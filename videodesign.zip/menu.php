<?php include 'header3.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
        <div class="text-center">
                   <div class="col-lg-12 menu d-flex align-items-center justify-content-center">
                    <div class="dropdown d-lg-inline-block ml-1">
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="bx bxs-briefcase-alt-2 text-dark"></i><br>Past a job
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-cog text-dark"></i><br>Manage Jobs
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-file-alt text-dark"></i><br>View Drafts
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-envelope-open-text text-dark"></i><br>Inbox
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-bookmark text-dark"></i><br>save profiles
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-chart-bar text-dark"></i><br>Dashboard
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-question-circle text-dark"></i><br>FAGs
                        </button>
                                                
                    </div>
                   </div>
                   
                </div>
        </div>
    </div>
</div>
