<?php include 'header3.html' ?>
<div class="main-content">
<div class="page-content">
<div class="container-fluid">
   <link href="assets/libs/summernote/summernote-bs4.min.css" rel="stylesheet" type="text/css" />
   <!-- Bootstrap Css -->
   <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
   <!-- Icons Css -->
   <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
   <!-- App Css-->
   <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
   <!-- start page title -->
   <div class="container-fluid">
      <!-- start page title -->
      <div class="row">
         <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
               <h4 class="mb-0 font-size-18">The New Hire</h4>
            </div>
         </div>
      </div>
      <!-- end page title -->
      <div class="row">
         <div class="col-8">
            <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                     <div class="card-body">
                        <!-- Nav tabs -->
                        <ul class="nav nav-pills nav-justified" role="tablist">
                           <li class="nav-item waves-effect waves-light">
                              <a class="nav-link active" data-toggle="tab" href="#home-1" role="tab">
                              <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                              <span class="d-none d-sm-block">Job Description</span> 
                              </a>
                           </li>
                           <li class="nav-item waves-effect waves-light">
                              <a class="nav-link" data-toggle="tab" href="#profile-1" role="tab">
                              <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                              <span class="d-none d-sm-block">Setting</span> 
                              </a>
                           </li>
                           <div class="col-md-1 text-center">
                              <div class="mt-2">
                                 <h1><i class="bx bx-edit mr-1 text-primary"></i> </h1>
                              </div>
                           </div>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content p-3 text-muted">
                           <div class="tab-pane active" id="home-1" role="tabpanel">
                              <p>
                                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditate iste incidunt repellendus architecto quisquam, nulla temporibus doloremque laudantium nihil recusandae id maiores commodi.                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditate iste incidunt repellendus architecto quisquam, nulla temporibus doloremque laudantium nihil recusandae id maiores commodi.
                              </p>
                              <p>
                                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditate iste incidunt repellendus architecto quisquam, nulla temporibus doloremque laudantium nihil recusandae id maiores commodi.
                              </p>
                              <p>
                                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditat.
                              </p>
                              <p>
                                 Raw denim you
                              </p>
                              <p>
                                 Raw denim you probably haven't heard of them jean shorts Austin.
                                 Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache. Aliquip placeat salvia cillum
                                 iphone. Seitan aliquip quis cardigan american apparel, butcher
                                 voluptate nisi qui.
                              </p>
                              <p>
                                 Raw denim you probably haven't heard of them jean shorts Austin.
                                 Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="card">
               <div class="card-body">
                  <div class="row">
                     <div class="col-md-11">
                        <h5 class="font-size-15 mt-4">Skills</h5>
                     </div>
                     <div class="col-md-1 text-center">
                        <div class="mt-2">
                           <h1><i class="bx bx-edit mr-1 text-primary"></i> </h1>
                        </div>
                     </div>
                  </div>
                  <div class="text-muted mt-4">
                     <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> Relation Database</p>
                     <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> Javascript</p>
                     <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> NodeJS</p>
                     <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> Python</p>
                  </div>
               </div>
            </div>
            <div class="card">
               <div class="card-body">
                  <div class="row">
                     <div class="col-md-11">
                        <h5 class="font-size-15 mt-4"> Screening Questions</h5>
                     </div>
                     <div class="col-md-1 text-center">
                        <div class="mt-2">
                           <h1><i class="bx bx-edit mr-1 text-primary"></i> </h1>
                        </div>
                     </div>
                  </div>
                  <div class="text-muted mt-4">
                     <ol>
                        <li>
                           how many years of works experence do you have using relational database 
                           <p><b>Answer:</b> 1 year <br><b>Type:</b> Requried perentage Assigmend:50%</p>
                        </li>
                        <li>
                           how many years of works experence do you have using relational database 
                           <p><b>Answer:</b> 1 year <br><b>Type:</b> Requried perentage Assigmend:50%</p>
                        </li>
                     </ol>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-4 text-center">
                           <button type="button" class="btn btn-outline-secondary waves-effect my-5">View all jobs</button>
                           <div class="row">
                           <div class="col-md-12"><p class="chatid">Statistics</p></div>
                           <div class="col-6"><p class="chatid">Reached to 100</p></div>
                           <div class="col-6"><p class="chatid">Views 50</p></div>
                           <div class="col-6"><p class="chatid">Application 20</p></div>
                           <div class="col-6"><p class="chatid">Under Review 10</p></div>
                           <div class="col-6"><p class="chatid"><b>Shortlisted You</b> howe short Listed anuet </p></div>
                           <div class="col-6"><p class="chatid"><b>Shortlisted You</b> howe short Listed anuet </p></div>
                           <div class="col-6"><p class="chatid">Not a Flit 2</p></div>
                           <div class="col-6"><p class="chatid">Inbox 20</p></div>

                            </div>
                        </div>
      </div>
      <button type="button" class="btn btn-outline-secondary waves-effect my-5">View all candidate</button>

   </div>
   <!-- end row -->
</div>
<!-- container-fluid -->