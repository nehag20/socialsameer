<?php include 'header3.html' ?>
<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-lg-9">
                           <div class="card-title-desc">
                              Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum fuga consequuntur quasi laborum dolor porro et optio doloribus nobis, quos iusto consequatur ratione ducimus nihil dolorem sit earum, rem aliquam!
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <p class="chatid">Subject:Job Id -SEF20205456 </p>
                        </div>
                        <div class="col-lg-12 about2bg mb-4">
                           <div class="row">
                              <div class="col-lg-8  justify-content-end my-2">
                                 <form>
                                    <div class="position-relative">
                                       <input type="text" class="custom-input form-control" placeholder="Search...">
                                       <span class="bx bx-search-alt custom-search"></span>
                                       <span class="bx bxs-microphone custom-voice"></span>
                                    </div>
                                 </form>
                              </div>
                              <div class="col-lg-4">
                                 <span><i class="fas fa-arrow-circle-left text-dark mx-1"></i>Go back to Application</span>
                                 <button type="button" class="btn btn-outline-secondary waves-effect my-2">View all jobs</button>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-9">
                           <iframe width="100%" height="315" src="https://www.youtube.com/embed/xcJtL7QggTI" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                           <div class="row">
                              <div class="col-lg-8 my-3">
                                 <div class="w-25">
                                    <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid img-thumbnail rounded-circle avatar-md">
                                 </div>
                                 <div class="text-left">
                                    <span class="username"> Business Advisor</span>
                                    <p>Full Time - Permanent <br>
                                       Surry, BC, Canada
                                    </p>
                                    <small class="pt-2 pb-2">Application ID : 0325465465 |<a href="javascript:void(0)"> Status - Opend</a></small>
                                 </div>
                              </div>
                              <div class="col-lg-4 text-center">
                                 <span class="mt-4">Saved on 12/01/2020</span><br>
                                 <div class="button-items">
                                    <button type="button" class="btn btn-primary waves-effect btn-sm waves-light">View Full Profile</button>
                                    <button type="button" class="btn btn-primary btn-sm waves-effect waves-light">Resume</button>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-12 dropdown d-lg-inline-block my-3">
                              <button type="button" class="btn header-item noti-icon waves-effect text-dark about2-icon">
                                 <i class="far fa-star text-dark"></i><br>Rating
                              </button>
                              <button type="button" class="btn header-item noti-icon waves-effect text-dark about2-icon">
                                 <i class="fas fa-thumbs-up text-dark"></i><br>Fit
                              </button>
                              <button type="button" class="btn header-item noti-icon waves-effect text-dark about2-icon">
                                 <i class="fas fa-thumbs-down text-dark"></i><br>Not Fit
                              </button>
                              <button type="button" class="btn header-item noti-icon waves-effect text-dark about2-icon">
                                 <i class="fas fa-comment text-dark"></i><br>Inbox
                              </button>
                              <button type="button" class="btn header-item noti-icon waves-effect text-dark about2-icon schedule">
                                 <i class="far fa-calendar-alt text-dark"></i><br>Schedule <br> on Interview
                              </button>
                              <button type="button" class="btn header-item noti-icon waves-effect text-dark about2-icon">
                                 <i class="fas fa-bookmark text-dark"></i><br>Saved
                              </button>
                              <button type="button" class="btn  header-item noti-icon waves-effect text-dark about2-icon">
                                 <i class="fas fa-sticky-note text-dark"></i><br>Notes
                              </button>
                              <button type="button" class="btn header-item noti-icon waves-effect text-dark about2-icon">
                                 <i class="fas fa-share-square text-dark"></i><br>Share
                              </button><br>
                              <div class="d-flex">
                                    <div class="col-lg-1 mr-2">
                                       <button type="button" class="btn btn-outline-secondary waves-effect">Status</button>
                                    </div>
                                    <div class="col-lg-3">
                                       <select class="form-control">
                                          <option>Title</option>
                                          <option>Large select</option>
                                          <option>Small select</option>
                                       </select>
                                    </div>
                              </div>
                           </div>
                           <h4 class="card-title my-3">ABOUT ME</h4>
                           <p class="text-muted">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quibusdam hic provident eum laudantium dolor accusantium nobis, ex corrupti impedit molestias nostrum placeat blanditiis ut explicabo fugit, ullam minima iusto. Odit!</p>
                           <h4 class="card-title mb-5">WORK EXPERIENCE</h4>
                           <div class="faq-box media mb-4">
                              <div class="faq-icon mr-3">
                                 210-2012
                              </div>
                              <div class="media-body">
                                 <h5 class="font-size-15">Junlor Marketer</h5>
                                 <p class="text-muted">New common language will be more simple and regular than the existing European languages. It will be as simple as occidental.</p>
                              </div>
                           </div>
                           <div class="faq-box media mb-4">
                              <div class="faq-icon mr-3">
                                 210-2012
                              </div>
                              <div class="media-body">
                                 <h5 class="font-size-15">Marketer</h5>
                                 <p class="text-muted">Everyone realizes why a new common language would be desirable one could refuse to pay expensive translators.</p>
                              </div>
                           </div>
                           <div class="faq-box media mb-4">
                              <div class="faq-icon mr-3">
                                 210-2012
                              </div>
                              <div class="media-body">
                                 <h5 class="font-size-15">Marketing Director</h5>
                                 <p class="text-muted">If several languages coalesce, the grammar of the resulting language is more simple and regular than that of the individual languages.</p>
                              </div>
                           </div>
                           <h4 class="card-title mb-5">EDUCATION</h4>
                           <div class="faq-box media mb-4">
                              <div class="faq-icon mr-3">
                                 210-2012
                              </div>
                              <div class="media-body">
                                 <h5 class="font-size-15">Advertsing school at stanford university</h5>
                                 <p class="text-muted">Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary.</p>
                              </div>
                           </div>
                           <div class="faq-box media">
                              <div class="faq-icon mr-3">
                                 210-2012
                              </div>
                              <div class="media-body">
                                 <h5 class="font-size-15">School Of Markrting At University Of PennSylvania</h5>
                                 <p class="text-muted">To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental</p>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3">
                           <div class="about2bg  mb-3">
                              <img class="img-thumbnail" alt="200x200" width="100%" src="assets/images/small/img-3.jpg" data-holder-rendered="true">
                              <div class="row">
                                 <div class="col-lg-8"><span class="text-muted mx-1">Neha -Full right hel</span></div>
                                 <div class="col-lg-4"><span>Open</span></div>
                              </div>
                           </div>
                           <div class="about2bg mb-3">
                              <img class="img-thumbnail" alt="200x200" width="100%" src="assets/images/small/img-3.jpg" data-holder-rendered="true">
                              <div class="row">
                                 <div class="col-lg-8"><span class="text-muted mx-1">Neha -Full right hel</span></div>
                                 <div class="col-lg-4"><span>Open</span></div>
                              </div>
                           </div>
                           <div class="about2bg mb-3">
                              <img class="img-thumbnail" alt="200x200" width="100%" src="assets/images/small/img-3.jpg" data-holder-rendered="true">
                              <div class="row">
                                 <div class="col-lg-8"><span class="text-muted mx-1">Neha -Full right hel</span></div>
                                 <div class="col-lg-4"><span>Open</span></div>
                              </div>
                           </div>
                           <div class="about2bg mb-3">
                              <img class="img-thumbnail" alt="200x200" width="100%" src="assets/images/small/img-3.jpg" data-holder-rendered="true">
                              <div class="row">
                                 <div class="col-lg-8"><span class="text-muted mx-1">Neha -Full right hel</span></div>
                                 <div class="col-lg-4"><span>Open</span></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>