<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Chat Box</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="searchbar">
                        <form>
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <select class="form-control" id="filter">
                                            <option>Recent Searches</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="search" placeholder="Search for jobs">
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="search" placeholder="Location">
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <button type="submit" class="btn btn-primary btn-block">Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="searchbar">
                        <form>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h1><span class="badge badge-secondary">Filters</span></h1>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <select class="form-control" id="filter">
                                            <option>Posted Date</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <select class="form-control" id="filter">
                                            <option>Revelance</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <select class="form-control" id="filter">
                                            <option>Employment Type</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <button type="submit" class="btn btn-primary btn-block">Create Job Alert</button>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <select class="form-control" id="filter">
                                            <option>Company</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <select class="form-control" id="filter">
                                            <option>Industry</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <select class="form-control" id="filter">
                                            <option>Network</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-9">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="post-wrapper mt-3 mb-3">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="w-25">
                                            <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="w-70" style="float: left; padding-left : 20px;">
                                            <span class="username">Small Business Advisor</span>
                                            <p>Full Time - Permanent</p>
                                            <span class="username" style="padding-top: 15px;">Socia Bank</span>
                                            <p>Vancouver, Canada</p>
                                        </div>
                                        <div class="w-10">
                                            <div class="dropdown">
                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Share</a>
                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <ul class="jobs">
                                            <li>Posted 2 days ago</li>
                                            <li>125 Views</li>
                                            <li>80 Applicants</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="post-wrapper mt-3 mb-3">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="w-25">
                                            <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="w-70" style="float: left; padding-left : 20px;">
                                            <span class="username">Small Business Advisor</span>
                                            <p>Full Time - Permanent</p>
                                            <span class="username" style="padding-top: 15px;">Socia Bank</span>
                                            <p>Vancouver, Canada</p>
                                        </div>
                                        <div class="w-10">
                                            <div class="dropdown">
                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Share</a>
                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <ul class="jobs">
                                            <li>Posted 2 days ago</li>
                                            <li>125 Views</li>
                                            <li>80 Applicants</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="post-wrapper mt-3 mb-3">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="w-25">
                                            <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="w-70" style="float: left; padding-left : 20px;">
                                            <span class="username">Small Business Advisor</span>
                                            <p>Full Time - Permanent</p>
                                            <span class="username" style="padding-top: 15px;">Socia Bank</span>
                                            <p>Vancouver, Canada</p>
                                        </div>
                                        <div class="w-10">
                                            <div class="dropdown">
                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Share</a>
                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <ul class="jobs">
                                            <li>Posted 2 days ago</li>
                                            <li>125 Views</li>
                                            <li>80 Applicants</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="post-wrapper mt-3 mb-3">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="w-25">
                                            <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="w-70" style="float: left; padding-left : 20px;">
                                            <span class="username">Small Business Advisor</span>
                                            <p>Full Time - Permanent</p>
                                            <span class="username" style="padding-top: 15px;">Socia Bank</span>
                                            <p>Vancouver, Canada</p>
                                        </div>
                                        <div class="w-10">
                                            <div class="dropdown">
                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Share</a>
                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <ul class="jobs">
                                            <li>Posted 2 days ago</li>
                                            <li>125 Views</li>
                                            <li>80 Applicants</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="post-wrapper mt-3 mb-3">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="w-25">
                                            <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="w-70" style="float: left; padding-left : 20px;">
                                            <span class="username">Small Business Advisor</span>
                                            <p>Full Time - Permanent</p>
                                            <span class="username" style="padding-top: 15px;">Socia Bank</span>
                                            <p>Vancouver, Canada</p>
                                        </div>
                                        <div class="w-10">
                                            <div class="dropdown">
                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Share</a>
                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <ul class="jobs">
                                            <li>Posted 2 days ago</li>
                                            <li>125 Views</li>
                                            <li>80 Applicants</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="post-wrapper mt-3 mb-3">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="w-25">
                                            <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="w-70" style="float: left; padding-left : 20px;">
                                            <span class="username">Small Business Advisor</span>
                                            <p>Full Time - Permanent</p>
                                            <span class="username" style="padding-top: 15px;">Socia Bank</span>
                                            <p>Vancouver, Canada</p>
                                        </div>
                                        <div class="w-10">
                                            <div class="dropdown">
                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Share</a>
                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <ul class="jobs">
                                            <li>Posted 2 days ago</li>
                                            <li>125 Views</li>
                                            <li>80 Applicants</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="user-chat">
                        <div class="card">
                            <div class="p-4 border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="profile-card text-center">
                                            <img src="assets/images/users/avatar-2.jpg" alt="" class="img-fluid rounded-circle">
                                        </div>
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">Steven Franklin</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Full Stack Developer at Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="p-4 border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">250</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Associates</p>
                                    </div>
                                    <div class="col-md-12">
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">50</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Mutual Associates</p>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="text-dark pb-1 pt-3 text-center font-size-18">Association since Oct 31st 2019</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

</div>

</div>
</div>
<!-- /Right-bar -->