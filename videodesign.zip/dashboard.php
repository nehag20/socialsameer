<?php include 'header5.html' ?>
<link href="assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">


            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0 font-size-18">Dashborad</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="card overflow-hidden">
                        <div class="bg-soft-primary">
                            <div class="row">
                                <div class="col-7">
                                    <div class="text-primary p-3">
                                        <h5 class="text-primary">Welcome Back !</h5>
                                        <p>Skote Dashboard</p>
                                    </div>
                                </div>
                                <div class="col-5 align-self-end">
                                    <img src="assets/images/profile-img.png" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="avatar-md profile-user-wid mb-4">
                                        <img src="assets/images/users/avatar-1.jpg" alt="" class="img-thumbnail rounded-circle">
                                    </div>
                                    <h5 class="font-size-15 text-truncate">Henry Price</h5>
                                    <p class="text-muted mb-0 text-truncate">UI/UX Designer</p>
                                </div>

                                <div class="col-sm-8">
                                    <div class="pt-4">

                                        <div class="row">
                                            <div class="col-6">
                                                <h5 class="font-size-15">125</h5>
                                                <p class="text-muted mb-0">Followers</p>
                                            </div>
                                            <div class="col-6">
                                                <h5 class="font-size-15">1245</h5>
                                                <p class="text-muted mb-0">Following</p>
                                            </div>
                                        </div>
                                        <div class="mt-4">
                                            <a href="" class="btn btn-primary waves-effect waves-light btn-sm">View Profile <i class="mdi mdi-arrow-right ml-1"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                </div>
                <div class="col-xl-12">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted font-weight-medium">Orders</p>
                                            <h4 class="mb-0">1,235</h4>
                                        </div>

                                        <div class="mini-stat-icon avatar-sm rounded-circle bg-primary align-self-center">
                                            <span class="avatar-title">
                                                <i class="bx bx-copy-alt font-size-24"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted font-weight-medium">Revenue</p>
                                            <h4 class="mb-0">$35, 723</h4>
                                        </div>

                                        <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                            <span class="avatar-title rounded-circle bg-primary">
                                                <i class="bx bx-archive-in font-size-24"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted font-weight-medium">Average Price</p>
                                            <h4 class="mb-0">$16.2</h4>
                                        </div>

                                        <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                            <span class="avatar-title rounded-circle bg-primary">
                                                <i class="bx bx-purchase-tag-alt font-size-24"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->

                    <div class="card">
                        <div class="card-body" style="position: relative;">
                            <h4 class="card-title mb-4 float-sm-left">Email Sent</h4>
                            <div class="float-sm-right">
                                <ul class="nav nav-pills">
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Week</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Month</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#">Year</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="clearfix"></div>
                            <div id="stacked-column-chart" class="apex-charts" dir="ltr" style="min-height: 374px;">
                                <div id="apexcharts3ba4a3" class="apexcharts-canvas apexcharts3ba4a3 apexcharts-theme-light" style="width: 755px; height: 359px;"><svg id="SvgjsSvg1174" width="755" height="359" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;">
                                        <foreignObject x="0" y="0" width="755" height="359">
                                            <div class="apexcharts-legend apexcharts-align-center position-bottom" xmlns="http://www.w3.org/1999/xhtml" style="inset: auto 0px 5px; position: absolute;">
                                                <div class="apexcharts-legend-series" rel="1" data:collapsed="false" style="margin: 0px 5px;"><span class="apexcharts-legend-marker" rel="1" data:collapsed="false" style="background: rgb(85, 110, 230); color: rgb(85, 110, 230); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 2px;"></span><span class="apexcharts-legend-text" rel="1" i="0" data:default-text="Series%20A" data:collapsed="false" style="color: rgb(55, 61, 63); font-size: 12px; font-family: Helvetica, Arial, sans-serif;">Series A</span></div>
                                                <div class="apexcharts-legend-series" rel="2" data:collapsed="false" style="margin: 0px 5px;"><span class="apexcharts-legend-marker" rel="2" data:collapsed="false" style="background: rgb(241, 180, 76); color: rgb(241, 180, 76); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 2px;"></span><span class="apexcharts-legend-text" rel="2" i="1" data:default-text="Series%20B" data:collapsed="false" style="color: rgb(55, 61, 63); font-size: 12px; font-family: Helvetica, Arial, sans-serif;">Series B</span></div>
                                                <div class="apexcharts-legend-series" rel="3" data:collapsed="false" style="margin: 0px 5px;"><span class="apexcharts-legend-marker" rel="3" data:collapsed="false" style="background: rgb(52, 195, 143); color: rgb(52, 195, 143); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 2px;"></span><span class="apexcharts-legend-text" rel="3" i="2" data:default-text="Series%20C" data:collapsed="false" style="color: rgb(55, 61, 63); font-size: 12px; font-family: Helvetica, Arial, sans-serif;">Series C</span></div>
                                            </div>
                                            <style type="text/css">
                                                .apexcharts-legend {
                                                    display: flex;
                                                    overflow: auto;
                                                    padding: 0 10px;
                                                }

                                                .apexcharts-legend.position-bottom,
                                                .apexcharts-legend.position-top {
                                                    flex-wrap: wrap
                                                }

                                                .apexcharts-legend.position-right,
                                                .apexcharts-legend.position-left {
                                                    flex-direction: column;
                                                    bottom: 0;
                                                }

                                                .apexcharts-legend.position-bottom.apexcharts-align-left,
                                                .apexcharts-legend.position-top.apexcharts-align-left,
                                                .apexcharts-legend.position-right,
                                                .apexcharts-legend.position-left {
                                                    justify-content: flex-start;
                                                }

                                                .apexcharts-legend.position-bottom.apexcharts-align-center,
                                                .apexcharts-legend.position-top.apexcharts-align-center {
                                                    justify-content: center;
                                                }

                                                .apexcharts-legend.position-bottom.apexcharts-align-right,
                                                .apexcharts-legend.position-top.apexcharts-align-right {
                                                    justify-content: flex-end;
                                                }

                                                .apexcharts-legend-series {
                                                    cursor: pointer;
                                                    line-height: normal;
                                                }

                                                .apexcharts-legend.position-bottom .apexcharts-legend-series,
                                                .apexcharts-legend.position-top .apexcharts-legend-series {
                                                    display: flex;
                                                    align-items: center;
                                                }

                                                .apexcharts-legend-text {
                                                    position: relative;
                                                    font-size: 14px;
                                                }

                                                .apexcharts-legend-text *,
                                                .apexcharts-legend-marker * {
                                                    pointer-events: none;
                                                }

                                                .apexcharts-legend-marker {
                                                    position: relative;
                                                    display: inline-block;
                                                    cursor: pointer;
                                                    margin-right: 3px;
                                                }

                                                .apexcharts-legend.apexcharts-align-right .apexcharts-legend-series,
                                                .apexcharts-legend.apexcharts-align-left .apexcharts-legend-series {
                                                    display: inline-block;
                                                }

                                                .apexcharts-legend-series.apexcharts-no-click {
                                                    cursor: auto;
                                                }

                                                .apexcharts-legend .apexcharts-hidden-zero-series,
                                                .apexcharts-legend .apexcharts-hidden-null-series {
                                                    display: none !important;
                                                }

                                                .apexcharts-inactive-legend {
                                                    opacity: 0.45;
                                                }
                                            </style>
                                        </foreignObject>
                                        <g id="SvgjsG1176" class="apexcharts-inner apexcharts-graphical" transform="translate(44.4375, 40)">
                                            <defs id="SvgjsDefs1175">
                                                <linearGradient id="SvgjsLinearGradient1179" x1="0" y1="0" x2="0" y2="1">
                                                    <stop id="SvgjsStop1180" stop-opacity="0.4" stop-color="rgba(216,227,240,0.4)" offset="0"></stop>
                                                    <stop id="SvgjsStop1181" stop-opacity="0.5" stop-color="rgba(190,209,230,0.5)" offset="1"></stop>
                                                    <stop id="SvgjsStop1182" stop-opacity="0.5" stop-color="rgba(190,209,230,0.5)" offset="1"></stop>
                                                </linearGradient>
                                                <clipPath id="gridRectMask3ba4a3">
                                                    <rect id="SvgjsRect1184" width="704.5625" height="256.494" x="-2" y="0" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                                </clipPath>
                                                <clipPath id="gridRectMarkerMask3ba4a3">
                                                    <rect id="SvgjsRect1185" width="702.5625" height="258.494" x="-1" y="-1" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                                </clipPath>
                                            </defs>
                                            <rect id="SvgjsRect1183" width="8.75703125" height="256.494" x="0" y="0" rx="0" ry="0" fill="url(#SvgjsLinearGradient1179)" opacity="1" stroke-width="0" stroke-dasharray="3" class="apexcharts-xcrosshairs" y2="256.494" filter="none" fill-opacity="0.9"></rect>
                                            <g id="SvgjsG1230" class="apexcharts-xaxis" transform="translate(0, 0)">
                                                <g id="SvgjsG1231" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"><text id="SvgjsText1233" font-family="Helvetica, Arial, sans-serif" x="29.190104166666668" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1234">Jan</tspan>
                                                        <title>Jan</title>
                                                    </text><text id="SvgjsText1236" font-family="Helvetica, Arial, sans-serif" x="87.5703125" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1237">Feb</tspan>
                                                        <title>Feb</title>
                                                    </text><text id="SvgjsText1239" font-family="Helvetica, Arial, sans-serif" x="145.95052083333334" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1240">Mar</tspan>
                                                        <title>Mar</title>
                                                    </text><text id="SvgjsText1242" font-family="Helvetica, Arial, sans-serif" x="204.33072916666669" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1243">Apr</tspan>
                                                        <title>Apr</title>
                                                    </text><text id="SvgjsText1245" font-family="Helvetica, Arial, sans-serif" x="262.7109375" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1246">May</tspan>
                                                        <title>May</title>
                                                    </text><text id="SvgjsText1248" font-family="Helvetica, Arial, sans-serif" x="321.0911458333333" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1249">Jun</tspan>
                                                        <title>Jun</title>
                                                    </text><text id="SvgjsText1251" font-family="Helvetica, Arial, sans-serif" x="379.47135416666663" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1252">Jul</tspan>
                                                        <title>Jul</title>
                                                    </text><text id="SvgjsText1254" font-family="Helvetica, Arial, sans-serif" x="437.85156249999994" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1255">Aug</tspan>
                                                        <title>Aug</title>
                                                    </text><text id="SvgjsText1257" font-family="Helvetica, Arial, sans-serif" x="496.2317708333333" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1258">Sep</tspan>
                                                        <title>Sep</title>
                                                    </text><text id="SvgjsText1260" font-family="Helvetica, Arial, sans-serif" x="554.6119791666667" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1261">Oct</tspan>
                                                        <title>Oct</title>
                                                    </text><text id="SvgjsText1263" font-family="Helvetica, Arial, sans-serif" x="612.9921875000001" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1264">Nov</tspan>
                                                        <title>Nov</title>
                                                    </text><text id="SvgjsText1266" font-family="Helvetica, Arial, sans-serif" x="671.3723958333335" y="285.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1267">Dec</tspan>
                                                        <title>Dec</title>
                                                    </text></g>
                                                <line id="SvgjsLine1268" x1="0" y1="257.494" x2="700.5625" y2="257.494" stroke="#e0e0e0" stroke-dasharray="0" stroke-width="1"></line>
                                            </g>
                                            <g id="SvgjsG1283" class="apexcharts-grid">
                                                <g id="SvgjsG1284" class="apexcharts-gridlines-horizontal">
                                                    <line id="SvgjsLine1299" x1="0" y1="0" x2="700.5625" y2="0" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1300" x1="0" y1="51.29880000000001" x2="700.5625" y2="51.29880000000001" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1301" x1="0" y1="102.59760000000001" x2="700.5625" y2="102.59760000000001" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1302" x1="0" y1="153.89640000000003" x2="700.5625" y2="153.89640000000003" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1303" x1="0" y1="205.19520000000003" x2="700.5625" y2="205.19520000000003" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1304" x1="0" y1="256.494" x2="700.5625" y2="256.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                </g>
                                                <g id="SvgjsG1285" class="apexcharts-gridlines-vertical"></g>
                                                <line id="SvgjsLine1286" x1="0" y1="257.494" x2="0" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1287" x1="58.380208333333336" y1="257.494" x2="58.380208333333336" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1288" x1="116.76041666666667" y1="257.494" x2="116.76041666666667" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1289" x1="175.140625" y1="257.494" x2="175.140625" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1290" x1="233.52083333333334" y1="257.494" x2="233.52083333333334" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1291" x1="291.9010416666667" y1="257.494" x2="291.9010416666667" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1292" x1="350.28125" y1="257.494" x2="350.28125" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1293" x1="408.6614583333333" y1="257.494" x2="408.6614583333333" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1294" x1="467.04166666666663" y1="257.494" x2="467.04166666666663" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1295" x1="525.421875" y1="257.494" x2="525.421875" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1296" x1="583.8020833333334" y1="257.494" x2="583.8020833333334" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1297" x1="642.1822916666667" y1="257.494" x2="642.1822916666667" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1298" x1="700.5625000000001" y1="257.494" x2="700.5625000000001" y2="263.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1306" x1="0" y1="256.494" x2="700.5625" y2="256.494" stroke="transparent" stroke-dasharray="0"></line>
                                                <line id="SvgjsLine1305" x1="0" y1="1" x2="0" y2="256.494" stroke="transparent" stroke-dasharray="0"></line>
                                            </g>
                                            <g id="SvgjsG1187" class="apexcharts-bar-series apexcharts-plot-series">
                                                <g id="SvgjsG1188" class="apexcharts-series" seriesName="SeriesxA" rel="1" data:realIndex="0">
                                                    <path id="SvgjsPath1190" d="M 24.811588541666666 256.494L 24.811588541666666 143.63664000000003Q 29.190104166666664 139.25812437500002 33.56861979166666 143.63664000000003L 33.56861979166666 256.494L 24.811588541666666 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 24.811588541666666 256.494L 24.811588541666666 143.63664000000003Q 29.190104166666664 139.25812437500002 33.56861979166666 143.63664000000003L 33.56861979166666 256.494L 24.811588541666666 256.494" pathFrom="M 24.811588541666666 256.494L 24.811588541666666 256.494L 33.56861979166666 256.494L 33.56861979166666 256.494L 33.56861979166666 256.494L 24.811588541666666 256.494" cy="143.63664000000003" cx="83.191796875" j="0" val="44" barHeight="112.85736" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1191" d="M 83.191796875 256.494L 83.191796875 115.4223Q 87.5703125 111.043784375 91.94882812499999 115.4223L 91.94882812499999 256.494L 83.191796875 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 83.191796875 256.494L 83.191796875 115.4223Q 87.5703125 111.043784375 91.94882812499999 115.4223L 91.94882812499999 256.494L 83.191796875 256.494" pathFrom="M 83.191796875 256.494L 83.191796875 256.494L 91.94882812499999 256.494L 91.94882812499999 256.494L 91.94882812499999 256.494L 83.191796875 256.494" cy="115.4223" cx="141.57200520833334" j="1" val="55" barHeight="141.07170000000002" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1192" d="M 141.57200520833334 256.494L 141.57200520833334 151.33146000000002Q 145.95052083333334 146.95294437500002 150.32903645833335 151.33146000000002L 150.32903645833335 256.494L 141.57200520833334 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 141.57200520833334 256.494L 141.57200520833334 151.33146000000002Q 145.95052083333334 146.95294437500002 150.32903645833335 151.33146000000002L 150.32903645833335 256.494L 141.57200520833334 256.494" pathFrom="M 141.57200520833334 256.494L 141.57200520833334 256.494L 150.32903645833335 256.494L 150.32903645833335 256.494L 150.32903645833335 256.494L 141.57200520833334 256.494" cy="151.33146000000002" cx="199.95221354166668" j="2" val="41" barHeight="105.16254" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1193" d="M 199.95221354166668 256.494L 199.95221354166668 84.64302Q 204.33072916666669 80.264504375 208.7092447916667 84.64302L 208.7092447916667 256.494L 199.95221354166668 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 199.95221354166668 256.494L 199.95221354166668 84.64302Q 204.33072916666669 80.264504375 208.7092447916667 84.64302L 208.7092447916667 256.494L 199.95221354166668 256.494" pathFrom="M 199.95221354166668 256.494L 199.95221354166668 256.494L 208.7092447916667 256.494L 208.7092447916667 256.494L 208.7092447916667 256.494L 199.95221354166668 256.494" cy="84.64302" cx="258.332421875" j="3" val="67" barHeight="171.85098000000002" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1194" d="M 258.332421875 256.494L 258.332421875 200.06532000000004Q 262.7109375 195.68680437500004 267.08945312500003 200.06532000000004L 267.08945312500003 256.494L 258.332421875 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 258.332421875 256.494L 258.332421875 200.06532000000004Q 262.7109375 195.68680437500004 267.08945312500003 200.06532000000004L 267.08945312500003 256.494L 258.332421875 256.494" pathFrom="M 258.332421875 256.494L 258.332421875 256.494L 267.08945312500003 256.494L 267.08945312500003 256.494L 267.08945312500003 256.494L 258.332421875 256.494" cy="200.06532000000004" cx="316.71263020833334" j="4" val="22" barHeight="56.42868" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1195" d="M 316.71263020833334 256.494L 316.71263020833334 146.20158000000004Q 321.0911458333333 141.82306437500003 325.46966145833335 146.20158000000004L 325.46966145833335 256.494L 316.71263020833334 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 316.71263020833334 256.494L 316.71263020833334 146.20158000000004Q 321.0911458333333 141.82306437500003 325.46966145833335 146.20158000000004L 325.46966145833335 256.494L 316.71263020833334 256.494" pathFrom="M 316.71263020833334 256.494L 316.71263020833334 256.494L 325.46966145833335 256.494L 325.46966145833335 256.494L 325.46966145833335 256.494L 316.71263020833334 256.494" cy="146.20158000000004" cx="375.09283854166665" j="5" val="43" barHeight="110.29242" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1196" d="M 375.09283854166665 256.494L 375.09283854166665 164.15616000000003Q 379.47135416666663 159.77764437500002 383.84986979166666 164.15616000000003L 383.84986979166666 256.494L 375.09283854166665 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 375.09283854166665 256.494L 375.09283854166665 164.15616000000003Q 379.47135416666663 159.77764437500002 383.84986979166666 164.15616000000003L 383.84986979166666 256.494L 375.09283854166665 256.494" pathFrom="M 375.09283854166665 256.494L 375.09283854166665 256.494L 383.84986979166666 256.494L 383.84986979166666 256.494L 383.84986979166666 256.494L 375.09283854166665 256.494" cy="164.15616000000003" cx="433.47304687499997" j="6" val="36" barHeight="92.33784" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1197" d="M 433.47304687499997 256.494L 433.47304687499997 123.11712000000003Q 437.85156249999994 118.73860437500002 442.230078125 123.11712000000003L 442.230078125 256.494L 433.47304687499997 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 433.47304687499997 256.494L 433.47304687499997 123.11712000000003Q 437.85156249999994 118.73860437500002 442.230078125 123.11712000000003L 442.230078125 256.494L 433.47304687499997 256.494" pathFrom="M 433.47304687499997 256.494L 433.47304687499997 256.494L 442.230078125 256.494L 442.230078125 256.494L 442.230078125 256.494L 433.47304687499997 256.494" cy="123.11712000000003" cx="491.8532552083333" j="7" val="52" barHeight="133.37688" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1198" d="M 491.8532552083333 256.494L 491.8532552083333 194.93544000000003Q 496.23177083333326 190.55692437500002 500.6102864583333 194.93544000000003L 500.6102864583333 256.494L 491.8532552083333 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 491.8532552083333 256.494L 491.8532552083333 194.93544000000003Q 496.23177083333326 190.55692437500002 500.6102864583333 194.93544000000003L 500.6102864583333 256.494L 491.8532552083333 256.494" pathFrom="M 491.8532552083333 256.494L 491.8532552083333 256.494L 500.6102864583333 256.494L 500.6102864583333 256.494L 500.6102864583333 256.494L 491.8532552083333 256.494" cy="194.93544000000003" cx="550.2334635416667" j="8" val="24" barHeight="61.55856" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1199" d="M 550.2334635416667 256.494L 550.2334635416667 210.32508Q 554.6119791666666 205.946564375 558.9904947916666 210.32508L 558.9904947916666 256.494L 550.2334635416667 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 550.2334635416667 256.494L 550.2334635416667 210.32508Q 554.6119791666666 205.946564375 558.9904947916666 210.32508L 558.9904947916666 256.494L 550.2334635416667 256.494" pathFrom="M 550.2334635416667 256.494L 550.2334635416667 256.494L 558.9904947916666 256.494L 558.9904947916666 256.494L 558.9904947916666 256.494L 550.2334635416667 256.494" cy="210.32508" cx="608.613671875" j="9" val="18" barHeight="46.16892" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1200" d="M 608.613671875 256.494L 608.613671875 164.15616000000003Q 612.9921875 159.77764437500002 617.370703125 164.15616000000003L 617.370703125 256.494L 608.613671875 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 608.613671875 256.494L 608.613671875 164.15616000000003Q 612.9921875 159.77764437500002 617.370703125 164.15616000000003L 617.370703125 256.494L 608.613671875 256.494" pathFrom="M 608.613671875 256.494L 608.613671875 256.494L 617.370703125 256.494L 617.370703125 256.494L 617.370703125 256.494L 608.613671875 256.494" cy="164.15616000000003" cx="666.9938802083334" j="10" val="36" barHeight="92.33784" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1201" d="M 666.9938802083334 256.494L 666.9938802083334 133.37688000000003Q 671.3723958333334 128.99836437500002 675.7509114583333 133.37688000000003L 675.7509114583333 256.494L 666.9938802083334 256.494" fill="rgba(85,110,230,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 666.9938802083334 256.494L 666.9938802083334 133.37688000000003Q 671.3723958333334 128.99836437500002 675.7509114583333 133.37688000000003L 675.7509114583333 256.494L 666.9938802083334 256.494" pathFrom="M 666.9938802083334 256.494L 666.9938802083334 256.494L 675.7509114583333 256.494L 675.7509114583333 256.494L 675.7509114583333 256.494L 666.9938802083334 256.494" cy="133.37688000000003" cx="725.3740885416668" j="11" val="48" barHeight="123.11712" barWidth="8.75703125"></path>
                                                </g>
                                                <g id="SvgjsG1202" class="apexcharts-series" seriesName="SeriesxB" rel="2" data:realIndex="1">
                                                    <path id="SvgjsPath1204" d="M 24.811588541666666 143.63664000000003L 24.811588541666666 110.29242000000002Q 29.190104166666664 105.91390437500002 33.56861979166666 110.29242000000002L 33.56861979166666 143.63664000000003L 24.811588541666666 143.63664000000003" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 24.811588541666666 143.63664000000003L 24.811588541666666 110.29242000000002Q 29.190104166666664 105.91390437500002 33.56861979166666 110.29242000000002L 33.56861979166666 143.63664000000003L 24.811588541666666 143.63664000000003" pathFrom="M 24.811588541666666 143.63664000000003L 24.811588541666666 143.63664000000003L 33.56861979166666 143.63664000000003L 33.56861979166666 143.63664000000003L 33.56861979166666 143.63664000000003L 24.811588541666666 143.63664000000003" cy="110.29242000000002" cx="83.191796875" j="0" val="13" barHeight="33.34422" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1205" d="M 83.191796875 115.4223L 83.191796875 56.42868000000001Q 87.5703125 52.05016437500001 91.94882812499999 56.42868000000001L 91.94882812499999 115.4223L 83.191796875 115.4223" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 83.191796875 115.4223L 83.191796875 56.42868000000001Q 87.5703125 52.05016437500001 91.94882812499999 56.42868000000001L 91.94882812499999 115.4223L 83.191796875 115.4223" pathFrom="M 83.191796875 115.4223L 83.191796875 115.4223L 91.94882812499999 115.4223L 91.94882812499999 115.4223L 91.94882812499999 115.4223L 83.191796875 115.4223" cy="56.42868000000001" cx="141.57200520833334" j="1" val="23" barHeight="58.99362" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1206" d="M 141.57200520833334 151.33146000000002L 141.57200520833334 100.03266000000002Q 145.95052083333334 95.65414437500002 150.32903645833335 100.03266000000002L 150.32903645833335 151.33146000000002L 141.57200520833334 151.33146000000002" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 141.57200520833334 151.33146000000002L 141.57200520833334 100.03266000000002Q 145.95052083333334 95.65414437500002 150.32903645833335 100.03266000000002L 150.32903645833335 151.33146000000002L 141.57200520833334 151.33146000000002" pathFrom="M 141.57200520833334 151.33146000000002L 141.57200520833334 151.33146000000002L 150.32903645833335 151.33146000000002L 150.32903645833335 151.33146000000002L 150.32903645833335 151.33146000000002L 141.57200520833334 151.33146000000002" cy="100.03266000000002" cx="199.95221354166668" j="2" val="20" barHeight="51.2988" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1207" d="M 199.95221354166668 84.64302L 199.95221354166668 64.1235Q 204.33072916666669 59.74498437500001 208.7092447916667 64.1235L 208.7092447916667 84.64302L 199.95221354166668 84.64302" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 199.95221354166668 84.64302L 199.95221354166668 64.1235Q 204.33072916666669 59.74498437500001 208.7092447916667 64.1235L 208.7092447916667 84.64302L 199.95221354166668 84.64302" pathFrom="M 199.95221354166668 84.64302L 199.95221354166668 84.64302L 208.7092447916667 84.64302L 208.7092447916667 84.64302L 208.7092447916667 84.64302L 199.95221354166668 84.64302" cy="64.1235" cx="258.332421875" j="3" val="8" barHeight="20.51952" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1208" d="M 258.332421875 200.06532000000004L 258.332421875 166.72110000000004Q 262.7109375 162.34258437500003 267.08945312500003 166.72110000000004L 267.08945312500003 200.06532000000004L 258.332421875 200.06532000000004" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 258.332421875 200.06532000000004L 258.332421875 166.72110000000004Q 262.7109375 162.34258437500003 267.08945312500003 166.72110000000004L 267.08945312500003 200.06532000000004L 258.332421875 200.06532000000004" pathFrom="M 258.332421875 200.06532000000004L 258.332421875 200.06532000000004L 267.08945312500003 200.06532000000004L 267.08945312500003 200.06532000000004L 267.08945312500003 200.06532000000004L 258.332421875 200.06532000000004" cy="166.72110000000004" cx="316.71263020833334" j="4" val="13" barHeight="33.34422" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1209" d="M 316.71263020833334 146.20158000000004L 316.71263020833334 76.94820000000003Q 321.0911458333333 72.56968437500002 325.46966145833335 76.94820000000003L 325.46966145833335 146.20158000000004L 316.71263020833334 146.20158000000004" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 316.71263020833334 146.20158000000004L 316.71263020833334 76.94820000000003Q 321.0911458333333 72.56968437500002 325.46966145833335 76.94820000000003L 325.46966145833335 146.20158000000004L 316.71263020833334 146.20158000000004" pathFrom="M 316.71263020833334 146.20158000000004L 316.71263020833334 146.20158000000004L 325.46966145833335 146.20158000000004L 325.46966145833335 146.20158000000004L 325.46966145833335 146.20158000000004L 316.71263020833334 146.20158000000004" cy="76.94820000000003" cx="375.09283854166665" j="5" val="27" barHeight="69.25338" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1210" d="M 375.09283854166665 164.15616000000003L 375.09283854166665 117.98724000000003Q 379.47135416666663 113.60872437500002 383.84986979166666 117.98724000000003L 383.84986979166666 164.15616000000003L 375.09283854166665 164.15616000000003" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 375.09283854166665 164.15616000000003L 375.09283854166665 117.98724000000003Q 379.47135416666663 113.60872437500002 383.84986979166666 117.98724000000003L 383.84986979166666 164.15616000000003L 375.09283854166665 164.15616000000003" pathFrom="M 375.09283854166665 164.15616000000003L 375.09283854166665 164.15616000000003L 383.84986979166666 164.15616000000003L 383.84986979166666 164.15616000000003L 383.84986979166666 164.15616000000003L 375.09283854166665 164.15616000000003" cy="117.98724000000003" cx="433.47304687499997" j="6" val="18" barHeight="46.16892" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1211" d="M 433.47304687499997 123.11712000000003L 433.47304687499997 66.68844000000003Q 437.85156249999994 62.30992437500003 442.230078125 66.68844000000003L 442.230078125 123.11712000000003L 433.47304687499997 123.11712000000003" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 433.47304687499997 123.11712000000003L 433.47304687499997 66.68844000000003Q 437.85156249999994 62.30992437500003 442.230078125 66.68844000000003L 442.230078125 123.11712000000003L 433.47304687499997 123.11712000000003" pathFrom="M 433.47304687499997 123.11712000000003L 433.47304687499997 123.11712000000003L 442.230078125 123.11712000000003L 442.230078125 123.11712000000003L 442.230078125 123.11712000000003L 433.47304687499997 123.11712000000003" cy="66.68844000000003" cx="491.8532552083333" j="7" val="22" barHeight="56.42868" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1212" d="M 491.8532552083333 194.93544000000003L 491.8532552083333 169.28604Q 496.23177083333326 164.907524375 500.6102864583333 169.28604L 500.6102864583333 194.93544000000003L 491.8532552083333 194.93544000000003" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 491.8532552083333 194.93544000000003L 491.8532552083333 169.28604Q 496.23177083333326 164.907524375 500.6102864583333 169.28604L 500.6102864583333 194.93544000000003L 491.8532552083333 194.93544000000003" pathFrom="M 491.8532552083333 194.93544000000003L 491.8532552083333 194.93544000000003L 500.6102864583333 194.93544000000003L 500.6102864583333 194.93544000000003L 500.6102864583333 194.93544000000003L 491.8532552083333 194.93544000000003" cy="169.28604" cx="550.2334635416667" j="8" val="10" barHeight="25.6494" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1213" d="M 550.2334635416667 210.32508L 550.2334635416667 169.28604Q 554.6119791666666 164.907524375 558.9904947916666 169.28604L 558.9904947916666 210.32508L 550.2334635416667 210.32508" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 550.2334635416667 210.32508L 550.2334635416667 169.28604Q 554.6119791666666 164.907524375 558.9904947916666 169.28604L 558.9904947916666 210.32508L 550.2334635416667 210.32508" pathFrom="M 550.2334635416667 210.32508L 550.2334635416667 210.32508L 558.9904947916666 210.32508L 558.9904947916666 210.32508L 558.9904947916666 210.32508L 550.2334635416667 210.32508" cy="169.28604" cx="608.613671875" j="9" val="16" barHeight="41.03904" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1214" d="M 608.613671875 164.15616000000003L 608.613671875 102.59760000000003Q 612.9921875 98.21908437500002 617.370703125 102.59760000000003L 617.370703125 164.15616000000003L 608.613671875 164.15616000000003" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 608.613671875 164.15616000000003L 608.613671875 102.59760000000003Q 612.9921875 98.21908437500002 617.370703125 102.59760000000003L 617.370703125 164.15616000000003L 608.613671875 164.15616000000003" pathFrom="M 608.613671875 164.15616000000003L 608.613671875 164.15616000000003L 617.370703125 164.15616000000003L 617.370703125 164.15616000000003L 617.370703125 164.15616000000003L 608.613671875 164.15616000000003" cy="102.59760000000003" cx="666.9938802083334" j="10" val="24" barHeight="61.55856" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1215" d="M 666.9938802083334 133.37688000000003L 666.9938802083334 76.94820000000003Q 671.3723958333334 72.56968437500002 675.7509114583333 76.94820000000003L 675.7509114583333 133.37688000000003L 666.9938802083334 133.37688000000003" fill="rgba(241,180,76,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 666.9938802083334 133.37688000000003L 666.9938802083334 76.94820000000003Q 671.3723958333334 72.56968437500002 675.7509114583333 76.94820000000003L 675.7509114583333 133.37688000000003L 666.9938802083334 133.37688000000003" pathFrom="M 666.9938802083334 133.37688000000003L 666.9938802083334 133.37688000000003L 675.7509114583333 133.37688000000003L 675.7509114583333 133.37688000000003L 675.7509114583333 133.37688000000003L 666.9938802083334 133.37688000000003" cy="76.94820000000003" cx="725.3740885416668" j="11" val="22" barHeight="56.42868" barWidth="8.75703125"></path>
                                                </g>
                                                <g id="SvgjsG1216" class="apexcharts-series" seriesName="SeriesxC" rel="3" data:realIndex="2">
                                                    <path id="SvgjsPath1218" d="M 24.811588541666666 110.29242000000002L 24.811588541666666 82.07808000000003Q 29.190104166666664 77.69956437500002 33.56861979166666 82.07808000000003L 33.56861979166666 110.29242000000002L 24.811588541666666 110.29242000000002" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 24.811588541666666 110.29242000000002L 24.811588541666666 82.07808000000003Q 29.190104166666664 77.69956437500002 33.56861979166666 82.07808000000003L 33.56861979166666 110.29242000000002L 24.811588541666666 110.29242000000002" pathFrom="M 24.811588541666666 110.29242000000002L 24.811588541666666 110.29242000000002L 33.56861979166666 110.29242000000002L 33.56861979166666 110.29242000000002L 33.56861979166666 110.29242000000002L 24.811588541666666 110.29242000000002" cy="82.07808000000003" cx="83.191796875" j="0" val="11" barHeight="28.21434" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1219" d="M 83.191796875 56.42868000000001L 83.191796875 12.824700000000007Q 87.5703125 8.446184375000007 91.94882812499999 12.824700000000007L 91.94882812499999 56.42868000000001L 83.191796875 56.42868000000001" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 83.191796875 56.42868000000001L 83.191796875 12.824700000000007Q 87.5703125 8.446184375000007 91.94882812499999 12.824700000000007L 91.94882812499999 56.42868000000001L 83.191796875 56.42868000000001" pathFrom="M 83.191796875 56.42868000000001L 83.191796875 56.42868000000001L 91.94882812499999 56.42868000000001L 91.94882812499999 56.42868000000001L 91.94882812499999 56.42868000000001L 83.191796875 56.42868000000001" cy="12.824700000000007" cx="141.57200520833334" j="1" val="17" barHeight="43.60398" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1220" d="M 141.57200520833334 100.03266000000002L 141.57200520833334 61.55856000000002Q 145.95052083333334 57.18004437500002 150.32903645833335 61.55856000000002L 150.32903645833335 100.03266000000002L 141.57200520833334 100.03266000000002" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 141.57200520833334 100.03266000000002L 141.57200520833334 61.55856000000002Q 145.95052083333334 57.18004437500002 150.32903645833335 61.55856000000002L 150.32903645833335 100.03266000000002L 141.57200520833334 100.03266000000002" pathFrom="M 141.57200520833334 100.03266000000002L 141.57200520833334 100.03266000000002L 150.32903645833335 100.03266000000002L 150.32903645833335 100.03266000000002L 150.32903645833335 100.03266000000002L 141.57200520833334 100.03266000000002" cy="61.55856000000002" cx="199.95221354166668" j="2" val="15" barHeight="38.4741" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1221" d="M 199.95221354166668 64.1235L 199.95221354166668 25.649400000000007Q 204.33072916666669 21.27088437500001 208.7092447916667 25.649400000000007L 208.7092447916667 64.1235L 199.95221354166668 64.1235" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 199.95221354166668 64.1235L 199.95221354166668 25.649400000000007Q 204.33072916666669 21.27088437500001 208.7092447916667 25.649400000000007L 208.7092447916667 64.1235L 199.95221354166668 64.1235" pathFrom="M 199.95221354166668 64.1235L 199.95221354166668 64.1235L 208.7092447916667 64.1235L 208.7092447916667 64.1235L 208.7092447916667 64.1235L 199.95221354166668 64.1235" cy="25.649400000000007" cx="258.332421875" j="3" val="15" barHeight="38.4741" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1222" d="M 258.332421875 166.72110000000004L 258.332421875 112.85736000000003Q 262.7109375 108.47884437500002 267.08945312500003 112.85736000000003L 267.08945312500003 166.72110000000004L 258.332421875 166.72110000000004" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 258.332421875 166.72110000000004L 258.332421875 112.85736000000003Q 262.7109375 108.47884437500002 267.08945312500003 112.85736000000003L 267.08945312500003 166.72110000000004L 258.332421875 166.72110000000004" pathFrom="M 258.332421875 166.72110000000004L 258.332421875 166.72110000000004L 267.08945312500003 166.72110000000004L 267.08945312500003 166.72110000000004L 267.08945312500003 166.72110000000004L 258.332421875 166.72110000000004" cy="112.85736000000003" cx="316.71263020833334" j="4" val="21" barHeight="53.86374" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1223" d="M 316.71263020833334 76.94820000000003L 316.71263020833334 41.03904000000003Q 321.0911458333333 36.66052437500003 325.46966145833335 41.03904000000003L 325.46966145833335 76.94820000000003L 316.71263020833334 76.94820000000003" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 316.71263020833334 76.94820000000003L 316.71263020833334 41.03904000000003Q 321.0911458333333 36.66052437500003 325.46966145833335 41.03904000000003L 325.46966145833335 76.94820000000003L 316.71263020833334 76.94820000000003" pathFrom="M 316.71263020833334 76.94820000000003L 316.71263020833334 76.94820000000003L 325.46966145833335 76.94820000000003L 325.46966145833335 76.94820000000003L 325.46966145833335 76.94820000000003L 316.71263020833334 76.94820000000003" cy="41.03904000000003" cx="375.09283854166665" j="5" val="14" barHeight="35.90916" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1224" d="M 375.09283854166665 117.98724000000003L 375.09283854166665 89.77290000000002Q 379.47135416666663 85.39438437500002 383.84986979166666 89.77290000000002L 383.84986979166666 117.98724000000003L 375.09283854166665 117.98724000000003" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 375.09283854166665 117.98724000000003L 375.09283854166665 89.77290000000002Q 379.47135416666663 85.39438437500002 383.84986979166666 89.77290000000002L 383.84986979166666 117.98724000000003L 375.09283854166665 117.98724000000003" pathFrom="M 375.09283854166665 117.98724000000003L 375.09283854166665 117.98724000000003L 383.84986979166666 117.98724000000003L 383.84986979166666 117.98724000000003L 383.84986979166666 117.98724000000003L 375.09283854166665 117.98724000000003" cy="89.77290000000002" cx="433.47304687499997" j="6" val="11" barHeight="28.21434" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1225" d="M 433.47304687499997 66.68844000000003L 433.47304687499997 20.51952000000003Q 437.85156249999994 16.14100437500003 442.230078125 20.51952000000003L 442.230078125 66.68844000000003L 433.47304687499997 66.68844000000003" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 433.47304687499997 66.68844000000003L 433.47304687499997 20.51952000000003Q 437.85156249999994 16.14100437500003 442.230078125 20.51952000000003L 442.230078125 66.68844000000003L 433.47304687499997 66.68844000000003" pathFrom="M 433.47304687499997 66.68844000000003L 433.47304687499997 66.68844000000003L 442.230078125 66.68844000000003L 442.230078125 66.68844000000003L 442.230078125 66.68844000000003L 433.47304687499997 66.68844000000003" cy="20.51952000000003" cx="491.8532552083333" j="7" val="18" barHeight="46.16892" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1226" d="M 491.8532552083333 169.28604L 491.8532552083333 125.68206Q 496.23177083333326 121.303544375 500.6102864583333 125.68206L 500.6102864583333 169.28604L 491.8532552083333 169.28604" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 491.8532552083333 169.28604L 491.8532552083333 125.68206Q 496.23177083333326 121.303544375 500.6102864583333 125.68206L 500.6102864583333 169.28604L 491.8532552083333 169.28604" pathFrom="M 491.8532552083333 169.28604L 491.8532552083333 169.28604L 500.6102864583333 169.28604L 500.6102864583333 169.28604L 500.6102864583333 169.28604L 491.8532552083333 169.28604" cy="125.68206" cx="550.2334635416667" j="8" val="17" barHeight="43.60398" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1227" d="M 550.2334635416667 169.28604L 550.2334635416667 138.50676Q 554.6119791666666 134.128244375 558.9904947916666 138.50676L 558.9904947916666 169.28604L 550.2334635416667 169.28604" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 550.2334635416667 169.28604L 550.2334635416667 138.50676Q 554.6119791666666 134.128244375 558.9904947916666 138.50676L 558.9904947916666 169.28604L 550.2334635416667 169.28604" pathFrom="M 550.2334635416667 169.28604L 550.2334635416667 169.28604L 558.9904947916666 169.28604L 558.9904947916666 169.28604L 558.9904947916666 169.28604L 550.2334635416667 169.28604" cy="138.50676" cx="608.613671875" j="9" val="12" barHeight="30.77928" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1228" d="M 608.613671875 102.59760000000003L 608.613671875 51.29880000000003Q 612.9921875 46.92028437500003 617.370703125 51.29880000000003L 617.370703125 102.59760000000003L 608.613671875 102.59760000000003" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 608.613671875 102.59760000000003L 608.613671875 51.29880000000003Q 612.9921875 46.92028437500003 617.370703125 51.29880000000003L 617.370703125 102.59760000000003L 608.613671875 102.59760000000003" pathFrom="M 608.613671875 102.59760000000003L 608.613671875 102.59760000000003L 617.370703125 102.59760000000003L 617.370703125 102.59760000000003L 617.370703125 102.59760000000003L 608.613671875 102.59760000000003" cy="51.29880000000003" cx="666.9938802083334" j="10" val="20" barHeight="51.2988" barWidth="8.75703125"></path>
                                                    <path id="SvgjsPath1229" d="M 666.9938802083334 76.94820000000003L 666.9938802083334 30.77928000000003Q 671.3723958333334 26.40076437500003 675.7509114583333 30.77928000000003L 675.7509114583333 76.94820000000003L 666.9938802083334 76.94820000000003" fill="rgba(52,195,143,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMask3ba4a3)" pathTo="M 666.9938802083334 76.94820000000003L 666.9938802083334 30.77928000000003Q 671.3723958333334 26.40076437500003 675.7509114583333 30.77928000000003L 675.7509114583333 76.94820000000003L 666.9938802083334 76.94820000000003" pathFrom="M 666.9938802083334 76.94820000000003L 666.9938802083334 76.94820000000003L 675.7509114583333 76.94820000000003L 675.7509114583333 76.94820000000003L 675.7509114583333 76.94820000000003L 666.9938802083334 76.94820000000003" cy="30.77928000000003" cx="725.3740885416668" j="11" val="18" barHeight="46.16892" barWidth="8.75703125"></path>
                                                </g>
                                                <g id="SvgjsG1189" class="apexcharts-datalabels"></g>
                                                <g id="SvgjsG1203" class="apexcharts-datalabels"></g>
                                                <g id="SvgjsG1217" class="apexcharts-datalabels"></g>
                                            </g>
                                            <line id="SvgjsLine1307" x1="0" y1="0" x2="700.5625" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" class="apexcharts-ycrosshairs"></line>
                                            <line id="SvgjsLine1308" x1="0" y1="0" x2="700.5625" y2="0" stroke-dasharray="0" stroke-width="0" class="apexcharts-ycrosshairs-hidden"></line>
                                            <g id="SvgjsG1309" class="apexcharts-yaxis-annotations" clip-path="url(#gridRectMask3ba4a3)"></g>
                                            <g id="SvgjsG1310" class="apexcharts-xaxis-annotations" clip-path="url(#gridRectMask3ba4a3)"></g>
                                            <g id="SvgjsG1311" class="apexcharts-point-annotations" clip-path="url(#gridRectMask3ba4a3)"></g>
                                        </g>
                                        <g id="SvgjsG1269" class="apexcharts-yaxis" rel="0" transform="translate(14.4375, 0)">
                                            <g id="SvgjsG1270" class="apexcharts-yaxis-texts-g"><text id="SvgjsText1271" font-family="Helvetica, Arial, sans-serif" x="20" y="41.5" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1272">100</tspan>
                                                </text><text id="SvgjsText1273" font-family="Helvetica, Arial, sans-serif" x="20" y="92.7988" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1274">80</tspan>
                                                </text><text id="SvgjsText1275" font-family="Helvetica, Arial, sans-serif" x="20" y="144.0976" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1276">60</tspan>
                                                </text><text id="SvgjsText1277" font-family="Helvetica, Arial, sans-serif" x="20" y="195.3964" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1278">40</tspan>
                                                </text><text id="SvgjsText1279" font-family="Helvetica, Arial, sans-serif" x="20" y="246.6952" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1280">20</tspan>
                                                </text><text id="SvgjsText1281" font-family="Helvetica, Arial, sans-serif" x="20" y="297.994" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1282">0</tspan>
                                                </text></g>
                                        </g>
                                    </svg>
                                    <div class="apexcharts-tooltip apexcharts-theme-light">
                                        <div class="apexcharts-tooltip-title" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;"></div>
                                        <div class="apexcharts-tooltip-series-group"><span class="apexcharts-tooltip-marker" style="background-color: rgb(85, 110, 230);"></span>
                                            <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                <div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-label"></span><span class="apexcharts-tooltip-text-value"></span></div>
                                                <div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div>
                                            </div>
                                        </div>
                                        <div class="apexcharts-tooltip-series-group"><span class="apexcharts-tooltip-marker" style="background-color: rgb(241, 180, 76);"></span>
                                            <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                <div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-label"></span><span class="apexcharts-tooltip-text-value"></span></div>
                                                <div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div>
                                            </div>
                                        </div>
                                        <div class="apexcharts-tooltip-series-group"><span class="apexcharts-tooltip-marker" style="background-color: rgb(52, 195, 143);"></span>
                                            <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                <div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-label"></span><span class="apexcharts-tooltip-text-value"></span></div>
                                                <div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="resize-triggers">
                                <div class="expand-trigger">
                                    <div style="width: 796px; height: 442px;"></div>
                                </div>
                                <div class="contract-trigger"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="font-size-18 card-title mb-3">Reshareed Posts</h4>

                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Phone / Email</th>
                                            <th>Type</th>

                                            <th>Share No</th>
                                            <th>Rating</th>
                                            <th>Share Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                    <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td>Stephen Rash</td>
                                            <td>
                                                <p class="mb-1">325-250-1106</p>
                                                <p class="mb-0">StephenRash@teleworm.us</p>
                                            </td>

                                            <td>Video</td>
                                            <td>7</td>
                                            <td><span class="badge badge-success font-size-12"><i class="mdi mdi-star mr-1"></i> 4.2</span></td>

                                            <td>07 Oct, 2019</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="mdi mdi-dots-horizontal font-size-18"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-pencil font-size-16 text-success mr-1"></i> Edit</a></li>
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-trash-can font-size-16 text-danger mr-1"></i> Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <h4 class="font-size-18 card-title mb-3">Top Posts</h4>
                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Type</th>
                                            <th>Views</th>
                                            <th>Comments</th>
                                            <th>Like</th>
                                            <th>Share No</th>
                                            <th>Rating</th>
                                            <th>Share Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                    <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td>Stephen Rash</td>


                                            <td>Video</td>
                                            <td>
                                                1000
                                            </td>
                                            <td>150</td>
                                            <td>725</td>
                                            <td>7</td>
                                            <td><span class="badge badge-success font-size-12"><i class="mdi mdi-star mr-1"></i> 4.2</span></td>

                                            <td>07 Oct, 2019</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="mdi mdi-dots-horizontal font-size-18"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-pencil font-size-16 text-success mr-1"></i> Edit</a></li>
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-trash-can font-size-16 text-danger mr-1"></i> Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="font-size-18 card-title mb-3">Top Commenteds Posts</h4>

                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Phone / Email</th>
                                            <th>Type</th>
                                            <th>Comments</th>
                                            <th>Rating</th>
                                            <th>Share Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                    <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td>Stephen Rash</td>
                                            <td>
                                                <p class="mb-1">325-250-1106</p>
                                                <p class="mb-0">StephenRash@teleworm.us</p>
                                            </td>

                                            <td>Images</td>
                                            <td>700</td>
                                            <td><span class="badge badge-success font-size-12"><i class="mdi mdi-star mr-1"></i> 4.2</span></td>

                                            <td>07 Oct, 2019</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="mdi mdi-dots-horizontal font-size-18"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-pencil font-size-16 text-success mr-1"></i> Edit</a></li>
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-trash-can font-size-16 text-danger mr-1"></i> Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="font-size-18 card-title mb-3">Top like and dislike</h4>

                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Phone / Email</th>
                                            <th>Type</th>
                                            <th>Like</th>
                                            <th>Dislike</th>
                                            <th>Share Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                    <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td>Stephen Rash</td>
                                            <td>
                                                <p class="mb-1">325-250-1106</p>
                                                <p class="mb-0">StephenRash@teleworm.us</p>
                                            </td>

                                            <td>Images</td>
                                            <td>700</td>
                                            <td>500</td>
                                            <td>07 Oct, 2019</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="mdi mdi-dots-horizontal font-size-18"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-pencil font-size-16 text-success mr-1"></i> Edit</a></li>
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-trash-can font-size-16 text-danger mr-1"></i> Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="font-size-18 card-title mb-3">Top Views</h4>

                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Phone / Email</th>
                                            <th>Type</th>
                                            <th>Age</th>
                                            <th>Location</th>
                                            <th>Time</th>
                                            <th>Share Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                    <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td>Stephen Rash</td>
                                            <td>
                                                <p class="mb-1">325-250-1106</p>
                                                <p class="mb-0">StephenRash@teleworm.us</p>
                                            </td>

                                            <td>text</td>
                                            <td>23</td>
                                            <td>Mumbai</td>
                                            <td>9:27am</td>
                                            <td>07 Oct, 2019</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="mdi mdi-dots-horizontal font-size-18"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-pencil font-size-16 text-success mr-1"></i> Edit</a></li>
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-trash-can font-size-16 text-danger mr-1"></i> Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="font-size-18 card-title mb-3">Top Share</h4>

                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Phone / Email</th>
                                            <th>Type</th>
                                            <th>Share</th>
                                            <th>Reshare</th>
                                            <th>Share Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                    <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td>Stephen Rash</td>
                                            <td>
                                                <p class="mb-1">325-250-1106</p>
                                                <p class="mb-0">StephenRash@teleworm.us</p>
                                            </td>

                                            <td>Images</td>
                                            <td>700</td>
                                            <td>245</td>
                                            <td>07 Oct, 2019</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="mdi mdi-dots-horizontal font-size-18"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-pencil font-size-16 text-success mr-1"></i> Edit</a></li>
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-trash-can font-size-16 text-danger mr-1"></i> Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="font-size-18 card-title mb-3">Top views</h4>

                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Username</th>
                                            <th>Phone / Email</th>
                                            <th>Post</th>
                                            <th>Visited</th>
                                            <th>Rating</th>
                                            <th>Open Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                                    <label class="custom-control-label" for="customCheck1">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td>Stephen Rash</td>
                                            <td>
                                                <p class="mb-1">325-250-1106</p>
                                                <p class="mb-0">StephenRash@teleworm.us</p>
                                            </td>

                                            <td>14</td>
                                            <td>700</td>
                                            <td><span class="badge badge-success font-size-12"><i class="mdi mdi-star mr-1"></i> 4.2</span></td>

                                            <td>07 Oct, 2019</td>
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="mdi mdi-dots-horizontal font-size-18"></i>
                                                    </a>
                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-pencil font-size-16 text-success mr-1"></i> Edit</a></li>
                                                        <li><a href="#" class="dropdown-item"><i class="mdi mdi-trash-can font-size-16 text-danger mr-1"></i> Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-4">Total Job Request</h4>

                        <div class="text-center">
                            <div class="mb-4">
                                <i class="bx bx-map-pin text-primary display-4"></i>
                            </div>
                            <h3>1,456</h3>
                            <p>Total Job Request</p>
                        </div>

                        <div class="table-responsive mt-4">
                            <table class="table table-centered table-nowrap">
                                <tbody>
                                    <tr>
                                        <td style="width: 30%">
                                            <p class="mb-0">Total Place</p>
                                        </td>
                                        <td style="width: 25%">
                                            <h5 class="mb-0">1500</h5>
                                        </td>
                                        <td>
                                            <div class="progress bg-transparent progress-sm">
                                                <div class="progress-bar bg-primary rounded" role="progressbar" style="width: 94%" aria-valuenow="94" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="mb-0">Saved Jobs</p>
                                        </td>
                                        <td>
                                            <h5 class="mb-0">1,123</h5>
                                        </td>
                                        <td>
                                            <div class="progress bg-transparent progress-sm">
                                                <div class="progress-bar bg-success rounded" role="progressbar" style="width: 82%" aria-valuenow="82" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="mb-0">Applied Jobs</p>
                                        </td>
                                        <td>
                                            <h5 class="mb-0">1,026</h5>
                                        </td>
                                        <td>
                                            <div class="progress bg-transparent progress-sm">
                                                <div class="progress-bar bg-warning rounded" role="progressbar" style="width: 70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-3">Overview</h4>

                    <div style="position: relative;">
                        <div id="overview-chart" class="apex-charts" dir="ltr" style="min-height: 255px;">
                            <div id="apexcharts1e5ca9" class="apexcharts-canvas apexcharts1e5ca9 apexcharts-theme-light apexcharts-zoomable" style="width: 755px; height: 240px;"><svg id="SvgjsSvg2088" width="755" height="240" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" class="apexcharts-svg hovering-zoom" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;">
                                    <foreignObject x="0" y="0" width="755" height="240">
                                        <div class="apexcharts-legend apexcharts-align-center position-bottom" xmlns="http://www.w3.org/1999/xhtml" style="inset: auto 0px 5px; position: absolute;">
                                            <div class="apexcharts-legend-series" rel="1" data:collapsed="false" style="margin: 0px 5px;"><span class="apexcharts-legend-marker" rel="1" data:collapsed="false" style="background: rgb(241, 180, 76); color: rgb(241, 180, 76); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;"></span><span class="apexcharts-legend-text" rel="1" i="0" data:default-text="BTC" data:collapsed="false" style="color: rgb(55, 61, 63); font-size: 12px; font-family: Helvetica, Arial, sans-serif;">BTC</span></div>
                                            <div class="apexcharts-legend-series" rel="2" data:collapsed="false" style="margin: 0px 5px;"><span class="apexcharts-legend-marker" rel="2" data:collapsed="false" style="background: rgb(52, 82, 225); color: rgb(52, 82, 225); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;"></span><span class="apexcharts-legend-text" rel="2" i="1" data:default-text="ETH" data:collapsed="false" style="color: rgb(55, 61, 63); font-size: 12px; font-family: Helvetica, Arial, sans-serif;">ETH</span></div>
                                            <div class="apexcharts-legend-series" rel="3" data:collapsed="false" style="margin: 0px 5px;"><span class="apexcharts-legend-marker" rel="3" data:collapsed="false" style="background: rgb(80, 165, 241); color: rgb(80, 165, 241); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;"></span><span class="apexcharts-legend-text" rel="3" i="2" data:default-text="LTC" data:collapsed="false" style="color: rgb(55, 61, 63); font-size: 12px; font-family: Helvetica, Arial, sans-serif;">LTC</span></div>
                                        </div>
                                        <style type="text/css">
                                            .apexcharts-legend {
                                                display: flex;
                                                overflow: auto;
                                                padding: 0 10px;
                                            }

                                            .apexcharts-legend.position-bottom,
                                            .apexcharts-legend.position-top {
                                                flex-wrap: wrap
                                            }

                                            .apexcharts-legend.position-right,
                                            .apexcharts-legend.position-left {
                                                flex-direction: column;
                                                bottom: 0;
                                            }

                                            .apexcharts-legend.position-bottom.apexcharts-align-left,
                                            .apexcharts-legend.position-top.apexcharts-align-left,
                                            .apexcharts-legend.position-right,
                                            .apexcharts-legend.position-left {
                                                justify-content: flex-start;
                                            }

                                            .apexcharts-legend.position-bottom.apexcharts-align-center,
                                            .apexcharts-legend.position-top.apexcharts-align-center {
                                                justify-content: center;
                                            }

                                            .apexcharts-legend.position-bottom.apexcharts-align-right,
                                            .apexcharts-legend.position-top.apexcharts-align-right {
                                                justify-content: flex-end;
                                            }

                                            .apexcharts-legend-series {
                                                cursor: pointer;
                                                line-height: normal;
                                            }

                                            .apexcharts-legend.position-bottom .apexcharts-legend-series,
                                            .apexcharts-legend.position-top .apexcharts-legend-series {
                                                display: flex;
                                                align-items: center;
                                            }

                                            .apexcharts-legend-text {
                                                position: relative;
                                                font-size: 14px;
                                            }

                                            .apexcharts-legend-text *,
                                            .apexcharts-legend-marker * {
                                                pointer-events: none;
                                            }

                                            .apexcharts-legend-marker {
                                                position: relative;
                                                display: inline-block;
                                                cursor: pointer;
                                                margin-right: 3px;
                                            }

                                            .apexcharts-legend.apexcharts-align-right .apexcharts-legend-series,
                                            .apexcharts-legend.apexcharts-align-left .apexcharts-legend-series {
                                                display: inline-block;
                                            }

                                            .apexcharts-legend-series.apexcharts-no-click {
                                                cursor: auto;
                                            }

                                            .apexcharts-legend .apexcharts-hidden-zero-series,
                                            .apexcharts-legend .apexcharts-hidden-null-series {
                                                display: none !important;
                                            }

                                            .apexcharts-inactive-legend {
                                                opacity: 0.45;
                                            }
                                        </style>
                                    </foreignObject>
                                    <g id="SvgjsG2090" class="apexcharts-inner apexcharts-graphical" transform="translate(44.4375, 40)">
                                        <defs id="SvgjsDefs2089">
                                            <clipPath id="gridRectMask1e5ca9">
                                                <rect id="SvgjsRect2095" width="693.59375" height="139.494" x="-3" y="-1" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                            </clipPath>
                                            <clipPath id="gridRectMarkerMask1e5ca9">
                                                <rect id="SvgjsRect2096" width="689.59375" height="139.494" x="-1" y="-1" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                            </clipPath>
                                        </defs>
                                        <line id="SvgjsLine2094" x1="249.53409090909088" y1="0" x2="249.53409090909088" y2="137.494" stroke="#b6b6b6" stroke-dasharray="3" class="apexcharts-xcrosshairs" x="249.53409090909088" y="0" width="1" height="137.494" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line>
                                        <g id="SvgjsG2114" class="apexcharts-xaxis" transform="translate(0, 0)">
                                            <g id="SvgjsG2115" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"><text id="SvgjsText2117" font-family="Helvetica, Arial, sans-serif" x="0" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2118">Jan</tspan>
                                                    <title>Jan</title>
                                                </text><text id="SvgjsText2120" font-family="Helvetica, Arial, sans-serif" x="62.508522727272734" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2121">Feb</tspan>
                                                    <title>Feb</title>
                                                </text><text id="SvgjsText2123" font-family="Helvetica, Arial, sans-serif" x="125.01704545454545" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2124">Mar</tspan>
                                                    <title>Mar</title>
                                                </text><text id="SvgjsText2126" font-family="Helvetica, Arial, sans-serif" x="187.52556818181816" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2127">Apr</tspan>
                                                    <title>Apr</title>
                                                </text><text id="SvgjsText2129" font-family="Helvetica, Arial, sans-serif" x="250.03409090909088" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2130">May</tspan>
                                                    <title>May</title>
                                                </text><text id="SvgjsText2132" font-family="Helvetica, Arial, sans-serif" x="312.5426136363636" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2133">Jun</tspan>
                                                    <title>Jun</title>
                                                </text><text id="SvgjsText2135" font-family="Helvetica, Arial, sans-serif" x="375.0511363636364" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2136">Jul</tspan>
                                                    <title>Jul</title>
                                                </text><text id="SvgjsText2138" font-family="Helvetica, Arial, sans-serif" x="437.5596590909091" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2139">Aug</tspan>
                                                    <title>Aug</title>
                                                </text><text id="SvgjsText2141" font-family="Helvetica, Arial, sans-serif" x="500.06818181818187" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2142">Sep</tspan>
                                                    <title>Sep</title>
                                                </text><text id="SvgjsText2144" font-family="Helvetica, Arial, sans-serif" x="562.5767045454546" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2145">Oct</tspan>
                                                    <title>Oct</title>
                                                </text><text id="SvgjsText2147" font-family="Helvetica, Arial, sans-serif" x="625.0852272727274" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2148">Nov</tspan>
                                                    <title>Nov</title>
                                                </text><text id="SvgjsText2150" font-family="Helvetica, Arial, sans-serif" x="687.5937500000001" y="166.494" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan2151">Dec</tspan>
                                                    <title>Dec</title>
                                                </text></g>
                                            <line id="SvgjsLine2152" x1="0" y1="138.494" x2="687.59375" y2="138.494" stroke="#e0e0e0" stroke-dasharray="0" stroke-width="1"></line>
                                        </g>
                                        <g id="SvgjsG2167" class="apexcharts-grid">
                                            <g id="SvgjsG2168" class="apexcharts-gridlines-horizontal">
                                                <line id="SvgjsLine2182" x1="0" y1="0" x2="687.59375" y2="0" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                <line id="SvgjsLine2183" x1="0" y1="27.4988" x2="687.59375" y2="27.4988" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                <line id="SvgjsLine2184" x1="0" y1="54.9976" x2="687.59375" y2="54.9976" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                <line id="SvgjsLine2185" x1="0" y1="82.4964" x2="687.59375" y2="82.4964" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                <line id="SvgjsLine2186" x1="0" y1="109.9952" x2="687.59375" y2="109.9952" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                <line id="SvgjsLine2187" x1="0" y1="137.494" x2="687.59375" y2="137.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                            </g>
                                            <g id="SvgjsG2169" class="apexcharts-gridlines-vertical"></g>
                                            <line id="SvgjsLine2170" x1="0" y1="138.494" x2="0" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2171" x1="62.50852272727273" y1="138.494" x2="62.50852272727273" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2172" x1="125.01704545454545" y1="138.494" x2="125.01704545454545" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2173" x1="187.5255681818182" y1="138.494" x2="187.5255681818182" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2174" x1="250.0340909090909" y1="138.494" x2="250.0340909090909" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2175" x1="312.5426136363636" y1="138.494" x2="312.5426136363636" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2176" x1="375.0511363636364" y1="138.494" x2="375.0511363636364" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2177" x1="437.5596590909091" y1="138.494" x2="437.5596590909091" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2178" x1="500.06818181818187" y1="138.494" x2="500.06818181818187" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2179" x1="562.5767045454546" y1="138.494" x2="562.5767045454546" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2180" x1="625.0852272727274" y1="138.494" x2="625.0852272727274" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2181" x1="687.5937500000001" y1="138.494" x2="687.5937500000001" y2="144.494" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                            <line id="SvgjsLine2189" x1="0" y1="137.494" x2="687.59375" y2="137.494" stroke="transparent" stroke-dasharray="0"></line>
                                            <line id="SvgjsLine2188" x1="0" y1="1" x2="0" y2="137.494" stroke="transparent" stroke-dasharray="0"></line>
                                        </g>
                                        <g id="SvgjsG2098" class="apexcharts-area-series apexcharts-plot-series">
                                            <g id="SvgjsG2104" class="apexcharts-series" seriesName="ETH" data:longestSeries="true" rel="2" data:realIndex="1">
                                                <path id="SvgjsPath2107" d="M 0 137.494L 0 98.99568C 21.877982954545452 98.99568 40.63053977272727 81.12146 62.50852272727272 81.12146C 84.38650568181816 81.12146 103.1390625 65.99712 125.01704545454544 65.99712C 146.89502840909088 65.99712 165.6475852272727 79.74652 187.52556818181816 79.74652C 209.4035511363636 79.74652 228.15610795454543 119.61977999999999 250.03409090909088 119.61977999999999C 271.91207386363635 119.61977999999999 290.66463068181815 112.74508 312.5426136363636 112.74508C 334.42059659090904 112.74508 353.1731534090909 97.62074 375.0511363636363 97.62074C 396.9291193181818 97.62074 415.6816761363636 112.74508 437.55965909090907 112.74508C 459.4376420454545 112.74508 478.19019886363634 87.99616 500.06818181818176 87.99616C 521.9461647727272 87.99616 540.698721590909 67.37206 562.5767045454545 67.37206C 584.4546875 67.37206 603.2072443181818 61.872299999999996 625.0852272727273 61.872299999999996C 646.9632102272727 61.872299999999996 665.7157670454545 89.3711 687.59375 89.3711C 687.59375 89.3711 687.59375 89.3711 687.59375 137.494M 687.59375 89.3711z" fill="rgba(52,82,225,0.05)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-area" index="1" clip-path="url(#gridRectMask1e5ca9)" pathTo="M 0 137.494L 0 98.99568C 21.877982954545452 98.99568 40.63053977272727 81.12146 62.50852272727272 81.12146C 84.38650568181816 81.12146 103.1390625 65.99712 125.01704545454544 65.99712C 146.89502840909088 65.99712 165.6475852272727 79.74652 187.52556818181816 79.74652C 209.4035511363636 79.74652 228.15610795454543 119.61977999999999 250.03409090909088 119.61977999999999C 271.91207386363635 119.61977999999999 290.66463068181815 112.74508 312.5426136363636 112.74508C 334.42059659090904 112.74508 353.1731534090909 97.62074 375.0511363636363 97.62074C 396.9291193181818 97.62074 415.6816761363636 112.74508 437.55965909090907 112.74508C 459.4376420454545 112.74508 478.19019886363634 87.99616 500.06818181818176 87.99616C 521.9461647727272 87.99616 540.698721590909 67.37206 562.5767045454545 67.37206C 584.4546875 67.37206 603.2072443181818 61.872299999999996 625.0852272727273 61.872299999999996C 646.9632102272727 61.872299999999996 665.7157670454545 89.3711 687.59375 89.3711C 687.59375 89.3711 687.59375 89.3711 687.59375 137.494M 687.59375 89.3711z" pathFrom="M 0 137.494L 0 105.41206666666668C 21.89637784090909 105.41206666666668 40.66470170454546 90.51688333333334 62.56107954545455 90.51688333333334C 84.45745738636364 90.51688333333334 103.22578125000001 77.91326666666666 125.1221590909091 77.91326666666666C 147.01853693181818 77.91326666666666 165.78686079545457 89.3711 187.68323863636365 89.3711C 209.57961647727274 89.3711 228.3479403409091 122.59881666666666 250.2443181818182 122.59881666666666C 272.1406960227273 122.59881666666666 290.90901988636364 116.8699 312.80539772727275 116.8699C 334.70177556818186 116.8699 353.4700994318182 104.26628333333333 375.3664772727273 104.26628333333333C 397.26285511363636 104.26628333333333 416.03117897727276 116.8699 437.9275568181818 116.8699C 459.8239346590909 116.8699 478.59225852272726 96.2458 500.4886363636364 96.2458C 522.3850142045455 96.2458 541.1533380681818 79.05905 563.049715909091 79.05905C 584.94609375 79.05905 603.7144176136364 74.47591666666666 625.6107954545455 74.47591666666666C 647.5071732954545 74.47591666666666 666.275497159091 97.39158333333333 688.171875 97.39158333333333C 688.171875 97.39158333333333 688.171875 97.39158333333333 688.171875 137.494M 688.171875 97.39158333333333z"></path>
                                                <path id="SvgjsPath2108" d="M 0 98.99568C 21.877982954545452 98.99568 40.63053977272727 81.12146 62.50852272727272 81.12146C 84.38650568181816 81.12146 103.1390625 65.99712 125.01704545454544 65.99712C 146.89502840909088 65.99712 165.6475852272727 79.74652 187.52556818181816 79.74652C 209.4035511363636 79.74652 228.15610795454543 119.61977999999999 250.03409090909088 119.61977999999999C 271.91207386363635 119.61977999999999 290.66463068181815 112.74508 312.5426136363636 112.74508C 334.42059659090904 112.74508 353.1731534090909 97.62074 375.0511363636363 97.62074C 396.9291193181818 97.62074 415.6816761363636 112.74508 437.55965909090907 112.74508C 459.4376420454545 112.74508 478.19019886363634 87.99616 500.06818181818176 87.99616C 521.9461647727272 87.99616 540.698721590909 67.37206 562.5767045454545 67.37206C 584.4546875 67.37206 603.2072443181818 61.872299999999996 625.0852272727273 61.872299999999996C 646.9632102272727 61.872299999999996 665.7157670454545 89.3711 687.59375 89.3711" fill="none" fill-opacity="1" stroke="#3452e1" stroke-opacity="1" stroke-linecap="butt" stroke-width="2" stroke-dasharray="0" class="apexcharts-area" index="1" clip-path="url(#gridRectMask1e5ca9)" pathTo="M 0 98.99568C 21.877982954545452 98.99568 40.63053977272727 81.12146 62.50852272727272 81.12146C 84.38650568181816 81.12146 103.1390625 65.99712 125.01704545454544 65.99712C 146.89502840909088 65.99712 165.6475852272727 79.74652 187.52556818181816 79.74652C 209.4035511363636 79.74652 228.15610795454543 119.61977999999999 250.03409090909088 119.61977999999999C 271.91207386363635 119.61977999999999 290.66463068181815 112.74508 312.5426136363636 112.74508C 334.42059659090904 112.74508 353.1731534090909 97.62074 375.0511363636363 97.62074C 396.9291193181818 97.62074 415.6816761363636 112.74508 437.55965909090907 112.74508C 459.4376420454545 112.74508 478.19019886363634 87.99616 500.06818181818176 87.99616C 521.9461647727272 87.99616 540.698721590909 67.37206 562.5767045454545 67.37206C 584.4546875 67.37206 603.2072443181818 61.872299999999996 625.0852272727273 61.872299999999996C 646.9632102272727 61.872299999999996 665.7157670454545 89.3711 687.59375 89.3711" pathFrom="M 0 105.41206666666668C 21.89637784090909 105.41206666666668 40.66470170454546 90.51688333333334 62.56107954545455 90.51688333333334C 84.45745738636364 90.51688333333334 103.22578125000001 77.91326666666666 125.1221590909091 77.91326666666666C 147.01853693181818 77.91326666666666 165.78686079545457 89.3711 187.68323863636365 89.3711C 209.57961647727274 89.3711 228.3479403409091 122.59881666666666 250.2443181818182 122.59881666666666C 272.1406960227273 122.59881666666666 290.90901988636364 116.8699 312.80539772727275 116.8699C 334.70177556818186 116.8699 353.4700994318182 104.26628333333333 375.3664772727273 104.26628333333333C 397.26285511363636 104.26628333333333 416.03117897727276 116.8699 437.9275568181818 116.8699C 459.8239346590909 116.8699 478.59225852272726 96.2458 500.4886363636364 96.2458C 522.3850142045455 96.2458 541.1533380681818 79.05905 563.049715909091 79.05905C 584.94609375 79.05905 603.7144176136364 74.47591666666666 625.6107954545455 74.47591666666666C 647.5071732954545 74.47591666666666 666.275497159091 97.39158333333333 688.171875 97.39158333333333"></path>
                                                <g id="SvgjsG2105" class="apexcharts-series-markers-wrap">
                                                    <g class="apexcharts-series-markers">
                                                        <circle id="SvgjsCircle2195" r="0" cx="250.03409090909088" cy="119.61977999999999" class="apexcharts-marker wtr17pmasf" stroke="#ffffff" fill="#3452e1" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle>
                                                    </g>
                                                </g>
                                            </g>
                                            <g id="SvgjsG2099" class="apexcharts-series" seriesName="BTC" data:longestSeries="true" rel="1" data:realIndex="0">
                                                <path id="SvgjsPath2102" d="M 0 137.494L 0 17.874219999999994C 21.877982954545452 17.874219999999994 40.63053977272727 59.122420000000005 62.50852272727272 59.122420000000005C 84.38650568181816 59.122420000000005 103.1390625 35.74844 125.01704545454544 35.74844C 146.89502840909088 35.74844 165.6475852272727 1.3749400000000094 187.52556818181816 1.3749400000000094C 209.4035511363636 1.3749400000000094 228.15610795454543 34.37349999999999 250.03409090909088 34.37349999999999C 271.91207386363635 34.37349999999999 290.66463068181815 85.24628 312.5426136363636 85.24628C 334.42059659090904 85.24628 353.1731534090909 52.24772 375.0511363636363 52.24772C 396.9291193181818 52.24772 415.6816761363636 72.87182 437.55965909090907 72.87182C 459.4376420454545 72.87182 478.19019886363634 24.74892 500.06818181818176 24.74892C 521.9461647727272 24.74892 540.698721590909 60.49736 562.5767045454545 60.49736C 584.4546875 60.49736 603.2072443181818 75.6217 625.0852272727273 75.6217C 646.9632102272727 75.6217 665.7157670454545 72.87182 687.59375 72.87182C 687.59375 72.87182 687.59375 72.87182 687.59375 137.494M 687.59375 72.87182z" fill="rgba(241,180,76,0.15)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-area" index="0" clip-path="url(#gridRectMask1e5ca9)" pathTo="M 0 137.494L 0 17.874219999999994C 21.877982954545452 17.874219999999994 40.63053977272727 59.122420000000005 62.50852272727272 59.122420000000005C 84.38650568181816 59.122420000000005 103.1390625 35.74844 125.01704545454544 35.74844C 146.89502840909088 35.74844 165.6475852272727 1.3749400000000094 187.52556818181816 1.3749400000000094C 209.4035511363636 1.3749400000000094 228.15610795454543 34.37349999999999 250.03409090909088 34.37349999999999C 271.91207386363635 34.37349999999999 290.66463068181815 85.24628 312.5426136363636 85.24628C 334.42059659090904 85.24628 353.1731534090909 52.24772 375.0511363636363 52.24772C 396.9291193181818 52.24772 415.6816761363636 72.87182 437.55965909090907 72.87182C 459.4376420454545 72.87182 478.19019886363634 24.74892 500.06818181818176 24.74892C 521.9461647727272 24.74892 540.698721590909 60.49736 562.5767045454545 60.49736C 584.4546875 60.49736 603.2072443181818 75.6217 625.0852272727273 75.6217C 646.9632102272727 75.6217 665.7157670454545 72.87182 687.59375 72.87182C 687.59375 72.87182 687.59375 72.87182 687.59375 137.494M 687.59375 72.87182z" pathFrom="M 0 137.494L 0 37.81085C 21.89637784090909 37.81085 40.66470170454546 72.18435 62.56107954545455 72.18435C 84.45745738636364 72.18435 103.22578125000001 52.70603333333334 125.1221590909091 52.70603333333334C 147.01853693181818 52.70603333333334 165.78686079545457 24.061449999999994 187.68323863636365 24.061449999999994C 209.57961647727274 24.061449999999994 228.3479403409091 51.560249999999996 250.2443181818182 51.560249999999996C 272.1406960227273 51.560249999999996 290.90901988636364 93.95423333333333 312.80539772727275 93.95423333333333C 334.70177556818186 93.95423333333333 353.4700994318182 66.45543333333333 375.3664772727273 66.45543333333333C 397.26285511363636 66.45543333333333 416.03117897727276 83.64218333333334 437.9275568181818 83.64218333333334C 459.8239346590909 83.64218333333334 478.59225852272726 43.539766666666665 500.4886363636364 43.539766666666665C 522.3850142045455 43.539766666666665 541.1533380681818 73.33013333333334 563.049715909091 73.33013333333334C 584.94609375 73.33013333333334 603.7144176136364 85.93375 625.6107954545455 85.93375C 647.5071732954545 85.93375 666.275497159091 83.64218333333334 688.171875 83.64218333333334C 688.171875 83.64218333333334 688.171875 83.64218333333334 688.171875 137.494M 688.171875 83.64218333333334z"></path>
                                                <path id="SvgjsPath2103" d="M 0 17.874219999999994C 21.877982954545452 17.874219999999994 40.63053977272727 59.122420000000005 62.50852272727272 59.122420000000005C 84.38650568181816 59.122420000000005 103.1390625 35.74844 125.01704545454544 35.74844C 146.89502840909088 35.74844 165.6475852272727 1.3749400000000094 187.52556818181816 1.3749400000000094C 209.4035511363636 1.3749400000000094 228.15610795454543 34.37349999999999 250.03409090909088 34.37349999999999C 271.91207386363635 34.37349999999999 290.66463068181815 85.24628 312.5426136363636 85.24628C 334.42059659090904 85.24628 353.1731534090909 52.24772 375.0511363636363 52.24772C 396.9291193181818 52.24772 415.6816761363636 72.87182 437.55965909090907 72.87182C 459.4376420454545 72.87182 478.19019886363634 24.74892 500.06818181818176 24.74892C 521.9461647727272 24.74892 540.698721590909 60.49736 562.5767045454545 60.49736C 584.4546875 60.49736 603.2072443181818 75.6217 625.0852272727273 75.6217C 646.9632102272727 75.6217 665.7157670454545 72.87182 687.59375 72.87182" fill="none" fill-opacity="1" stroke="#f1b44c" stroke-opacity="1" stroke-linecap="butt" stroke-width="2" stroke-dasharray="0" class="apexcharts-area" index="0" clip-path="url(#gridRectMask1e5ca9)" pathTo="M 0 17.874219999999994C 21.877982954545452 17.874219999999994 40.63053977272727 59.122420000000005 62.50852272727272 59.122420000000005C 84.38650568181816 59.122420000000005 103.1390625 35.74844 125.01704545454544 35.74844C 146.89502840909088 35.74844 165.6475852272727 1.3749400000000094 187.52556818181816 1.3749400000000094C 209.4035511363636 1.3749400000000094 228.15610795454543 34.37349999999999 250.03409090909088 34.37349999999999C 271.91207386363635 34.37349999999999 290.66463068181815 85.24628 312.5426136363636 85.24628C 334.42059659090904 85.24628 353.1731534090909 52.24772 375.0511363636363 52.24772C 396.9291193181818 52.24772 415.6816761363636 72.87182 437.55965909090907 72.87182C 459.4376420454545 72.87182 478.19019886363634 24.74892 500.06818181818176 24.74892C 521.9461647727272 24.74892 540.698721590909 60.49736 562.5767045454545 60.49736C 584.4546875 60.49736 603.2072443181818 75.6217 625.0852272727273 75.6217C 646.9632102272727 75.6217 665.7157670454545 72.87182 687.59375 72.87182" pathFrom="M 0 37.81085C 21.89637784090909 37.81085 40.66470170454546 72.18435 62.56107954545455 72.18435C 84.45745738636364 72.18435 103.22578125000001 52.70603333333334 125.1221590909091 52.70603333333334C 147.01853693181818 52.70603333333334 165.78686079545457 24.061449999999994 187.68323863636365 24.061449999999994C 209.57961647727274 24.061449999999994 228.3479403409091 51.560249999999996 250.2443181818182 51.560249999999996C 272.1406960227273 51.560249999999996 290.90901988636364 93.95423333333333 312.80539772727275 93.95423333333333C 334.70177556818186 93.95423333333333 353.4700994318182 66.45543333333333 375.3664772727273 66.45543333333333C 397.26285511363636 66.45543333333333 416.03117897727276 83.64218333333334 437.9275568181818 83.64218333333334C 459.8239346590909 83.64218333333334 478.59225852272726 43.539766666666665 500.4886363636364 43.539766666666665C 522.3850142045455 43.539766666666665 541.1533380681818 73.33013333333334 563.049715909091 73.33013333333334C 584.94609375 73.33013333333334 603.7144176136364 85.93375 625.6107954545455 85.93375C 647.5071732954545 85.93375 666.275497159091 83.64218333333334 688.171875 83.64218333333334"></path>
                                                <g id="SvgjsG2100" class="apexcharts-series-markers-wrap">
                                                    <g class="apexcharts-series-markers">
                                                        <circle id="SvgjsCircle2196" r="0" cx="250.03409090909088" cy="34.37349999999999" class="apexcharts-marker we6erhhjr" stroke="#ffffff" fill="#f1b44c" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle>
                                                    </g>
                                                </g>
                                            </g>
                                        </g>
                                        <g id="SvgjsG2109" class="apexcharts-line-series apexcharts-plot-series">
                                            <g id="SvgjsG2110" class="apexcharts-series" seriesName="LTC" data:longestSeries="true" rel="1" data:realIndex="2">
                                                <path id="SvgjsPath2113" d="M 0 75.6217C 21.877982954545452 75.6217 40.63053977272727 65.99712 62.50852272727272 65.99712C 84.38650568181816 65.99712 103.1390625 85.24628 125.01704545454544 85.24628C 146.89502840909088 85.24628 165.6475852272727 104.49544 187.52556818181816 104.49544C 209.4035511363636 104.49544 228.15610795454543 92.12098 250.03409090909088 92.12098C 271.91207386363635 92.12098 290.66463068181815 48.1229 312.5426136363636 48.1229C 334.42059659090904 48.1229 353.1731534090909 75.6217 375.0511363636363 75.6217C 396.9291193181818 75.6217 415.6816761363636 34.37349999999999 437.55965909090907 34.37349999999999C 459.4376420454545 34.37349999999999 478.19019886363634 63.247240000000005 500.06818181818176 63.247240000000005C 521.9461647727272 63.247240000000005 540.698721590909 112.74508 562.5767045454545 112.74508C 584.4546875 112.74508 603.2072443181818 98.99568 625.0852272727273 98.99568C 646.9632102272727 98.99568 665.7157670454545 123.7446 687.59375 123.7446" fill="none" fill-opacity="1" stroke="rgba(80,165,241,1)" stroke-opacity="1" stroke-linecap="butt" stroke-width="2" stroke-dasharray="3" class="apexcharts-line" index="2" clip-path="url(#gridRectMask1e5ca9)" pathTo="M 0 75.6217C 21.877982954545452 75.6217 40.63053977272727 65.99712 62.50852272727272 65.99712C 84.38650568181816 65.99712 103.1390625 85.24628 125.01704545454544 85.24628C 146.89502840909088 85.24628 165.6475852272727 104.49544 187.52556818181816 104.49544C 209.4035511363636 104.49544 228.15610795454543 92.12098 250.03409090909088 92.12098C 271.91207386363635 92.12098 290.66463068181815 48.1229 312.5426136363636 48.1229C 334.42059659090904 48.1229 353.1731534090909 75.6217 375.0511363636363 75.6217C 396.9291193181818 75.6217 415.6816761363636 34.37349999999999 437.55965909090907 34.37349999999999C 459.4376420454545 34.37349999999999 478.19019886363634 63.247240000000005 500.06818181818176 63.247240000000005C 521.9461647727272 63.247240000000005 540.698721590909 112.74508 562.5767045454545 112.74508C 584.4546875 112.74508 603.2072443181818 98.99568 625.0852272727273 98.99568C 646.9632102272727 98.99568 665.7157670454545 123.7446 687.59375 123.7446" pathFrom="M -1 137.494L -1 137.494L 62.50852272727272 137.494L 125.01704545454544 137.494L 187.52556818181816 137.494L 250.03409090909088 137.494L 312.5426136363636 137.494L 375.0511363636363 137.494L 437.55965909090907 137.494L 500.06818181818176 137.494L 562.5767045454545 137.494L 625.0852272727273 137.494L 687.59375 137.494"></path>
                                                <g id="SvgjsG2111" class="apexcharts-series-markers-wrap">
                                                    <g class="apexcharts-series-markers">
                                                        <circle id="SvgjsCircle2197" r="0" cx="250.03409090909088" cy="92.12098" class="apexcharts-marker w34gpuqg5" stroke="#ffffff" fill="#50a5f1" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle>
                                                    </g>
                                                </g>
                                            </g>
                                            <g id="SvgjsG2106" class="apexcharts-datalabels"></g>
                                            <g id="SvgjsG2101" class="apexcharts-datalabels"></g>
                                            <g id="SvgjsG2112" class="apexcharts-datalabels"></g>
                                        </g>
                                        <line id="SvgjsLine2190" x1="0" y1="0" x2="687.59375" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" class="apexcharts-ycrosshairs"></line>
                                        <line id="SvgjsLine2191" x1="0" y1="0" x2="687.59375" y2="0" stroke-dasharray="0" stroke-width="0" class="apexcharts-ycrosshairs-hidden"></line>
                                        <g id="SvgjsG2192" class="apexcharts-yaxis-annotations" clip-path="url(#gridRectMask1e5ca9)"></g>
                                        <g id="SvgjsG2193" class="apexcharts-xaxis-annotations" clip-path="url(#gridRectMask1e5ca9)"></g>
                                        <g id="SvgjsG2194" class="apexcharts-point-annotations" clip-path="url(#gridRectMask1e5ca9)"></g>
                                        <rect id="SvgjsRect2198" width="0" height="0" x="0" y="0" rx="0" ry="0" fill="#fefefe" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" class="apexcharts-zoom-rect"></rect>
                                        <rect id="SvgjsRect2199" width="0" height="0" x="0" y="0" rx="0" ry="0" fill="#fefefe" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" class="apexcharts-selection-rect"></rect>
                                    </g>
                                    <rect id="SvgjsRect2093" width="0" height="0" x="0" y="0" rx="0" ry="0" fill="#fefefe" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                    <g id="SvgjsG2153" class="apexcharts-yaxis" rel="0" transform="translate(14.4375, 0)">
                                        <g id="SvgjsG2154" class="apexcharts-yaxis-texts-g"><text id="SvgjsText2155" font-family="Helvetica, Arial, sans-serif" x="20" y="41.5" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                <tspan id="SvgjsTspan2156">100</tspan>
                                            </text><text id="SvgjsText2157" font-family="Helvetica, Arial, sans-serif" x="20" y="68.9988" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                <tspan id="SvgjsTspan2158">80</tspan>
                                            </text><text id="SvgjsText2159" font-family="Helvetica, Arial, sans-serif" x="20" y="96.4976" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                <tspan id="SvgjsTspan2160">60</tspan>
                                            </text><text id="SvgjsText2161" font-family="Helvetica, Arial, sans-serif" x="20" y="123.99640000000001" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                <tspan id="SvgjsTspan2162">40</tspan>
                                            </text><text id="SvgjsText2163" font-family="Helvetica, Arial, sans-serif" x="20" y="151.4952" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                <tspan id="SvgjsTspan2164">20</tspan>
                                            </text><text id="SvgjsText2165" font-family="Helvetica, Arial, sans-serif" x="20" y="178.994" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                <tspan id="SvgjsTspan2166">0</tspan>
                                            </text></g>
                                    </g>
                                </svg>
                                <div class="apexcharts-tooltip apexcharts-theme-light" style="left: 305.472px; top: 41.494px;">
                                    <div class="apexcharts-tooltip-title" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; display: flex;">May</div>
                                    <div class="apexcharts-tooltip-series-group apexcharts-active" style="display: flex;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(241, 180, 76);"></span>
                                        <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                            <div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-label">BTC: </span><span class="apexcharts-tooltip-text-value">75</span></div>
                                            <div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div>
                                        </div>
                                    </div>
                                    <div class="apexcharts-tooltip-series-group apexcharts-active" style="display: flex;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(52, 82, 225);"></span>
                                        <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                            <div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-label">ETH: </span><span class="apexcharts-tooltip-text-value">13</span></div>
                                            <div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div>
                                        </div>
                                    </div>
                                    <div class="apexcharts-tooltip-series-group apexcharts-active" style="display: flex;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(80, 165, 241);"></span>
                                        <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                            <div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-label">LTC: </span><span class="apexcharts-tooltip-text-value">33</span></div>
                                            <div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom apexcharts-theme-light" style="left: 268.979px; top: 179.494px;">
                                    <div class="apexcharts-xaxistooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; min-width: 27.9844px;">May</div>
                                </div>
                            </div>
                        </div>
                        <div class="resize-triggers">
                            <div class="expand-trigger">
                                <div style="width: 756px; height: 241px;"></div>
                            </div>
                            <div class="contract-trigger"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-4">Price</h4>

                        <div class="row">
                            <div class="col-xl-3 col-sm-4">
                                <div class="media">
                                    <div class="avatar-sm mr-3">
                                        <span class="avatar-title rounded-circle bg-soft-warning text-warning font-size-22">
                                            <i class="mdi mdi-bitcoin"></i>
                                        </span>
                                    </div>

                                    <div class="media-body">
                                        <p class="text-muted mb-2">Bitcoin</p>
                                        <h5>1.02356 BTC</h5>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-sm-4">
                                <div class="mt-4 mt-sm-0">
                                    <p class="text-muted mb-2">In USD</p>
                                    <h5>6310.22 USD</h5>
                                </div>
                            </div>

                            <div class="col-xl-3 col-sm-4">
                                <div class="mt-4 mt-sm-0">
                                    <p class="text-muted mb-2">Last 24 hrs</p>
                                    <h5>0.24 % <i class="mdi mdi-arrow-up text-success"></i></h5>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4" style="position: relative;">
                            <div id="candlestick-chart" class="apex-charts" dir="ltr" style="min-height: 325px;">
                                <div id="apexcharts1e65a5" class="apexcharts-canvas apexcharts1e65a5 apexcharts-theme-light apexcharts-zoomable" style="width: 755px; height: 310px;"><svg id="SvgjsSvg1249" width="755" height="310" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;">
                                        <g id="SvgjsG1251" class="apexcharts-inner apexcharts-graphical" transform="translate(71.09375, 30)">
                                            <defs id="SvgjsDefs1250">
                                                <clipPath id="gridRectMask1e65a5">
                                                    <rect id="SvgjsRect1288" width="678.90625" height="245.60000000000002" x="-2.5" y="-0.5" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                                </clipPath>
                                                <clipPath id="gridRectMarkerMask1e65a5">
                                                    <rect id="SvgjsRect1289" width="675.90625" height="246.60000000000002" x="-1" y="-1" rx="0" ry="0" fill="#ffffff" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                                </clipPath>
                                            </defs>
                                            <line id="SvgjsLine1256" x1="318.8199152542373" y1="0" x2="318.8199152542373" y2="244.60000000000002" stroke="#b6b6b6" stroke-dasharray="3" class="apexcharts-xcrosshairs" x="318.8199152542373" y="0" width="1" height="244.60000000000002" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line>
                                            <g id="SvgjsG1354" class="apexcharts-xaxis" transform="translate(0, 0)">
                                                <g id="SvgjsG1355" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"><text id="SvgjsText1357" font-family="Helvetica, Arial, sans-serif" x="11.422139830508472" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1358">23:00</tspan>
                                                        <title>23:00</title>
                                                    </text><text id="SvgjsText1360" font-family="Helvetica, Arial, sans-serif" x="57.11069915254237" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1361">02:00</tspan>
                                                        <title>02:00</title>
                                                    </text><text id="SvgjsText1363" font-family="Helvetica, Arial, sans-serif" x="102.79925847457625" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1364">04:00</tspan>
                                                        <title>04:00</title>
                                                    </text><text id="SvgjsText1366" font-family="Helvetica, Arial, sans-serif" x="148.48781779661013" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1367">06:00</tspan>
                                                        <title>06:00</title>
                                                    </text><text id="SvgjsText1369" font-family="Helvetica, Arial, sans-serif" x="194.176377118644" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1370">08:00</tspan>
                                                        <title>08:00</title>
                                                    </text><text id="SvgjsText1372" font-family="Helvetica, Arial, sans-serif" x="239.8649364406779" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1373">10:00</tspan>
                                                        <title>10:00</title>
                                                    </text><text id="SvgjsText1375" font-family="Helvetica, Arial, sans-serif" x="285.5534957627118" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1376">12:00</tspan>
                                                        <title>12:00</title>
                                                    </text><text id="SvgjsText1378" font-family="Helvetica, Arial, sans-serif" x="331.24205508474574" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1379">14:00</tspan>
                                                        <title>14:00</title>
                                                    </text><text id="SvgjsText1381" font-family="Helvetica, Arial, sans-serif" x="376.9306144067797" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1382">16:00</tspan>
                                                        <title>16:00</title>
                                                    </text><text id="SvgjsText1384" font-family="Helvetica, Arial, sans-serif" x="422.6191737288136" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1385">18:00</tspan>
                                                        <title>18:00</title>
                                                    </text><text id="SvgjsText1387" font-family="Helvetica, Arial, sans-serif" x="468.30773305084756" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1388">20:00</tspan>
                                                        <title>20:00</title>
                                                    </text><text id="SvgjsText1390" font-family="Helvetica, Arial, sans-serif" x="513.9962923728815" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1391">22:00</tspan>
                                                        <title>22:00</title>
                                                    </text><text id="SvgjsText1393" font-family="Helvetica, Arial, sans-serif" x="559.6848516949153" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="600" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1394">07 Oct</tspan>
                                                        <title>07 Oct</title>
                                                    </text><text id="SvgjsText1396" font-family="Helvetica, Arial, sans-serif" x="628.2176906779661" y="273.6" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                        <tspan id="SvgjsTspan1397">03:00</tspan>
                                                        <title>03:00</title>
                                                    </text></g>
                                                <line id="SvgjsLine1398" x1="0" y1="245.60000000000002" x2="673.90625" y2="245.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" stroke-width="1"></line>
                                            </g>
                                            <g id="SvgjsG1413" class="apexcharts-grid">
                                                <g id="SvgjsG1414" class="apexcharts-gridlines-horizontal">
                                                    <line id="SvgjsLine1430" x1="0" y1="0" x2="673.90625" y2="0" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1431" x1="0" y1="48.92" x2="673.90625" y2="48.92" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1432" x1="0" y1="97.84" x2="673.90625" y2="97.84" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1433" x1="0" y1="146.76" x2="673.90625" y2="146.76" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1434" x1="0" y1="195.68" x2="673.90625" y2="195.68" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                    <line id="SvgjsLine1435" x1="0" y1="244.60000000000002" x2="673.90625" y2="244.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-gridline"></line>
                                                </g>
                                                <g id="SvgjsG1415" class="apexcharts-gridlines-vertical"></g>
                                                <line id="SvgjsLine1416" x1="11.422139830508472" y1="245.60000000000002" x2="11.422139830508472" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1417" x1="57.11069915254237" y1="245.60000000000002" x2="57.11069915254237" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1418" x1="102.79925847457625" y1="245.60000000000002" x2="102.79925847457625" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1419" x1="148.48781779661013" y1="245.60000000000002" x2="148.48781779661013" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1420" x1="194.176377118644" y1="245.60000000000002" x2="194.176377118644" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1421" x1="239.8649364406779" y1="245.60000000000002" x2="239.8649364406779" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1422" x1="285.5534957627118" y1="245.60000000000002" x2="285.5534957627118" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1423" x1="331.24205508474574" y1="245.60000000000002" x2="331.24205508474574" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1424" x1="376.9306144067797" y1="245.60000000000002" x2="376.9306144067797" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1425" x1="422.6191737288136" y1="245.60000000000002" x2="422.6191737288136" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1426" x1="468.30773305084756" y1="245.60000000000002" x2="468.30773305084756" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1427" x1="513.9962923728815" y1="245.60000000000002" x2="513.9962923728815" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1428" x1="559.6848516949153" y1="245.60000000000002" x2="559.6848516949153" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1429" x1="628.2176906779661" y1="245.60000000000002" x2="628.2176906779661" y2="251.60000000000002" stroke="#e0e0e0" stroke-dasharray="0" class="apexcharts-xaxis-tick"></line>
                                                <line id="SvgjsLine1437" x1="0" y1="244.60000000000002" x2="673.90625" y2="244.60000000000002" stroke="transparent" stroke-dasharray="0"></line>
                                                <line id="SvgjsLine1436" x1="0" y1="1" x2="0" y2="244.60000000000002" stroke="transparent" stroke-dasharray="0"></line>
                                            </g>
                                            <g id="SvgjsG1291" class="apexcharts-candlestick-series apexcharts-plot-series">
                                                <g id="SvgjsG1292" class="apexcharts-series" seriesName="seriesx1" rel="1" data:realIndex="0">
                                                    <path id="SvgjsPath1294" d="M -3.9977489406779667 65.23481999999967L 0 65.23481999999967L 0 23.23699999999917L 0 65.23481999999967L 3.9977489406779667 65.23481999999967L 3.9977489406779667 73.84473999999864L 0 73.84473999999864L 0 90.40416000000005L 0 73.84473999999864L -3.9977489406779667 73.84473999999864L -3.9977489406779667 64.73481999999967" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M -3.9977489406779667 65.23481999999967L 0 65.23481999999967L 0 23.23699999999917L 0 65.23481999999967L 3.9977489406779667 65.23481999999967L 3.9977489406779667 73.84473999999864L 0 73.84473999999864L 0 90.40416000000005L 0 73.84473999999864L -3.9977489406779667 73.84473999999864L -3.9977489406779667 64.73481999999967" pathFrom="M -3.9977489406779667 73.84473999999864M -3.9977489406779667 73.84473999999864" cy="65.23481999999967" cx="3.4977489406779667" j="0" val="6633.33" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1295" d="M 7.424390889830509 68.46353999999883L 11.422139830508476 68.46353999999883L 11.422139830508476 40.13885999999911L 11.422139830508476 68.46353999999883L 15.419888771186443 68.46353999999883L 15.419888771186443 73.11094000000048L 11.422139830508476 73.11094000000048L 11.422139830508476 97.84000000000015L 11.422139830508476 73.11094000000048L 7.424390889830509 73.11094000000048L 7.424390889830509 67.96353999999883" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 7.424390889830509 68.46353999999883L 11.422139830508476 68.46353999999883L 11.422139830508476 40.13885999999911L 11.422139830508476 68.46353999999883L 15.419888771186443 68.46353999999883L 15.419888771186443 73.11094000000048L 11.422139830508476 73.11094000000048L 11.422139830508476 97.84000000000015L 11.422139830508476 73.11094000000048L 7.424390889830509 73.11094000000048L 7.424390889830509 67.96353999999883" pathFrom="M 7.424390889830509 73.11094000000048M 7.424390889830509 73.11094000000048" cy="68.46353999999883" cx="14.919888771186443" j="1" val="6630.11" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1296" d="M 18.846530720338986 59.5601000000006L 22.84427966101695 59.5601000000006L 22.84427966101695 27.028299999999945L 22.84427966101695 59.5601000000006L 26.84202860169492 59.5601000000006L 26.84202860169492 71.64333999999872L 22.84427966101695 71.64333999999872L 22.84427966101695 89.67036000000007L 22.84427966101695 71.64333999999872L 18.846530720338986 71.64333999999872L 18.846530720338986 59.0601000000006" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 18.846530720338986 59.5601000000006L 22.84427966101695 59.5601000000006L 22.84427966101695 27.028299999999945L 22.84427966101695 59.5601000000006L 26.84202860169492 59.5601000000006L 26.84202860169492 71.64333999999872L 22.84427966101695 71.64333999999872L 22.84427966101695 89.67036000000007L 22.84427966101695 71.64333999999872L 18.846530720338986 71.64333999999872L 18.846530720338986 59.0601000000006" pathFrom="M 18.846530720338986 71.64333999999872M 18.846530720338986 71.64333999999872" cy="59.5601000000006" cx="26.34202860169492" j="2" val="6635.65" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1297" d="M 30.26867055084746 53.224959999999555L 34.266419491525426 53.224959999999555L 34.266419491525426 22.013999999999214L 34.266419491525426 53.224959999999555L 38.26416843220339 53.224959999999555L 38.26416843220339 59.5601000000006L 34.266419491525426 59.5601000000006L 34.266419491525426 74.18717999999899L 34.266419491525426 59.5601000000006L 30.26867055084746 59.5601000000006L 30.26867055084746 52.724959999999555" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 30.26867055084746 53.224959999999555L 34.266419491525426 53.224959999999555L 34.266419491525426 22.013999999999214L 34.266419491525426 53.224959999999555L 38.26416843220339 53.224959999999555L 38.26416843220339 59.5601000000006L 34.266419491525426 59.5601000000006L 34.266419491525426 74.18717999999899L 34.266419491525426 59.5601000000006L 30.26867055084746 59.5601000000006L 30.26867055084746 52.724959999999555" pathFrom="M 30.26867055084746 59.5601000000006M 30.26867055084746 59.5601000000006" cy="53.224959999999555" cx="37.76416843220339" j="3" val="6638.24" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1298" d="M 41.69081038135594 53.224959999999555L 45.6885593220339 53.224959999999555L 45.6885593220339 48.92000000000007L 45.6885593220339 53.224959999999555L 49.68630826271187 53.224959999999555L 49.68630826271187 86.90637999999853L 45.6885593220339 86.90637999999853L 45.6885593220339 97.84000000000015L 45.6885593220339 86.90637999999853L 41.69081038135594 86.90637999999853L 41.69081038135594 52.724959999999555" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 41.69081038135594 53.224959999999555L 45.6885593220339 53.224959999999555L 45.6885593220339 48.92000000000007L 45.6885593220339 53.224959999999555L 49.68630826271187 53.224959999999555L 49.68630826271187 86.90637999999853L 45.6885593220339 86.90637999999853L 45.6885593220339 97.84000000000015L 45.6885593220339 86.90637999999853L 41.69081038135594 86.90637999999853L 41.69081038135594 52.724959999999555" pathFrom="M 41.69081038135594 86.90637999999853M 41.69081038135594 86.90637999999853" cy="53.224959999999555" cx="49.18630826271187" j="4" val="6624.47" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1299" d="M 53.11295021186441 86.75962000000072L 57.110699152542374 86.75962000000072L 57.110699152542374 58.63061999999991L 57.110699152542374 86.75962000000072L 61.10844809322034 86.75962000000072L 61.10844809322034 87.29773999999816L 57.110699152542374 87.29773999999816L 57.110699152542374 93.73071999999956L 57.110699152542374 87.29773999999816L 53.11295021186441 87.29773999999816L 53.11295021186441 86.25962000000072" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 53.11295021186441 86.75962000000072L 57.110699152542374 86.75962000000072L 57.110699152542374 58.63061999999991L 57.110699152542374 86.75962000000072L 61.10844809322034 86.75962000000072L 61.10844809322034 87.29773999999816L 57.110699152542374 87.29773999999816L 57.110699152542374 93.73071999999956L 57.110699152542374 87.29773999999816L 53.11295021186441 87.29773999999816L 53.11295021186441 86.25962000000072" pathFrom="M 53.11295021186441 87.29773999999816M 53.11295021186441 87.29773999999816" cy="86.75962000000072" cx="60.60844809322034" j="5" val="6624.31" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1300" d="M 64.53509004237289 83.11507999999776L 68.53283898305085 83.11507999999776L 68.53283898305085 67.99879999999939L 68.53283898305085 83.11507999999776L 72.53058792372882 83.11507999999776L 72.53058792372882 86.56394L 68.53283898305085 86.56394L 68.53283898305085 105.17799999999988L 68.53283898305085 86.56394L 64.53509004237289 86.56394L 64.53509004237289 82.61507999999776" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 64.53509004237289 83.11507999999776L 68.53283898305085 83.11507999999776L 68.53283898305085 67.99879999999939L 68.53283898305085 83.11507999999776L 72.53058792372882 83.11507999999776L 72.53058792372882 86.56394L 68.53283898305085 86.56394L 68.53283898305085 105.17799999999988L 68.53283898305085 86.56394L 64.53509004237289 86.56394L 64.53509004237289 82.61507999999776" pathFrom="M 64.53509004237289 86.56394M 64.53509004237289 86.56394" cy="83.11507999999776" cx="72.03058792372882" j="6" val="6626.02" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1301" d="M 75.95722987288136 80.71799999999894L 79.95497881355932 80.71799999999894L 79.95497881355932 79.20147999999972L 79.95497881355932 80.71799999999894L 83.95272775423729 80.71799999999894L 83.95272775423729 139.3730799999994L 79.95497881355932 139.3730799999994L 79.95497881355932 185.35787999999957L 79.95497881355932 139.3730799999994L 75.95722987288136 139.3730799999994L 75.95722987288136 80.21799999999894" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 75.95722987288136 80.71799999999894L 79.95497881355932 80.71799999999894L 79.95497881355932 79.20147999999972L 79.95497881355932 80.71799999999894L 83.95272775423729 80.71799999999894L 83.95272775423729 139.3730799999994L 79.95497881355932 139.3730799999994L 79.95497881355932 185.35787999999957L 79.95497881355932 139.3730799999994L 75.95722987288136 139.3730799999994L 75.95722987288136 80.21799999999894" pathFrom="M 75.95722987288136 139.3730799999994M 75.95722987288136 139.3730799999994" cy="80.71799999999894" cx="83.45272775423729" j="7" val="6603.02" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1302" d="M 87.37936970338984 134.52999999999884L 91.3771186440678 134.52999999999884L 91.3771186440678 127.1186200000011L 91.3771186440678 134.52999999999884L 95.37486758474577 134.52999999999884L 95.37486758474577 136.95154000000002L 91.3771186440678 136.95154000000002L 91.3771186440678 149.32830000000104L 91.3771186440678 136.95154000000002L 87.37936970338984 136.95154000000002L 87.37936970338984 134.02999999999884" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 87.37936970338984 134.52999999999884L 91.3771186440678 134.52999999999884L 91.3771186440678 127.1186200000011L 91.3771186440678 134.52999999999884L 95.37486758474577 134.52999999999884L 95.37486758474577 136.95154000000002L 91.3771186440678 136.95154000000002L 91.3771186440678 149.32830000000104L 91.3771186440678 136.95154000000002L 87.37936970338984 136.95154000000002L 87.37936970338984 134.02999999999884" pathFrom="M 87.37936970338984 136.95154000000002M 87.37936970338984 136.95154000000002" cy="134.52999999999884" cx="94.87486758474577" j="8" val="6604.01" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1303" d="M 98.80150953389831 127.14307999999801L 102.79925847457628 127.14307999999801L 102.79925847457628 111.53760000000148L 102.79925847457628 127.14307999999801L 106.79700741525424 127.14307999999801L 106.79700741525424 135.7529999999988L 102.79925847457628 135.7529999999988L 102.79925847457628 141.23203999999896L 102.79925847457628 135.7529999999988L 98.80150953389831 135.7529999999988L 98.80150953389831 126.64307999999801" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 98.80150953389831 127.14307999999801L 102.79925847457628 127.14307999999801L 102.79925847457628 111.53760000000148L 102.79925847457628 127.14307999999801L 106.79700741525424 127.14307999999801L 106.79700741525424 135.7529999999988L 102.79925847457628 135.7529999999988L 102.79925847457628 141.23203999999896L 102.79925847457628 135.7529999999988L 98.80150953389831 135.7529999999988L 98.80150953389831 126.64307999999801" pathFrom="M 98.80150953389831 135.7529999999988M 98.80150953389831 135.7529999999988" cy="127.14307999999801" cx="106.29700741525424" j="9" val="6608.02" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1304" d="M 110.22364936440678 124.96614000000045L 114.22139830508475 124.96614000000045L 114.22139830508475 120.6367199999986L 114.22139830508475 124.96614000000045L 118.21914724576271 124.96614000000045L 118.21914724576271 127.14307999999801L 114.22139830508475 127.14307999999801L 114.22139830508475 141.89246000000094L 114.22139830508475 127.14307999999801L 110.22364936440678 127.14307999999801L 110.22364936440678 124.46614000000045" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 110.22364936440678 124.96614000000045L 114.22139830508475 124.96614000000045L 114.22139830508475 120.6367199999986L 114.22139830508475 124.96614000000045L 118.21914724576271 124.96614000000045L 118.21914724576271 127.14307999999801L 114.22139830508475 127.14307999999801L 114.22139830508475 141.89246000000094L 114.22139830508475 127.14307999999801L 110.22364936440678 127.14307999999801L 110.22364936440678 124.46614000000045" pathFrom="M 110.22364936440678 127.14307999999801M 110.22364936440678 127.14307999999801" cy="124.96614000000045" cx="117.71914724576271" j="10" val="6608.91" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1305" d="M 121.64578919491527 117.40799999999945L 125.64353813559323 117.40799999999945L 125.64353813559323 100.3104600000006L 125.64353813559323 117.40799999999945L 129.6412870762712 117.40799999999945L 129.6412870762712 124.96614000000045L 125.64353813559323 124.96614000000045L 125.64353813559323 127.16753999999855L 125.64353813559323 124.96614000000045L 121.64578919491527 124.96614000000045L 121.64578919491527 116.90799999999945" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 121.64578919491527 117.40799999999945L 125.64353813559323 117.40799999999945L 125.64353813559323 100.3104600000006L 125.64353813559323 117.40799999999945L 129.6412870762712 117.40799999999945L 129.6412870762712 124.96614000000045L 125.64353813559323 124.96614000000045L 125.64353813559323 127.16753999999855L 125.64353813559323 124.96614000000045L 121.64578919491527 124.96614000000045L 121.64578919491527 116.90799999999945" pathFrom="M 121.64578919491527 124.96614000000045M 121.64578919491527 124.96614000000045" cy="117.40799999999945" cx="129.1412870762712" j="11" val="6612" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1306" d="M 133.06792902542372 117.40799999999945L 137.0656779661017 117.40799999999945L 137.0656779661017 109.7520199999999L 137.0656779661017 117.40799999999945L 141.06342690677965 117.40799999999945L 141.06342690677965 117.40799999999945L 137.0656779661017 117.40799999999945L 137.0656779661017 134.3098599999994L 137.0656779661017 117.40799999999945L 133.06792902542372 117.40799999999945L 133.06792902542372 116.90799999999945" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 133.06792902542372 117.40799999999945L 137.0656779661017 117.40799999999945L 137.0656779661017 109.7520199999999L 137.0656779661017 117.40799999999945L 141.06342690677965 117.40799999999945L 141.06342690677965 117.40799999999945L 137.0656779661017 117.40799999999945L 137.0656779661017 134.3098599999994L 137.0656779661017 117.40799999999945L 133.06792902542372 117.40799999999945L 133.06792902542372 116.90799999999945" pathFrom="M 133.06792902542372 117.40799999999945M 133.06792902542372 117.40799999999945" cy="117.40799999999945" cx="140.56342690677965" j="12" val="6612" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1307" d="M 144.4900688559322 90.6242999999995L 148.4878177966102 90.6242999999995L 148.4878177966102 87.76247999999941L 148.4878177966102 90.6242999999995L 152.48556673728814 90.6242999999995L 152.48556673728814 117.40799999999945L 148.4878177966102 117.40799999999945L 148.4878177966102 126.14021999999932L 148.4878177966102 117.40799999999945L 144.4900688559322 117.40799999999945L 144.4900688559322 90.1242999999995" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 144.4900688559322 90.6242999999995L 148.4878177966102 90.6242999999995L 148.4878177966102 87.76247999999941L 148.4878177966102 90.6242999999995L 152.48556673728814 90.6242999999995L 152.48556673728814 117.40799999999945L 148.4878177966102 117.40799999999945L 148.4878177966102 126.14021999999932L 148.4878177966102 117.40799999999945L 144.4900688559322 117.40799999999945L 144.4900688559322 90.1242999999995" pathFrom="M 144.4900688559322 117.40799999999945M 144.4900688559322 117.40799999999945" cy="90.6242999999995" cx="151.98556673728814" j="13" val="6622.95" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1308" d="M 155.91220868644066 88.27613999999994L 159.90995762711864 88.27613999999994L 159.90995762711864 88.27613999999994L 159.90995762711864 88.27613999999994L 163.9077065677966 88.27613999999994L 163.9077065677966 108.43117999999959L 159.90995762711864 108.43117999999959L 159.90995762711864 110.06999999999971L 159.90995762711864 108.43117999999959L 155.91220868644066 108.43117999999959L 155.91220868644066 87.77613999999994" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 155.91220868644066 88.27613999999994L 159.90995762711864 88.27613999999994L 159.90995762711864 88.27613999999994L 159.90995762711864 88.27613999999994L 163.9077065677966 88.27613999999994L 163.9077065677966 108.43117999999959L 159.90995762711864 108.43117999999959L 159.90995762711864 110.06999999999971L 159.90995762711864 108.43117999999959L 155.91220868644066 108.43117999999959L 155.91220868644066 87.77613999999994" pathFrom="M 155.91220868644066 108.43117999999959M 155.91220868644066 108.43117999999959" cy="88.27613999999994" cx="163.4077065677966" j="14" val="6615.67" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1309" d="M 167.33434851694915 101.04426000000058L 171.33209745762713 101.04426000000058L 171.33209745762713 100.92195999999967L 171.33209745762713 101.04426000000058L 175.32984639830508 101.04426000000058L 175.32984639830508 121.32160000000113L 171.33209745762713 121.32160000000113L 171.33209745762713 122.29999999999927L 171.33209745762713 121.32160000000113L 167.33434851694915 121.32160000000113L 167.33434851694915 100.54426000000058" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 167.33434851694915 101.04426000000058L 171.33209745762713 101.04426000000058L 171.33209745762713 100.92195999999967L 171.33209745762713 101.04426000000058L 175.32984639830508 101.04426000000058L 175.32984639830508 121.32160000000113L 171.33209745762713 121.32160000000113L 171.33209745762713 122.29999999999927L 171.33209745762713 121.32160000000113L 167.33434851694915 121.32160000000113L 167.33434851694915 100.54426000000058" pathFrom="M 167.33434851694915 121.32160000000113M 167.33434851694915 121.32160000000113" cy="101.04426000000058" cx="174.82984639830508" j="15" val="6610.4" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1310" d="M 178.75648834745763 110.3145999999997L 182.7542372881356 110.3145999999997L 182.7542372881356 91.04011999999966L 182.7542372881356 110.3145999999997L 186.75198622881356 110.3145999999997L 186.75198622881356 119.85399999999936L 182.7542372881356 119.85399999999936L 182.7542372881356 121.32160000000113L 182.7542372881356 119.85399999999936L 178.75648834745763 119.85399999999936L 178.75648834745763 109.8145999999997" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 178.75648834745763 110.3145999999997L 182.7542372881356 110.3145999999997L 182.7542372881356 91.04011999999966L 182.7542372881356 110.3145999999997L 186.75198622881356 110.3145999999997L 186.75198622881356 119.85399999999936L 182.7542372881356 119.85399999999936L 182.7542372881356 121.32160000000113L 182.7542372881356 119.85399999999936L 178.75648834745763 119.85399999999936L 178.75648834745763 109.8145999999997" pathFrom="M 178.75648834745763 119.85399999999936M 178.75648834745763 119.85399999999936" cy="110.3145999999997" cx="186.25198622881356" j="16" val="6614.9" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1311" d="M 190.1786281779661 89.40129999999954L 194.17637711864407 89.40129999999954L 194.17637711864407 82.67480000000069L 194.17637711864407 89.40129999999954L 198.17412605932202 89.40129999999954L 198.17412605932202 110.3145999999997L 194.17637711864407 110.3145999999997L 194.17637711864407 114.15481999999975L 194.17637711864407 110.3145999999997L 190.1786281779661 110.3145999999997L 190.1786281779661 88.90129999999954" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 190.1786281779661 89.40129999999954L 194.17637711864407 89.40129999999954L 194.17637711864407 82.67480000000069L 194.17637711864407 89.40129999999954L 198.17412605932202 89.40129999999954L 198.17412605932202 110.3145999999997L 194.17637711864407 110.3145999999997L 194.17637711864407 114.15481999999975L 194.17637711864407 110.3145999999997L 190.1786281779661 110.3145999999997L 190.1786281779661 88.90129999999954" pathFrom="M 190.1786281779661 110.3145999999997M 190.1786281779661 110.3145999999997" cy="89.40129999999954" cx="197.67412605932202" j="17" val="6623.45" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1312" d="M 201.60076800847457 89.32792000000154L 205.59851694915255 89.32792000000154L 205.59851694915255 80.71799999999894L 205.59851694915255 89.32792000000154L 209.5962658898305 89.32792000000154L 209.5962658898305 96.98389999999927L 205.59851694915255 96.98389999999927L 205.59851694915255 101.80251999999928L 205.59851694915255 96.98389999999927L 201.60076800847457 96.98389999999927L 201.60076800847457 88.82792000000154" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 201.60076800847457 89.32792000000154L 205.59851694915255 89.32792000000154L 205.59851694915255 80.71799999999894L 205.59851694915255 89.32792000000154L 209.5962658898305 89.32792000000154L 209.5962658898305 96.98389999999927L 205.59851694915255 96.98389999999927L 205.59851694915255 101.80251999999928L 205.59851694915255 96.98389999999927L 201.60076800847457 96.98389999999927L 201.60076800847457 88.82792000000154" pathFrom="M 201.60076800847457 96.98389999999927M 201.60076800847457 96.98389999999927" cy="89.32792000000154" cx="209.0962658898305" j="18" val="6620.35" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1313" d="M 213.02290783898306 99.23421999999846L 217.02065677966104 99.23421999999846L 217.02065677966104 96.98389999999927L 217.02065677966104 99.23421999999846L 221.018405720339 99.23421999999846L 221.018405720339 108.77361999999994L 217.02065677966104 108.77361999999994L 217.02065677966104 122.17769999999837L 217.02065677966104 108.77361999999994L 213.02290783898306 108.77361999999994L 213.02290783898306 98.73421999999846" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 213.02290783898306 99.23421999999846L 217.02065677966104 99.23421999999846L 217.02065677966104 96.98389999999927L 217.02065677966104 99.23421999999846L 221.018405720339 99.23421999999846L 221.018405720339 108.77361999999994L 217.02065677966104 108.77361999999994L 217.02065677966104 122.17769999999837L 217.02065677966104 108.77361999999994L 213.02290783898306 108.77361999999994L 213.02290783898306 98.73421999999846" pathFrom="M 213.02290783898306 108.77361999999994M 213.02290783898306 108.77361999999994" cy="99.23421999999846" cx="220.518405720339" j="19" val="6615.53" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1314" d="M 224.44504766949152 108.77361999999994L 228.4427966101695 108.77361999999994L 228.4427966101695 102.90321999999833L 228.4427966101695 108.77361999999994L 232.44054555084745 108.77361999999994L 232.44054555084745 109.60526000000027L 228.4427966101695 109.60526000000027L 228.4427966101695 122.29999999999927L 228.4427966101695 109.60526000000027L 224.44504766949152 109.60526000000027L 224.44504766949152 108.27361999999994" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 224.44504766949152 108.77361999999994L 228.4427966101695 108.77361999999994L 228.4427966101695 102.90321999999833L 228.4427966101695 108.77361999999994L 232.44054555084745 108.77361999999994L 232.44054555084745 109.60526000000027L 228.4427966101695 109.60526000000027L 228.4427966101695 122.29999999999927L 228.4427966101695 109.60526000000027L 224.44504766949152 109.60526000000027L 224.44504766949152 108.27361999999994" pathFrom="M 224.44504766949152 109.60526000000027M 224.44504766949152 109.60526000000027" cy="108.77361999999994" cx="231.94054555084745" j="20" val="6615.19" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1315" d="M 235.8671875 97.84000000000015L 239.86493644067798 97.84000000000015L 239.86493644067798 93.92639999999847L 239.86493644067798 97.84000000000015L 243.86268538135593 97.84000000000015L 243.86268538135593 109.60526000000027L 239.86493644067798 109.60526000000027L 239.86493644067798 126.70280000000093L 239.86493644067798 109.60526000000027L 235.8671875 109.60526000000027L 235.8671875 97.34000000000015" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 235.8671875 97.84000000000015L 239.86493644067798 97.84000000000015L 239.86493644067798 93.92639999999847L 239.86493644067798 97.84000000000015L 243.86268538135593 97.84000000000015L 243.86268538135593 109.60526000000027L 239.86493644067798 109.60526000000027L 239.86493644067798 126.70280000000093L 239.86493644067798 109.60526000000027L 235.8671875 109.60526000000027L 235.8671875 97.34000000000015" pathFrom="M 235.8671875 109.60526000000027M 235.8671875 109.60526000000027" cy="97.84000000000015" cx="243.36268538135593" j="21" val="6620" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1316" d="M 247.28932733050848 97.84000000000015L 251.28707627118646 97.84000000000015L 251.28707627118646 85.19418000000042L 251.28707627118646 97.84000000000015L 255.28482521186442 97.84000000000015L 255.28482521186442 98.96515999999974L 251.28707627118646 98.96515999999974L 251.28707627118646 112.14910000000054L 251.28707627118646 98.96515999999974L 247.28932733050848 98.96515999999974L 247.28932733050848 97.34000000000015" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 247.28932733050848 97.84000000000015L 251.28707627118646 97.84000000000015L 251.28707627118646 85.19418000000042L 251.28707627118646 97.84000000000015L 255.28482521186442 97.84000000000015L 255.28482521186442 98.96515999999974L 251.28707627118646 98.96515999999974L 251.28707627118646 112.14910000000054L 251.28707627118646 98.96515999999974L 247.28932733050848 98.96515999999974L 247.28932733050848 97.34000000000015" pathFrom="M 247.28932733050848 98.96515999999974M 247.28932733050848 98.96515999999974" cy="97.84000000000015" cx="254.78482521186442" j="22" val="6620" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1317" d="M 258.71146716101697 86.56394L 262.70921610169495 86.56394L 262.70921610169495 63.22910000000047L 262.70921610169495 86.56394L 266.70696504237293 86.56394L 266.70696504237293 97.03282000000036L 262.70921610169495 97.03282000000036L 262.70921610169495 104.59095999999954L 262.70921610169495 97.03282000000036L 258.71146716101697 97.03282000000036L 258.71146716101697 86.06394" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 258.71146716101697 86.56394L 262.70921610169495 86.56394L 262.70921610169495 63.22910000000047L 262.70921610169495 86.56394L 266.70696504237293 86.56394L 266.70696504237293 97.03282000000036L 262.70921610169495 97.03282000000036L 262.70921610169495 104.59095999999954L 262.70921610169495 97.03282000000036L 258.71146716101697 97.03282000000036L 258.71146716101697 86.06394" pathFrom="M 258.71146716101697 97.03282000000036M 258.71146716101697 97.03282000000036" cy="86.56394" cx="266.20696504237293" j="23" val="6624.61" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1318" d="M 270.1336069915254 83.28629999999976L 274.1313559322034 83.28629999999976L 274.1313559322034 83.16399999999885L 274.1313559322034 83.28629999999976L 278.1291048728814 83.28629999999976L 278.1291048728814 103.7593199999992L 274.1313559322034 103.7593199999992L 274.1313559322034 118.23963999999978L 274.1313559322034 103.7593199999992L 270.1336069915254 103.7593199999992L 270.1336069915254 82.78629999999976" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 270.1336069915254 83.28629999999976L 274.1313559322034 83.28629999999976L 274.1313559322034 83.16399999999885L 274.1313559322034 83.28629999999976L 278.1291048728814 83.28629999999976L 278.1291048728814 103.7593199999992L 274.1313559322034 103.7593199999992L 274.1313559322034 118.23963999999978L 274.1313559322034 103.7593199999992L 270.1336069915254 103.7593199999992L 270.1336069915254 82.78629999999976" pathFrom="M 270.1336069915254 103.7593199999992M 270.1336069915254 103.7593199999992" cy="83.28629999999976" cx="277.6291048728814" j="24" val="6617.58" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1319" d="M 281.5557468220339 100.28600000000006L 285.55349576271186 100.28600000000006L 285.55349576271186 83.23737999999867L 285.55349576271186 100.28600000000006L 289.55124470338984 100.28600000000006L 289.55124470338984 149.54844000000048L 285.55349576271186 149.54844000000048L 285.55349576271186 158.3295799999978L 285.55349576271186 149.54844000000048L 281.5557468220339 149.54844000000048L 281.5557468220339 99.78600000000006" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 281.5557468220339 100.28600000000006L 285.55349576271186 100.28600000000006L 285.55349576271186 83.23737999999867L 285.55349576271186 100.28600000000006L 289.55124470338984 100.28600000000006L 289.55124470338984 149.54844000000048L 285.55349576271186 149.54844000000048L 285.55349576271186 158.3295799999978L 285.55349576271186 149.54844000000048L 281.5557468220339 149.54844000000048L 281.5557468220339 99.78600000000006" pathFrom="M 281.5557468220339 149.54844000000048M 281.5557468220339 149.54844000000048" cy="100.28600000000006" cx="289.05124470338984" j="25" val="6598.86" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1320" d="M 292.9778866525424 149.54844000000048L 296.9756355932204 149.54844000000048L 296.9756355932204 149.4995199999994L 296.9756355932204 149.54844000000048L 300.97338453389835 149.54844000000048L 300.97338453389835 178.16663999999946L 296.9756355932204 178.16663999999946L 296.9756355932204 220.13999999999942L 296.9756355932204 178.16663999999946L 292.9778866525424 178.16663999999946L 292.9778866525424 149.04844000000048" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 292.9778866525424 149.54844000000048L 296.9756355932204 149.54844000000048L 296.9756355932204 149.4995199999994L 296.9756355932204 149.54844000000048L 300.97338453389835 149.54844000000048L 300.97338453389835 178.16663999999946L 296.9756355932204 178.16663999999946L 296.9756355932204 220.13999999999942L 296.9756355932204 178.16663999999946L 292.9778866525424 178.16663999999946L 292.9778866525424 149.04844000000048" pathFrom="M 292.9778866525424 178.16663999999946M 292.9778866525424 178.16663999999946" cy="149.54844000000048" cx="300.47338453389835" j="26" val="6587.16" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1321" d="M 304.40002648305085 162.90360000000146L 308.39777542372883 162.90360000000146L 308.39777542372883 146.76000000000022L 308.39777542372883 162.90360000000146L 312.3955243644068 162.90360000000146L 312.3955243644068 174.0084399999996L 308.39777542372883 174.0084399999996L 308.39777542372883 195.6800000000003L 308.39777542372883 174.0084399999996L 304.40002648305085 174.0084399999996L 304.40002648305085 162.40360000000146" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 304.40002648305085 162.90360000000146L 308.39777542372883 162.90360000000146L 308.39777542372883 146.76000000000022L 308.39777542372883 162.90360000000146L 312.3955243644068 162.90360000000146L 312.3955243644068 174.0084399999996L 308.39777542372883 174.0084399999996L 308.39777542372883 195.6800000000003L 308.39777542372883 174.0084399999996L 304.40002648305085 174.0084399999996L 304.40002648305085 162.40360000000146" pathFrom="M 304.40002648305085 174.0084399999996M 304.40002648305085 174.0084399999996" cy="162.90360000000146" cx="311.8955243644068" j="27" val="6593.4" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1322" d="M 315.8221663135593 161.46046000000024L 319.8199152542373 161.46046000000024L 319.8199152542373 149.47505999999885L 319.8199152542373 161.46046000000024L 323.81766419491527 161.46046000000024L 323.81766419491527 176.5767399999986L 319.8199152542373 176.5767399999986L 319.8199152542373 183.4499999999989L 319.8199152542373 176.5767399999986L 315.8221663135593 176.5767399999986L 315.8221663135593 160.96046000000024" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 315.8221663135593 161.46046000000024L 319.8199152542373 161.46046000000024L 319.8199152542373 149.47505999999885L 319.8199152542373 161.46046000000024L 323.81766419491527 161.46046000000024L 323.81766419491527 176.5767399999986L 319.8199152542373 176.5767399999986L 319.8199152542373 183.4499999999989L 319.8199152542373 176.5767399999986L 315.8221663135593 176.5767399999986L 315.8221663135593 160.96046000000024" pathFrom="M 315.8221663135593 176.5767399999986M 315.8221663135593 176.5767399999986" cy="161.46046000000024" cx="323.31766419491527" j="28" val="6587.81" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1323" d="M 327.2443061440678 176.5767399999986L 331.2420550847458 176.5767399999986L 331.2420550847458 164.54242000000158L 331.2420550847458 176.5767399999986L 335.2398040254238 176.5767399999986L 335.2398040254238 200.57200000000012L 331.2420550847458 200.57200000000012L 331.2420550847458 227.1355599999988L 331.2420550847458 200.57200000000012L 327.2443061440678 200.57200000000012L 327.2443061440678 176.0767399999986" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 327.2443061440678 176.5767399999986L 331.2420550847458 176.5767399999986L 331.2420550847458 164.54242000000158L 331.2420550847458 176.5767399999986L 335.2398040254238 176.5767399999986L 335.2398040254238 200.57200000000012L 331.2420550847458 200.57200000000012L 331.2420550847458 227.1355599999988L 331.2420550847458 200.57200000000012L 327.2443061440678 200.57200000000012L 327.2443061440678 176.0767399999986" pathFrom="M 327.2443061440678 200.57200000000012M 327.2443061440678 200.57200000000012" cy="176.5767399999986" cx="334.7398040254238" j="29" val="6578" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1324" d="M 338.6664459745763 198.1260000000002L 342.66419491525426 198.1260000000002L 342.66419491525426 191.47287999999935L 342.66419491525426 198.1260000000002L 346.66194385593224 198.1260000000002L 346.66194385593224 199.71589999999924L 342.66419491525426 199.71589999999924L 342.66419491525426 226.52405999999974L 342.66419491525426 199.71589999999924L 338.6664459745763 199.71589999999924L 338.6664459745763 197.6260000000002" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 338.6664459745763 198.1260000000002L 342.66419491525426 198.1260000000002L 342.66419491525426 191.47287999999935L 342.66419491525426 198.1260000000002L 346.66194385593224 198.1260000000002L 346.66194385593224 199.71589999999924L 342.66419491525426 199.71589999999924L 342.66419491525426 226.52405999999974L 342.66419491525426 199.71589999999924L 338.6664459745763 199.71589999999924L 338.6664459745763 197.6260000000002" pathFrom="M 338.6664459745763 199.71589999999924M 338.6664459745763 199.71589999999924" cy="198.1260000000002" cx="346.16194385593224" j="30" val="6579" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1325" d="M 350.08858580508473 197.1965199999995L 354.0863347457627 197.1965199999995L 354.0863347457627 193.42967999999928L 354.0863347457627 197.1965199999995L 358.0840836864407 197.1965199999995L 358.0840836864407 205.5618400000003L 354.0863347457627 205.5618400000003L 354.0863347457627 228.04057999999895L 354.0863347457627 205.5618400000003L 350.08858580508473 205.5618400000003L 350.08858580508473 196.6965199999995" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 350.08858580508473 197.1965199999995L 354.0863347457627 197.1965199999995L 354.0863347457627 193.42967999999928L 354.0863347457627 197.1965199999995L 358.0840836864407 197.1965199999995L 358.0840836864407 205.5618400000003L 354.0863347457627 205.5618400000003L 354.0863347457627 228.04057999999895L 354.0863347457627 205.5618400000003L 350.08858580508473 205.5618400000003L 350.08858580508473 196.6965199999995" pathFrom="M 350.08858580508473 205.5618400000003M 350.08858580508473 205.5618400000003" cy="197.1965199999995" cx="357.5840836864407" j="31" val="6575.96" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1326" d="M 361.51072563559325 173.86167999999998L 365.5084745762712 173.86167999999998L 365.5084745762712 173.66599999999926L 365.5084745762712 173.86167999999998L 369.5062235169492 173.86167999999998L 369.5062235169492 205.5618400000003L 365.5084745762712 205.5618400000003L 365.5084745762712 215.8105799999994L 365.5084745762712 205.5618400000003L 361.51072563559325 205.5618400000003L 361.51072563559325 173.36167999999998" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 361.51072563559325 173.86167999999998L 365.5084745762712 173.86167999999998L 365.5084745762712 173.66599999999926L 365.5084745762712 173.86167999999998L 369.5062235169492 173.86167999999998L 369.5062235169492 205.5618400000003L 365.5084745762712 205.5618400000003L 365.5084745762712 215.8105799999994L 365.5084745762712 205.5618400000003L 361.51072563559325 205.5618400000003L 361.51072563559325 173.36167999999998" pathFrom="M 361.51072563559325 205.5618400000003M 361.51072563559325 205.5618400000003" cy="173.86167999999998" cx="369.0062235169492" j="32" val="6588.92" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1327" d="M 372.9328654661017 173.12787999999819L 376.9306144067797 173.12787999999819L 376.9306144067797 161.4359999999997L 376.9306144067797 173.12787999999819L 380.92836334745766 173.12787999999819L 380.92836334745766 173.86167999999998L 376.9306144067797 173.86167999999998L 376.9306144067797 201.67269999999917L 376.9306144067797 173.86167999999998L 372.9328654661017 173.86167999999998L 372.9328654661017 172.62787999999819" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 372.9328654661017 173.12787999999819L 376.9306144067797 173.12787999999819L 376.9306144067797 161.4359999999997L 376.9306144067797 173.12787999999819L 380.92836334745766 173.12787999999819L 380.92836334745766 173.86167999999998L 376.9306144067797 173.86167999999998L 376.9306144067797 201.67269999999917L 376.9306144067797 173.86167999999998L 372.9328654661017 173.86167999999998L 372.9328654661017 172.62787999999819" pathFrom="M 372.9328654661017 173.86167999999998M 372.9328654661017 173.86167999999998" cy="173.12787999999819" cx="380.42836334745766" j="33" val="6589.22" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1328" d="M 384.35500529661016 156.34831999999915L 388.35275423728814 156.34831999999915L 388.35275423728814 149.47505999999885L 388.35275423728814 156.34831999999915L 392.3505031779661 156.34831999999915L 392.3505031779661 172.93219999999928L 388.35275423728814 172.93219999999928L 388.35275423728814 173.42139999999927L 388.35275423728814 172.93219999999928L 384.35500529661016 172.93219999999928L 384.35500529661016 155.84831999999915" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 384.35500529661016 156.34831999999915L 388.35275423728814 156.34831999999915L 388.35275423728814 149.47505999999885L 388.35275423728814 156.34831999999915L 392.3505031779661 156.34831999999915L 392.3505031779661 172.93219999999928L 388.35275423728814 172.93219999999928L 388.35275423728814 173.42139999999927L 388.35275423728814 172.93219999999928L 384.35500529661016 172.93219999999928L 384.35500529661016 155.84831999999915" pathFrom="M 384.35500529661016 172.93219999999928M 384.35500529661016 172.93219999999928" cy="156.34831999999915" cx="391.8505031779661" j="34" val="6596.08" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1329" d="M 395.7771451271187 152.875L 399.77489406779665 152.875L 399.77489406779665 146.76000000000022L 399.77489406779665 152.875L 403.77264300847463 152.875L 403.77264300847463 155.93249999999898L 399.77489406779665 155.93249999999898L 399.77489406779665 175.15805999999975L 399.77489406779665 155.93249999999898L 395.7771451271187 155.93249999999898L 395.7771451271187 152.375" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 395.7771451271187 152.875L 399.77489406779665 152.875L 399.77489406779665 146.76000000000022L 399.77489406779665 152.875L 403.77264300847463 152.875L 403.77264300847463 155.93249999999898L 399.77489406779665 155.93249999999898L 399.77489406779665 175.15805999999975L 399.77489406779665 155.93249999999898L 395.7771451271187 155.93249999999898L 395.7771451271187 152.375" pathFrom="M 395.7771451271187 155.93249999999898M 395.7771451271187 155.93249999999898" cy="152.875" cx="403.27264300847463" j="35" val="6596.25" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1330" d="M 407.1992849576271 151.57862000000023L 411.1970338983051 151.57862000000023L 411.1970338983051 146.76000000000022L 411.1970338983051 151.57862000000023L 415.1947828389831 151.57862000000023L 415.1947828389831 156.61737999999968L 411.1970338983051 156.61737999999968L 411.1970338983051 174.32642000000124L 411.1970338983051 156.61737999999968L 407.1992849576271 156.61737999999968L 407.1992849576271 151.07862000000023" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 407.1992849576271 151.57862000000023L 411.1970338983051 151.57862000000023L 411.1970338983051 146.76000000000022L 411.1970338983051 151.57862000000023L 415.1947828389831 151.57862000000023L 415.1947828389831 156.61737999999968L 411.1970338983051 156.61737999999968L 411.1970338983051 174.32642000000124L 411.1970338983051 156.61737999999968L 407.1992849576271 156.61737999999968L 407.1992849576271 151.07862000000023" pathFrom="M 407.1992849576271 156.61737999999968M 407.1992849576271 156.61737999999968" cy="151.57862000000023" cx="414.6947828389831" j="36" val="6595.97" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1331" d="M 418.6214247881356 141.8680000000004L 422.61917372881356 141.8680000000004L 422.61917372881356 141.84353999999985L 422.61917372881356 141.8680000000004L 426.61692266949154 141.8680000000004L 426.61692266949154 156.61737999999968L 422.61917372881356 156.61737999999968L 422.61917372881356 175.696179999999L 422.61917372881356 156.61737999999968L 418.6214247881356 156.61737999999968L 418.6214247881356 141.3680000000004" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 418.6214247881356 141.8680000000004L 422.61917372881356 141.8680000000004L 422.61917372881356 141.84353999999985L 422.61917372881356 141.8680000000004L 426.61692266949154 141.8680000000004L 426.61692266949154 156.61737999999968L 422.61917372881356 156.61737999999968L 422.61917372881356 175.696179999999L 422.61917372881356 156.61737999999968L 418.6214247881356 156.61737999999968L 418.6214247881356 141.3680000000004" pathFrom="M 418.6214247881356 156.61737999999968M 418.6214247881356 156.61737999999968" cy="141.8680000000004" cx="426.11692266949154" j="37" val="6602" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1332" d="M 430.0435646186441 141.8680000000004L 434.0413135593221 141.8680000000004L 434.0413135593221 129.637999999999L 434.0413135593221 141.8680000000004L 438.03906250000006 141.8680000000004L 438.03906250000006 146.8822999999993L 434.0413135593221 146.8822999999993L 434.0413135593221 155.29653999999937L 434.0413135593221 146.8822999999993L 430.0435646186441 146.8822999999993L 430.0435646186441 141.3680000000004" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 430.0435646186441 141.8680000000004L 434.0413135593221 141.8680000000004L 434.0413135593221 129.637999999999L 434.0413135593221 141.8680000000004L 438.03906250000006 141.8680000000004L 438.03906250000006 146.8822999999993L 434.0413135593221 146.8822999999993L 434.0413135593221 155.29653999999937L 434.0413135593221 146.8822999999993L 430.0435646186441 146.8822999999993L 430.0435646186441 141.3680000000004" pathFrom="M 430.0435646186441 146.8822999999993M 430.0435646186441 146.8822999999993" cy="141.8680000000004" cx="437.53906250000006" j="38" val="6599.95" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1333" d="M 441.46570444915255 145.21901999999864L 445.46345338983053 145.21901999999864L 445.46345338983053 143.80033999999978L 445.46345338983053 145.21901999999864L 449.4612023305085 145.21901999999864L 449.4612023305085 168.72507999999834L 445.46345338983053 168.72507999999834L 445.46345338983053 170.2660599999981L 445.46345338983053 168.72507999999834L 441.46570444915255 168.72507999999834L 441.46570444915255 144.71901999999864" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 441.46570444915255 145.21901999999864L 445.46345338983053 145.21901999999864L 445.46345338983053 143.80033999999978L 445.46345338983053 145.21901999999864L 449.4612023305085 145.21901999999864L 449.4612023305085 168.72507999999834L 445.46345338983053 168.72507999999834L 445.46345338983053 170.2660599999981L 445.46345338983053 168.72507999999834L 441.46570444915255 168.72507999999834L 441.46570444915255 144.71901999999864" pathFrom="M 441.46570444915255 168.72507999999834M 441.46570444915255 168.72507999999834" cy="145.21901999999864" cx="448.9612023305085" j="39" val="6591.02" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1334" d="M 452.887844279661 168.72507999999834L 456.885593220339 168.72507999999834L 456.885593220339 139.22631999999976L 456.885593220339 168.72507999999834L 460.88334216101697 168.72507999999834L 460.88334216101697 168.77399999999943L 456.885593220339 168.77399999999943L 456.885593220339 168.77399999999943L 456.885593220339 168.77399999999943L 452.887844279661 168.77399999999943L 452.887844279661 168.22507999999834" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 452.887844279661 168.72507999999834L 456.885593220339 168.72507999999834L 456.885593220339 139.22631999999976L 456.885593220339 168.72507999999834L 460.88334216101697 168.72507999999834L 460.88334216101697 168.77399999999943L 456.885593220339 168.77399999999943L 456.885593220339 168.77399999999943L 456.885593220339 168.77399999999943L 452.887844279661 168.77399999999943L 452.887844279661 168.22507999999834" pathFrom="M 452.887844279661 168.77399999999943M 452.887844279661 168.77399999999943" cy="168.72507999999834" cx="460.38334216101697" j="40" val="6591" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1335" d="M 464.3099841101695 166.32799999999952L 468.3077330508475 166.32799999999952L 468.3077330508475 143.53128000000106L 468.3077330508475 166.32799999999952L 472.3054819915255 166.32799999999952L 472.3054819915255 168.77399999999943L 468.3077330508475 168.77399999999943L 468.3077330508475 183.4499999999989L 468.3077330508475 168.77399999999943L 464.3099841101695 168.77399999999943L 464.3099841101695 165.82799999999952" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 464.3099841101695 166.32799999999952L 468.3077330508475 166.32799999999952L 468.3077330508475 143.53128000000106L 468.3077330508475 166.32799999999952L 472.3054819915255 166.32799999999952L 472.3054819915255 168.77399999999943L 468.3077330508475 168.77399999999943L 468.3077330508475 183.4499999999989L 468.3077330508475 168.77399999999943L 464.3099841101695 168.77399999999943L 464.3099841101695 165.82799999999952" pathFrom="M 464.3099841101695 168.77399999999943M 464.3099841101695 168.77399999999943" cy="166.32799999999952" cx="471.8054819915255" j="41" val="6592" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1336" d="M 475.732123940678 163.05035999999927L 479.72987288135596 163.05035999999927L 479.72987288135596 156.51953999999932L 479.72987288135596 163.05035999999927L 483.72762182203394 163.05035999999927L 483.72762182203394 163.5640199999998L 479.72987288135596 163.5640199999998L 479.72987288135596 171.21999999999935L 479.72987288135596 163.5640199999998L 475.732123940678 163.5640199999998L 475.732123940678 162.55035999999927" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 475.732123940678 163.05035999999927L 479.72987288135596 163.05035999999927L 479.72987288135596 156.51953999999932L 479.72987288135596 163.05035999999927L 483.72762182203394 163.05035999999927L 483.72762182203394 163.5640199999998L 479.72987288135596 163.5640199999998L 479.72987288135596 171.21999999999935L 479.72987288135596 163.5640199999998L 475.732123940678 163.5640199999998L 475.732123940678 162.55035999999927" pathFrom="M 475.732123940678 163.5640199999998M 475.732123940678 163.5640199999998" cy="163.05035999999927" cx="483.22762182203394" j="42" val="6593.34" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1337" d="M 487.15426377118644 161.77844000000005L 491.1520127118644 161.77844000000005L 491.1520127118644 135.11703999999918L 491.1520127118644 161.77844000000005L 495.1497616525424 161.77844000000005L 495.1497616525424 163.05035999999927L 491.1520127118644 163.05035999999927L 491.1520127118644 189.24701999999888L 491.1520127118644 163.05035999999927L 487.15426377118644 163.05035999999927L 487.15426377118644 161.27844000000005" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 487.15426377118644 161.77844000000005L 491.1520127118644 161.77844000000005L 491.1520127118644 135.11703999999918L 491.1520127118644 161.77844000000005L 495.1497616525424 161.77844000000005L 495.1497616525424 163.05035999999927L 491.1520127118644 163.05035999999927L 491.1520127118644 189.24701999999888L 491.1520127118644 163.05035999999927L 487.15426377118644 163.05035999999927L 487.15426377118644 161.27844000000005" pathFrom="M 487.15426377118644 163.05035999999927M 487.15426377118644 163.05035999999927" cy="161.77844000000005" cx="494.6497616525424" j="43" val="6593.86" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1338" d="M 498.57640360169495 146.73553999999967L 502.57415254237293 146.73553999999967L 502.57415254237293 136.29111999999986L 502.57415254237293 146.73553999999967L 506.5719014830509 146.73553999999967L 506.5719014830509 161.77844000000005L 502.57415254237293 161.77844000000005L 502.57415254237293 179.60978000000068L 502.57415254237293 161.77844000000005L 498.57640360169495 161.77844000000005L 498.57640360169495 146.23553999999967" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 498.57640360169495 146.73553999999967L 502.57415254237293 146.73553999999967L 502.57415254237293 136.29111999999986L 502.57415254237293 146.73553999999967L 506.5719014830509 146.73553999999967L 506.5719014830509 161.77844000000005L 502.57415254237293 161.77844000000005L 502.57415254237293 179.60978000000068L 502.57415254237293 161.77844000000005L 498.57640360169495 161.77844000000005L 498.57640360169495 146.23553999999967" pathFrom="M 498.57640360169495 161.77844000000005M 498.57640360169495 161.77844000000005" cy="146.73553999999967" cx="506.0719014830509" j="44" val="6600.01" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1339" d="M 509.9985434322034 142.332739999998L 513.9962923728814 142.332739999998L 513.9962923728814 138.90833999999995L 513.9962923728814 142.332739999998L 517.9940413135594 142.332739999998L 517.9940413135594 155.93249999999898L 513.9962923728814 155.93249999999898L 513.9962923728814 164.42012000000068L 513.9962923728814 155.93249999999898L 509.9985434322034 155.93249999999898L 509.9985434322034 141.832739999998" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 509.9985434322034 142.332739999998L 513.9962923728814 142.332739999998L 513.9962923728814 138.90833999999995L 513.9962923728814 142.332739999998L 517.9940413135594 142.332739999998L 517.9940413135594 155.93249999999898L 513.9962923728814 155.93249999999898L 513.9962923728814 164.42012000000068L 513.9962923728814 155.93249999999898L 509.9985434322034 155.93249999999898L 509.9985434322034 141.832739999998" pathFrom="M 509.9985434322034 155.93249999999898M 509.9985434322034 155.93249999999898" cy="142.332739999998" cx="517.4940413135594" j="45" val="6596.25" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1340" d="M 521.4206832627119 139.44646000000103L 525.4184322033899 139.44646000000103L 525.4184322033899 136.48680000000058L 525.4184322033899 139.44646000000103L 529.4161811440679 139.44646000000103L 529.4161811440679 155.93249999999898L 525.4184322033899 155.93249999999898L 525.4184322033899 171.21999999999935L 525.4184322033899 155.93249999999898L 521.4206832627119 155.93249999999898L 521.4206832627119 138.94646000000103" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 521.4206832627119 139.44646000000103L 525.4184322033899 139.44646000000103L 525.4184322033899 136.48680000000058L 525.4184322033899 139.44646000000103L 529.4161811440679 139.44646000000103L 529.4161811440679 155.93249999999898L 525.4184322033899 155.93249999999898L 525.4184322033899 171.21999999999935L 525.4184322033899 155.93249999999898L 521.4206832627119 155.93249999999898L 521.4206832627119 138.94646000000103" pathFrom="M 521.4206832627119 155.93249999999898M 521.4206832627119 155.93249999999898" cy="139.44646000000103" cx="528.9161811440679" j="46" val="6602.99" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1341" d="M 532.8428230932203 139.44646000000103L 536.8405720338983 139.44646000000103L 536.8405720338983 132.08399999999892L 536.8405720338983 139.44646000000103L 540.8383209745763 139.44646000000103L 540.8383209745763 176.5767399999986L 536.8405720338983 176.5767399999986L 536.8405720338983 183.47445999999945L 536.8405720338983 176.5767399999986L 532.8428230932203 176.5767399999986L 532.8428230932203 138.94646000000103" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 532.8428230932203 139.44646000000103L 536.8405720338983 139.44646000000103L 536.8405720338983 132.08399999999892L 536.8405720338983 139.44646000000103L 540.8383209745763 139.44646000000103L 540.8383209745763 176.5767399999986L 536.8405720338983 176.5767399999986L 536.8405720338983 183.47445999999945L 536.8405720338983 176.5767399999986L 532.8428230932203 176.5767399999986L 532.8428230932203 138.94646000000103" pathFrom="M 532.8428230932203 176.5767399999986M 532.8428230932203 176.5767399999986" cy="139.44646000000103" cx="540.3383209745763" j="47" val="6587.81" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1342" d="M 544.2649629237288 166.42583999999988L 548.2627118644068 166.42583999999988L 548.2627118644068 158.98999999999978L 548.2627118644068 166.42583999999988L 552.2604608050848 166.42583999999988L 552.2604608050848 176.5767399999986L 548.2627118644068 176.5767399999986L 548.2627118644068 187.68157999999858L 548.2627118644068 176.5767399999986L 544.2649629237288 176.5767399999986L 544.2649629237288 165.92583999999988" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 544.2649629237288 166.42583999999988L 548.2627118644068 166.42583999999988L 548.2627118644068 158.98999999999978L 548.2627118644068 166.42583999999988L 552.2604608050848 166.42583999999988L 552.2604608050848 176.5767399999986L 548.2627118644068 176.5767399999986L 548.2627118644068 187.68157999999858L 548.2627118644068 176.5767399999986L 544.2649629237288 176.5767399999986L 544.2649629237288 165.92583999999988" pathFrom="M 544.2649629237288 176.5767399999986M 544.2649629237288 176.5767399999986" cy="166.42583999999988" cx="551.7604608050848" j="48" val="6591.96" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1343" d="M 555.6871027542373 166.40137999999934L 559.6848516949153 166.40137999999934L 559.6848516949153 156.3727799999997L 559.6848516949153 166.40137999999934L 563.6826006355933 166.40137999999934L 563.6826006355933 175.15805999999975L 559.6848516949153 175.15805999999975L 559.6848516949153 183.4499999999989L 559.6848516949153 175.15805999999975L 555.6871027542373 175.15805999999975L 555.6871027542373 165.90137999999934" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 555.6871027542373 166.40137999999934L 559.6848516949153 166.40137999999934L 559.6848516949153 156.3727799999997L 559.6848516949153 166.40137999999934L 563.6826006355933 166.40137999999934L 563.6826006355933 175.15805999999975L 559.6848516949153 175.15805999999975L 559.6848516949153 183.4499999999989L 559.6848516949153 175.15805999999975L 555.6871027542373 175.15805999999975L 555.6871027542373 165.90137999999934" pathFrom="M 555.6871027542373 175.15805999999975M 555.6871027542373 175.15805999999975" cy="166.40137999999934" cx="563.1826006355933" j="49" val="6588.39" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1344" d="M 567.1092425847457 160.77557999999954L 571.1069915254237 160.77557999999954L 571.1069915254237 151.13833999999952L 571.1069915254237 160.77557999999954L 575.1047404661017 160.77557999999954L 575.1047404661017 177.09039999999914L 571.1069915254237 177.09039999999914L 571.1069915254237 177.09039999999914L 571.1069915254237 177.09039999999914L 567.1092425847457 177.09039999999914L 567.1092425847457 160.27557999999954" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 567.1092425847457 160.77557999999954L 571.1069915254237 160.77557999999954L 571.1069915254237 151.13833999999952L 571.1069915254237 160.77557999999954L 575.1047404661017 160.77557999999954L 575.1047404661017 177.09039999999914L 571.1069915254237 177.09039999999914L 571.1069915254237 177.09039999999914L 571.1069915254237 177.09039999999914L 567.1092425847457 177.09039999999914L 567.1092425847457 160.27557999999954" pathFrom="M 567.1092425847457 177.09039999999914M 567.1092425847457 177.09039999999914" cy="160.77557999999954" cx="574.6047404661017" j="50" val="6594.27" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1345" d="M 578.5313824152543 155.198699999999L 582.5291313559322 155.198699999999L 582.5291313559322 144.3140000000003L 582.5291313559322 155.198699999999L 586.5268802966102 155.198699999999L 586.5268802966102 155.46776000000136L 582.5291313559322 155.46776000000136L 582.5291313559322 171.21999999999935L 582.5291313559322 155.46776000000136L 578.5313824152543 155.46776000000136L 578.5313824152543 154.698699999999" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 578.5313824152543 155.198699999999L 582.5291313559322 155.198699999999L 582.5291313559322 144.3140000000003L 582.5291313559322 155.198699999999L 586.5268802966102 155.198699999999L 586.5268802966102 155.46776000000136L 582.5291313559322 155.46776000000136L 582.5291313559322 171.21999999999935L 582.5291313559322 155.46776000000136L 578.5313824152543 155.46776000000136L 578.5313824152543 154.698699999999" pathFrom="M 578.5313824152543 155.46776000000136M 578.5313824152543 155.46776000000136" cy="155.198699999999" cx="586.0268802966102" j="51" val="6596.55" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1346" d="M 589.9535222457628 146.71107999999913L 593.9512711864407 146.71107999999913L 593.9512711864407 134.52999999999884L 593.9512711864407 146.71107999999913L 597.9490201271187 146.71107999999913L 597.9490201271187 149.42613999999958L 593.9512711864407 149.42613999999958L 593.9512711864407 155.0519400000012L 593.9512711864407 149.42613999999958L 589.9535222457628 149.42613999999958L 589.9535222457628 146.21107999999913" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 589.9535222457628 146.71107999999913L 593.9512711864407 146.71107999999913L 593.9512711864407 134.52999999999884L 593.9512711864407 146.71107999999913L 597.9490201271187 146.71107999999913L 597.9490201271187 149.42613999999958L 593.9512711864407 149.42613999999958L 593.9512711864407 155.0519400000012L 593.9512711864407 149.42613999999958L 589.9535222457628 149.42613999999958L 589.9535222457628 146.21107999999913" pathFrom="M 589.9535222457628 149.42613999999958M 589.9535222457628 149.42613999999958" cy="146.71107999999913" cx="597.4490201271187" j="52" val="6600.02" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1347" d="M 601.3756620762712 145.41469999999936L 605.3734110169491 145.41469999999936L 605.3734110169491 134.52999999999884L 605.3734110169491 145.41469999999936L 609.3711599576271 145.41469999999936L 609.3711599576271 163.85753999999906L 605.3734110169491 163.85753999999906L 605.3734110169491 173.3235599999989L 605.3734110169491 163.85753999999906L 601.3756620762712 163.85753999999906L 601.3756620762712 144.91469999999936" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 601.3756620762712 145.41469999999936L 605.3734110169491 145.41469999999936L 605.3734110169491 134.52999999999884L 605.3734110169491 145.41469999999936L 609.3711599576271 145.41469999999936L 609.3711599576271 163.85753999999906L 605.3734110169491 163.85753999999906L 605.3734110169491 173.3235599999989L 605.3734110169491 163.85753999999906L 601.3756620762712 163.85753999999906L 601.3756620762712 144.91469999999936" pathFrom="M 601.3756620762712 163.85753999999906M 601.3756620762712 163.85753999999906" cy="145.41469999999936" cx="608.8711599576271" j="53" val="6593.01" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1348" d="M 612.7978019067797 139.27523999999903L 616.7955508474577 139.27523999999903L 616.7955508474577 134.52999999999884L 616.7955508474577 139.27523999999903L 620.7932997881356 139.27523999999903L 620.7932997881356 163.51510000000053L 616.7955508474577 163.51510000000053L 616.7955508474577 166.32799999999952L 616.7955508474577 163.51510000000053L 612.7978019067797 163.51510000000053L 612.7978019067797 138.77523999999903" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 612.7978019067797 139.27523999999903L 616.7955508474577 139.27523999999903L 616.7955508474577 134.52999999999884L 616.7955508474577 139.27523999999903L 620.7932997881356 139.27523999999903L 620.7932997881356 163.51510000000053L 616.7955508474577 163.51510000000053L 616.7955508474577 166.32799999999952L 616.7955508474577 163.51510000000053L 612.7978019067797 163.51510000000053L 612.7978019067797 138.77523999999903" pathFrom="M 612.7978019067797 163.51510000000053M 612.7978019067797 163.51510000000053" cy="139.27523999999903" cx="620.2932997881356" j="54" val="6603.06" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1349" d="M 624.2199417372882 137.24505999999928L 628.2176906779662 137.24505999999928L 628.2176906779662 135.7529999999988L 628.2176906779662 137.24505999999928L 632.2154396186442 137.24505999999928L 632.2154396186442 139.2507800000003L 628.2176906779662 139.2507800000003L 628.2176906779662 148.98585999999887L 628.2176906779662 139.2507800000003L 624.2199417372882 139.2507800000003L 624.2199417372882 136.74505999999928" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 624.2199417372882 137.24505999999928L 628.2176906779662 137.24505999999928L 628.2176906779662 135.7529999999988L 628.2176906779662 137.24505999999928L 632.2154396186442 137.24505999999928L 632.2154396186442 139.2507800000003L 628.2176906779662 139.2507800000003L 628.2176906779662 148.98585999999887L 628.2176906779662 139.2507800000003L 624.2199417372882 139.2507800000003L 624.2199417372882 136.74505999999928" pathFrom="M 624.2199417372882 139.2507800000003M 624.2199417372882 139.2507800000003" cy="137.24505999999928" cx="631.7154396186442" j="55" val="6603.89" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1350" d="M 635.6420815677966 135.89976000000024L 639.6398305084746 135.89976000000024L 639.6398305084746 135.89976000000024L 639.6398305084746 135.89976000000024L 643.6375794491526 135.89976000000024L 643.6375794491526 138.19900000000052L 639.6398305084746 138.19900000000052L 639.6398305084746 146.76000000000022L 639.6398305084746 138.19900000000052L 635.6420815677966 138.19900000000052L 635.6420815677966 135.39976000000024" fill="rgba(244,106,106,0.85)" fill-opacity="1" stroke="#f46a6a" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 635.6420815677966 135.89976000000024L 639.6398305084746 135.89976000000024L 639.6398305084746 135.89976000000024L 639.6398305084746 135.89976000000024L 643.6375794491526 135.89976000000024L 643.6375794491526 138.19900000000052L 639.6398305084746 138.19900000000052L 639.6398305084746 146.76000000000022L 639.6398305084746 138.19900000000052L 635.6420815677966 138.19900000000052L 635.6420815677966 135.39976000000024" pathFrom="M 635.6420815677966 138.19900000000052M 635.6420815677966 138.19900000000052" cy="135.89976000000024" cx="643.1375794491526" j="56" val="6603.5" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1351" d="M 647.0642213983051 137.31844000000092L 651.0619703389831 137.31844000000092L 651.0619703389831 137.0004600000011L 651.0619703389831 137.31844000000092L 655.0597192796611 137.31844000000092L 655.0597192796611 138.19900000000052L 651.0619703389831 138.19900000000052L 651.0619703389831 152.875L 651.0619703389831 138.19900000000052L 647.0642213983051 138.19900000000052L 647.0642213983051 136.81844000000092" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 647.0642213983051 137.31844000000092L 651.0619703389831 137.31844000000092L 651.0619703389831 137.0004600000011L 651.0619703389831 137.31844000000092L 655.0597192796611 137.31844000000092L 655.0597192796611 138.19900000000052L 651.0619703389831 138.19900000000052L 651.0619703389831 152.875L 651.0619703389831 138.19900000000052L 647.0642213983051 138.19900000000052L 647.0642213983051 136.81844000000092" pathFrom="M 647.0642213983051 138.19900000000052M 647.0642213983051 138.19900000000052" cy="137.31844000000092" cx="654.5597192796611" j="57" val="6603.86" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1352" d="M 658.4863612288136 136.8047800000004L 662.4841101694916 136.8047800000004L 662.4841101694916 134.52999999999884L 662.4841101694916 136.8047800000004L 666.4818591101696 136.8047800000004L 666.4818591101696 137.34289999999964L 662.4841101694916 137.34289999999964L 662.4841101694916 146.76000000000022L 662.4841101694916 137.34289999999964L 658.4863612288136 137.34289999999964L 658.4863612288136 136.3047800000004" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 658.4863612288136 136.8047800000004L 662.4841101694916 136.8047800000004L 662.4841101694916 134.52999999999884L 662.4841101694916 136.8047800000004L 666.4818591101696 136.8047800000004L 666.4818591101696 137.34289999999964L 662.4841101694916 137.34289999999964L 662.4841101694916 146.76000000000022L 662.4841101694916 137.34289999999964L 658.4863612288136 137.34289999999964L 658.4863612288136 136.3047800000004" pathFrom="M 658.4863612288136 137.34289999999964M 658.4863612288136 137.34289999999964" cy="136.8047800000004" cx="665.9818591101696" j="58" val="6604.07" barWidth="7.995497881355933"></path>
                                                    <path id="SvgjsPath1353" d="M 669.908501059322 132.08399999999892L 673.90625 132.08399999999892L 673.90625 132.08399999999892L 673.90625 132.08399999999892L 677.903998940678 132.08399999999892L 677.903998940678 134.57891999999993L 673.90625 134.57891999999993L 673.90625 136.8047800000004L 673.90625 134.57891999999993L 669.908501059322 134.57891999999993L 669.908501059322 131.58399999999892" fill="rgba(52,195,143,0.85)" fill-opacity="1" stroke="#34c38f" stroke-opacity="1" stroke-linecap="butt" stroke-width="1" stroke-dasharray="0" class="apexcharts-candlestick-area" index="0" clip-path="url(#gridRectMask1e65a5)" pathTo="M 669.908501059322 132.08399999999892L 673.90625 132.08399999999892L 673.90625 132.08399999999892L 673.90625 132.08399999999892L 677.903998940678 132.08399999999892L 677.903998940678 134.57891999999993L 673.90625 134.57891999999993L 673.90625 136.8047800000004L 673.90625 134.57891999999993L 669.908501059322 134.57891999999993L 669.908501059322 131.58399999999892" pathFrom="M 669.908501059322 134.57891999999993M 669.908501059322 134.57891999999993" cy="132.08399999999892" cx="677.403998940678" j="59" val="6606" barWidth="7.995497881355933"></path>
                                                </g>
                                                <g id="SvgjsG1293" class="apexcharts-datalabels"></g>
                                            </g>
                                            <line id="SvgjsLine1438" x1="0" y1="107" x2="673.90625" y2="107" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" class="apexcharts-ycrosshairs"></line>
                                            <line id="SvgjsLine1439" x1="0" y1="107" x2="673.90625" y2="107" stroke-dasharray="0" stroke-width="0" class="apexcharts-ycrosshairs-hidden"></line>
                                            <g id="SvgjsG1440" class="apexcharts-yaxis-annotations" clip-path="url(#gridRectMask1e65a5)"></g>
                                            <g id="SvgjsG1441" class="apexcharts-xaxis-annotations" clip-path="url(#gridRectMask1e65a5)"></g>
                                            <g id="SvgjsG1442" class="apexcharts-point-annotations" clip-path="url(#gridRectMask1e65a5)"></g>
                                            <rect id="SvgjsRect1443" width="0" height="0" x="0" y="0" rx="0" ry="0" fill="#fefefe" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" class="apexcharts-zoom-rect"></rect>
                                            <rect id="SvgjsRect1444" width="0" height="0" x="0" y="0" rx="0" ry="0" fill="#fefefe" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" class="apexcharts-selection-rect"></rect>
                                        </g>
                                        <rect id="SvgjsRect1255" width="0" height="0" x="0" y="0" rx="0" ry="0" fill="#fefefe" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0"></rect>
                                        <g id="SvgjsG1399" class="apexcharts-yaxis" rel="0" transform="translate(41.09375, 0)">
                                            <g id="SvgjsG1400" class="apexcharts-yaxis-texts-g"><text id="SvgjsText1401" font-family="Helvetica, Arial, sans-serif" x="20" y="31.5" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1402">6660.00</tspan>
                                                </text><text id="SvgjsText1403" font-family="Helvetica, Arial, sans-serif" x="20" y="80.42" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1404">6640.00</tspan>
                                                </text><text id="SvgjsText1405" font-family="Helvetica, Arial, sans-serif" x="20" y="129.34" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1406">6620.00</tspan>
                                                </text><text id="SvgjsText1407" font-family="Helvetica, Arial, sans-serif" x="20" y="178.26" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1408">6600.00</tspan>
                                                </text><text id="SvgjsText1409" font-family="Helvetica, Arial, sans-serif" x="20" y="227.18" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1410">6580.00</tspan>
                                                </text><text id="SvgjsText1411" font-family="Helvetica, Arial, sans-serif" x="20" y="276.1" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="regular" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: Helvetica, Arial, sans-serif;">
                                                    <tspan id="SvgjsTspan1412">6560.00</tspan>
                                                </text></g>
                                        </g>
                                    </svg>
                                    <div class="apexcharts-legend"></div>
                                    <div class="apexcharts-tooltip apexcharts-theme-light" style="left: 396.414px; top: 50.5px;">
                                        <div class="apexcharts-tooltip-candlestick">
                                            <div>Open: <span class="value">6593.99</span></div>
                                            <div>High: <span class="value">6598.89</span></div>
                                            <div>Low: <span class="value">6585</span></div>
                                            <div>Close: <span class="value">6587.81</span></div>
                                        </div>
                                    </div>
                                    <div class="apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom apexcharts-theme-light" style="left: 357.414px; top: 276.6px;">
                                        <div class="apexcharts-xaxistooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px; min-width: 43px;">06 Oct</div>
                                    </div>
                                    <div class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light" style="top: 122.5px; left: 39.0938px;">
                                        <div class="apexcharts-yaxistooltip-text">6616.26</div>
                                    </div>
                                </div>
                            </div>
                            <div class="resize-triggers">
                                <div class="expand-trigger">
                                    <div style="width: 756px; height: 311px;"></div>
                                </div>
                                <div class="contract-trigger"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    2020 © Skote.
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-right d-none d-sm-block">
                        Design &amp; Develop by Memento
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>
<script src="assets/libs/apexcharts/apexcharts.min.js"></script>
<script src="assets/js/pages/crypto-exchange.init.js"></script>
<svg id="SvgjsSvg1197" width="2" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" style="overflow: hidden; top: -100%; left: -100%; position: absolute; opacity: 0;">
    <defs id="SvgjsDefs1198"></defs>
    <polyline id="SvgjsPolyline1199" points="0,0"></polyline>
    <path id="SvgjsPath1200" d="M674.2109507415255 134.02799999999843C674.2109507415255 134.02799999999843 678.2343750000001 134.02799999999843 678.2343750000001 134.02799999999843C678.2343750000001 134.02799999999843 678.2343750000001 134.02799999999843 678.2343750000001 134.02799999999843C678.2343750000001 134.02799999999843 678.2343750000001 134.02799999999843 678.2343750000001 134.02799999999843C678.2343750000001 134.02799999999843 682.2577992584746 134.02799999999843 682.2577992584746 134.02799999999843C682.2577992584746 134.02799999999843 682.2577992584746 136.5596399999995 682.2577992584746 136.5596399999995C682.2577992584746 136.5596399999995 678.2343750000001 136.5596399999995 678.2343750000001 136.5596399999995C678.2343750000001 136.5596399999995 678.2343750000001 138.81826 678.2343750000001 138.81826C678.2343750000001 138.81826 678.2343750000001 136.5596399999995 678.2343750000001 136.5596399999995C678.2343750000001 136.5596399999995 674.2109507415255 136.5596399999995 674.2109507415255 136.5596399999995C674.2109507415255 136.5596399999995 674.2109507415255 133.52799999999843 674.2109507415255 133.52799999999843 "></path>
</svg>