<?php include 'header.html' ?>
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->

            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Associations</h4>

                                    <!-- <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);"></a></li>
                                            <li class="breadcrumb-item active">Chat</li>
                                        </ol>
                                    </div> -->

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
        
                                        <!-- Nav tabs -->
                                        <ul class="nav nav-pills nav-justified col-md-10" role="tablist" >
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link active" data-toggle="tab" href="#home-1" role="tab" aria-selected="true">
                                                    <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                                    <span class="d-none d-sm-block">Suggestions</span> 
                                                </a>
                                            </li>
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link" data-toggle="tab" href="#profile-1" role="tab" aria-selected="false">
                                                    <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                                    <span class="d-none d-sm-block">Requests</span> 
                                                </a>
                                            </li>
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link" data-toggle="tab" href="#messages-1" role="tab" aria-selected="false">
                                                    <span class="d-block d-sm-none"><i class="far fa-envelope"></i></span>
                                                    <span class="d-none d-sm-block">Associations</span>   
                                                </a>
                                            </li>
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link" data-toggle="tab" href="#settings-1" role="tab" aria-selected="false">
                                                    <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                                    <span class="d-none d-sm-block">Followers</span>    
                                                </a>
                                            </li>
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link" data-toggle="tab" href="#spam-1" role="tab" aria-selected="false">
                                                    <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                                    <span class="d-none d-sm-block">Following</span>    
                                                </a>
                                            </li>
                                            <div class="search-box chat-search-box " style="border-radius:0px;">
                                        <div class="position-relative">
                                            <input type="text" class="form-control" placeholder="Search...">
                                            <i class="bx bx-search-alt search-icon"></i>
                                            
                                        </div>
                                       
                                    </div>
                                    <li>
                                    <i class="fa fa-fw fa-bars" style="font-size: 14px;font-weight:600"></i>
                                    Filters
                                    </li>
                                        </ul>
                                       
                                        <!-- Tab panes -->
                                        <div class="tab-content p-3 text-muted">
                                            <div class="tab-pane active" id="home-1" role="tabpanel">
                                            

                                            <div class="d-lg-flex">
                                            
                            <div class="chat-leftsidebar mr-lg-6 col-lg-9">
                                <div class="">
                                    <div class="py-4 border-bottom">
                                        <div class="media">
                                            <div class="align-self-center mr-3">
                                                <img src="assets/images/users/avatar-1.jpg" class="avatar-xs rounded-circle" alt="">
                                            </div>
                                            <div class="media-body">
                                                <h5 class="font-size-15 mt-0 mb-1">Sameer</h5>
                                                <p class="text-muted mb-0"><i class="align-middle mr-1"></i> Full Stack Developer<br>Memento Technologies</p>
                                                <p>10 mutual friends</p>
                                            </div>

                                            <div>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="chat-leftsidebar mr-lg-4 col-lg-3">
                                <div class="">
                                <p class="text-center">2 weeks ago</p>
                                    <div class="py-4 border-bottom">
                                  
                                        <div class="media">
                                        
                                            <div class="align-self-center mr-3 text-center">
                                            <i class="bx bx-user-plus " style="font-size: 25px;"></i><br>
                                                <button class="btn-req">Request Associations</button>
                                                <li class="list-inline-item">
                                                        <div class="dropdown">
                                                            <button class="btn nav-btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <i class="bx bx-dots-horizontal-rounded"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-center">
                                                                <a class="dropdown-item" href="#">Message</a>
                                                                <a class="dropdown-item" href="#">Share Profile</a>
                                                                <a class="dropdown-item" href="#">Follow </a>
                                                                <a class="dropdown-item" href="#">Dismiss </a>
                                                                <a class="dropdown-item" href="#">Report/Block </a>



                                                            </div>
                                                        </div>
                                                    </li>
                                            </div>
                                        

                                            <div>
                                               
                                            </div>
                                        </div>
                                    </div>

                                    

                                    
                                       
                                    </div>


                                </div>
                            </div>
                            <div class="d-lg-flex">
                                            
                                            <div class="chat-leftsidebar mr-lg-6 col-lg-9">
                                                <div class="">
                                                    <div class="py-4 border-bottom">
                                                        <div class="media">
                                                            <div class="align-self-center mr-3">
                                                                <img src="assets/images/users/avatar-1.jpg" class="avatar-xs rounded-circle" alt="">
                                                            </div>
                                                            <div class="media-body">
                                                                <h5 class="font-size-15 mt-0 mb-1">Sameer</h5>
                                                                <p class="text-muted mb-0"><i class="align-middle mr-1"></i> Full Stack Developer<br>Memento Technologies</p>
                                                                <p>10 mutual friends</p>
                                                            </div>
                
                                                            <div>
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="chat-leftsidebar mr-lg-4 col-lg-3">
                                                <div class="">
                                                <p class="text-center">2 weeks ago</p>
                                                    <div class="py-4 border-bottom">
                                                  
                                                        <div class="media">
                                                        
                                                            <div class="align-self-center mr-3 text-center">
                                                            <i class="bx bx-user-plus " style="font-size: 25px;"></i><br>
                                                                <button class="btn-req">Request Associations</button>
                                                                <li class="list-inline-item">
                                                                        <div class="dropdown">
                                                                            <button class="btn nav-btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                                <i class="bx bx-dots-horizontal-rounded"></i>
                                                                            </button>
                                                                            <div class="dropdown-menu dropdown-menu-center">
                                                                                <a class="dropdown-item" href="#">Message</a>
                                                                                <a class="dropdown-item" href="#">Share Profile</a>
                                                                                <a class="dropdown-item" href="#">Follow </a>
                                                                                <a class="dropdown-item" href="#">Dismiss </a>
                                                                                <a class="dropdown-item" href="#">Report/Block </a>
                
                
                
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                            </div>
                                                        
                
                                                            <div>
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                
                                                    
                
                                                    
                                                       
                                                    </div>
                
                
                                                </div>
                                            </div>
                       
                       <div class="text-center">
                       <p>
                      <button> No More Suggestions</button><br>
                      Upload Phone Contacts <br>so you can find associations
                       </p>
                       </div>
                                            </div>
                                            <div class="tab-pane" id="profile-1" role="tabpanel">
                                            <p class="text-center">250 associations Request Received</p>
                                            <div class="row">
                                            <button class="btn">Received</button>
                                            <button class="btn">Sent</button>
                                           </div> 
                                            <div class="d-lg-flex">
                                            
                            <div class="chat-leftsidebar mr-lg-6 col-lg-9">
                                <div class="">
                                    <div class="py-4 border-bottom">
                                        <div class="media">
                                            <div class="align-self-center mr-3">
                                                <img src="assets/images/users/avatar-1.jpg" class="avatar-xs rounded-circle" alt="">
                                            </div>
                                            <div class="media-body">
                                                <h5 class="font-size-15 mt-0 mb-1">Sameer</h5>
                                                <p class="text-muted mb-0"><i class="align-middle mr-1"></i> Full Stack Developer<br>Memento Technologies</p>
                                                <p>10 mutual friends</p>
                                            </div>

                                            <div>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="chat-leftsidebar mr-lg-4 col-lg-3">
                                <div class="">
                                <p class="text-center">2 weeks ago</p>
                                    <div class="py-4 border-bottom">
                                  
                                        <div class="media">
                                        
                                            <div class="align-self-center mr-3 text-center">
                                                <button class="btn-req">Accept</button>
                                                <li class="list-inline-item">
                                                        <div class="dropdown">
                                                            <button class="btn nav-btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <i class="bx bx-dots-horizontal-rounded"></i>
                                                            </button>
                                                            <div class="dropdown-menu dropdown-menu-center">
                                                                <a class="dropdown-item" href="#">Decline Request</a>
                                                                <a class="dropdown-item" href="#">Share Profile</a>
                                                                <a class="dropdown-item" href="#">Follow </a>
                                                                <a class="dropdown-item" href="#">Dismiss </a>
                                                                <a class="dropdown-item" href="#">Report/Block </a>



                                                            </div>
                                                        </div>
                                                    </li>
                                            </div>
                                        

                                            <div>
                                               
                                            </div>
                                        </div>
                                    </div>

                                    

                                    
                                       
                                    </div>


                                </div>
                            </div>
                            <div class="d-lg-flex">
                                            
                                            <div class="chat-leftsidebar mr-lg-6 col-lg-9">
                                                <div class="">
                                                    <div class="py-4 border-bottom">
                                                        <div class="media">
                                                            <div class="align-self-center mr-3">
                                                                <img src="assets/images/users/avatar-1.jpg" class="avatar-xs rounded-circle" alt="">
                                                            </div>
                                                            <div class="media-body">
                                                                <h5 class="font-size-15 mt-0 mb-1">Sameer</h5>
                                                                <p class="text-muted mb-0"><i class="align-middle mr-1"></i> Full Stack Developer<br>Memento Technologies</p>
                                                                <p>10 mutual friends</p>
                                                            </div>
                
                                                            <div>
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="chat-leftsidebar mr-lg-4 col-lg-3">
                                                <div class="">
                                                <p class="text-center">2 weeks ago</p>
                                                    <div class="py-4 border-bottom">
                                                  
                                                        <div class="media">
                                                        
                                                            <div class="align-self-center mr-3 text-center">
                                                                <button class="btn-req">accept</button>
                                                                <li class="list-inline-item">
                                                                        <div class="dropdown">
                                                                            <button class="btn nav-btn dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                                <i class="bx bx-dots-horizontal-rounded"></i>
                                                                            </button>
                                                                            <div class="dropdown-menu dropdown-menu-center">
                                                                                <a class="dropdown-item" href="#">Message</a>
                                                                                <a class="dropdown-item" href="#">Share Profile</a>
                                                                                <a class="dropdown-item" href="#">Follow </a>
                                                                                <a class="dropdown-item" href="#">Dismiss </a>
                                                                                <a class="dropdown-item" href="#">Report/Block </a>
                
                
                
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                            </div>
                                                        
                
                                                            <div>
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                
                                                    
                
                                                    
                                                       
                                                    </div>
                
                
                                                </div>
                                            </div>
                       
                       <div class="text-center">
                       <p>
                      <button> No More Suggestions</button><br>
                      Upload Phone Contacts <br>so you can find associations
                       </p>
                       </div>
                                            </div>
                                            <div class="tab-pane" id="messages-1" role="tabpanel">
                                                <p class="mb-0">
                                                Dynamic Data will call.
                                                </p>
                                            </div>
                                            <div class="tab-pane" id="settings-1" role="tabpanel">
                                                <p class="mb-0">
                                                Dynamic Data will call.
                                                </p>
                                            </div>
                                       
                                        <div class="tab-pane" id="spam-1" role="tabpanel">
                                                <p class="mb-0">
                                                Dynamic Data will call.
                                                </p>
                                            </div>
                                        
                                        <div class="tab-pane" id="jobs-1" role="tabpanel">
                                                <p class="mb-0">
                                                Dynamic Data will call.
                                                </p>
                                            </div>
                                        </div>
        
                                    </div>
                                </div>
                            </div>
            
                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->

    