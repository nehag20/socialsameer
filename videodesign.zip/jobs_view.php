<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-9">
                    <div class="post-wrapper mt-3 mb-3">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="w-25">
                                    <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                </div>
                                <div class="w-70" style="float: left; padding-left : 20px;">
                                    <span class="username">Small Business Advisor</span>
                                    <p>Full Time - Permanent</p>
                                    <span class="username" style="padding-top: 15px;">Socia Bank</span>
                                    <p>Vancouver, Canada</p>
                                </div>
                                <div class="w-10">
                                    <div class="dropdown">
                                        <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                        </a>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="#">Share</a>
                                            <a class="dropdown-item" href="#">Edit Post</a>
                                            <a class="dropdown-item" href="#">Disable Comments</a>
                                            <a class="dropdown-item" href="#">Add Favourite</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <ul class="jobs">
                                    <li>
                                        <button class="btn btn-primary pl-5 pr-5">Apply</button>
                                    </li>
                                    <li>
                                        <button class="btn btn-secondary pl-5 pr-5">Save</button>
                                    </li>
                                    <li>Posted 2 days ago</li>
                                    <li>125 Views</li>
                                    <li>80 Applicants</li>
                                </ul>
                            </div>
                            <div class="col-lg-12 mt-5">
                                <ul class="nav nav-pills nav-justified" role="tablist">
                                    <li class="nav-item waves-effect waves-light">
                                        <a class="nav-link active" data-toggle="tab" href="#job" role="tab" aria-selected="true">
                                            <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                            <span class="d-none d-sm-block">Job Description</span>
                                        </a>
                                    </li>
                                    <li class="nav-item waves-effect waves-light">
                                        <a class="nav-link" data-toggle="tab" href="#about" role="tab" aria-selected="false">
                                            <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                            <span class="d-none d-sm-block">About Company</span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="tab-content p-3 text-muted">
                                    <div class="tab-pane active" id="job" role="tabpanel">
                                        <p class="mb-0">
                                            Raw denim you probably haven't heard of them jean shorts Austin.
                                            Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache
                                            cliche tempor, williamsburg carles vegan helvetica. Reprehenderit
                                            butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi,
                                            qui irure terry richardson ex squid. Aliquip placeat salvia cillum
                                            iphone. Seitan aliquip quis cardigan american apparel, butcher
                                            voluptate nisi qui.
                                        </p>
                                    </div>
                                    <div class="tab-pane" id="about" role="tabpanel">
                                        <p class="mb-0">
                                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quae voluptas dicta sapiente vitae deleniti. Similique alias eos exercitationem nulla rem corrupti dolorum quam porro laudantium nisi. At, cupiditate repellat. Nulla?
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="user-chat">
                        <div class="card">
                            <div class="p-4 border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="profile-card text-center">
                                            <img src="assets/images/users/avatar-2.jpg" alt="" class="img-fluid rounded-circle">
                                        </div>
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">Steven Franklin</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Full Stack Developer at Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="p-4 border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">250</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Associates</p>
                                    </div>
                                    <div class="col-md-12">
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">50</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Mutual Associates</p>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="text-dark pb-1 pt-3 text-center font-size-18">Association since Oct 31st 2019</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

</div>

</div>
</div>
<!-- /Right-bar -->