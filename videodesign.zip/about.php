<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="cover-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/group/group-cover.jpg" alt="">
                    </div>
                    <div class="profile-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                    </div>
                    <i class="fa fa-camera upload-image" aria-hidden="true"></i>
                    <h1 class="about-username">John Smith</h1>
                    <p><b>Assitant Manager</b> @ deolite, Toranto,British Colombia,Canada.</p>
                </div>
                <!-- end page title -->
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#all" role="tab" aria-selected="true">
                                        <span class="d-block d-sm-none"><i class="fas fa-users-cog"></i></span>
                                        <span class="d-none d-sm-block">About</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#unread" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-clock"></i></span>
                                        <span class="d-none d-sm-block">Activity</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#archieve" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-users"></i></span>
                                        <span class="d-none d-sm-block">Associations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                        <span class="d-none d-sm-block">Recommendations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#appointment" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="far fa-calendar-alt"></i></span>
                                        <span class="d-none d-sm-block">Appointment</span>
                                    </a>
                                </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content text-muted">
                                <div class="tab-pane active" id="all" role="tabpanel">
                                    <div class="row">
                                        <div class="col-12">
                                            <h3 class="pt-3">About</h3>
                                            <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae suscipit cum ipsam, corrupti nisi beatae fugit impedit assumenda quidem incidunt, doloremque non quibusdam ea, id aspernatur. Autem voluptates dolore non? Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae suscipit cum ipsam, corrupti nisi beatae fugit impedit assumenda quidem incidunt, doloremque non quibusdam ea, id aspernatur. Autem voluptates dolore non?</p>
                                        </div>
                                        <div class="col-12">
                                            <h3 class="pt-3 pb-3">Career Journey</h3>
                                            <ul class="career">
                                                <li>
                                                    <div>
                                                        <div>
                                                            <img src="http://mahorgwarevaish.in/social/assets/images/icons/market.png" alt="" class="rounded-circle">
                                                        </div>
                                                    </div>

                                                </li>
                                                <li>
                                                    <h4 class="font-weight-bold">Full Stack Developer</h4>
                                                    <b>Memento Technologies</b>
                                                    <p>Jan 2020 - Present 6 Months<br>Bangalore</p>
                                                </li>
                                            </ul>
                                            <br>
                                            <ul class="career">
                                                <li>
                                                    <div>
                                                        <div>
                                                            <img src="http://mahorgwarevaish.in/social/assets/images/icons/market.png" alt="" class="rounded-circle">
                                                        </div>
                                                    </div>

                                                </li>
                                                <li>
                                                    <h4 class="font-weight-bold">Full Stack Developer</h4>
                                                    <b>Memento Technologies</b>
                                                    <p>Jan 2020 - Present 6 Months<br>Bangalore</p>
                                                </li>
                                            </ul>
                                            <br>
                                            <ul class="career">
                                                <li>
                                                    <div>
                                                        <div>
                                                            <img src="http://mahorgwarevaish.in/social/assets/images/icons/market.png" alt="" class="rounded-circle">
                                                        </div>
                                                    </div>

                                                </li>
                                                <li>
                                                    <h4 class="font-weight-bold">Full Stack Developer</h4>
                                                    <b>Memento Technologies</b>
                                                    <p>Jan 2020 - Present 6 Months<br>Bangalore</p>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-12">
                                            <h3 class="pt-3">Academic</h3>
                                        </div>
                                        <div class="col-lg-4">
                                            <table class="table academic-table">
                                                <tbody>
                                                    <tr>
                                                        <td>Course</td>
                                                        <td>MBA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Specilization</td>
                                                        <td>Management</td>
                                                    </tr>
                                                    <tr>
                                                        <td>University / College</td>
                                                        <td>MANIT</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Start Year</td>
                                                        <td>2016</td>
                                                    </tr>
                                                    <tr>
                                                        <td>End Year</td>
                                                        <td>2019</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Projects</td>
                                                        <td>The following classes will transform text</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-4">
                                            <table class="table academic-table">
                                                <tbody>
                                                    <tr>
                                                        <td>Course</td>
                                                        <td>MBA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Specilization</td>
                                                        <td>Management</td>
                                                    </tr>
                                                    <tr>
                                                        <td>University / College</td>
                                                        <td>MANIT</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Start Year</td>
                                                        <td>2016</td>
                                                    </tr>
                                                    <tr>
                                                        <td>End Year</td>
                                                        <td>2019</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Projects</td>
                                                        <td>The following classes will transform text</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-4">
                                            <table class="table academic-table">
                                                <tbody>
                                                    <tr>
                                                        <td>Course</td>
                                                        <td>MBA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Specilization</td>
                                                        <td>Management</td>
                                                    </tr>
                                                    <tr>
                                                        <td>University / College</td>
                                                        <td>MANIT</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Start Year</td>
                                                        <td>2016</td>
                                                    </tr>
                                                    <tr>
                                                        <td>End Year</td>
                                                        <td>2019</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Projects</td>
                                                        <td>The following classes will transform text</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-6">
                                            <h3 class="pt-3">Certifications</h3>
                                            <table class="table academic-table">
                                                <tbody>
                                                    <tr>
                                                        <td>Course</td>
                                                        <td>MBA</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Institute</td>
                                                        <td>IIT Delhi</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Start Year</td>
                                                        <td>2016</td>
                                                    </tr>
                                                    <tr>
                                                        <td>End Year</td>
                                                        <td>2019</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-6">
                                            <h3 class="pt-3">Language Proficiency</h3>
                                            <table class="table academic-table">
                                                <tbody>
                                                    <tr>
                                                        <td>Hindi</td>
                                                        <td>Expert</td>
                                                    </tr>
                                                    <tr>
                                                        <td>English</td>
                                                        <td>Advance</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Punjabi</td>
                                                        <td>Advance</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Gujrati</td>
                                                        <td>Expert</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-12">
                                            <h3 class="pt-3">Achievement</h3>
                                            <ol class="achivement">
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                            </ol>
                                        </div>
                                        <div class="col-lg-6">
                                            <h3 class="pt-3">Hard Skills</h3>
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <td>1. Gathering Software Requirement</td>
                                                        <td>2. Forklift Operation</td>
                                                    </tr>
                                                    <tr>
                                                        <td>3. Marketing Skills</td>
                                                        <td>4. Phlebotomy</td>
                                                    </tr>
                                                    <tr>
                                                        <td>5. IT Skills</td>
                                                        <td>6. Shelf Stocking</td>
                                                    </tr>
                                                    <tr>
                                                        <td>7. Leadership</td>
                                                        <td>8. Time Management</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-6">
                                            <h3 class="pt-3">Soft Skills</h3>
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <td>1. Good Attitude</td>
                                                        <td>2. Active Learning</td>
                                                    </tr>
                                                    <tr>
                                                        <td>3. Strong Work Ethic</td>
                                                        <td>4. Problem Solving</td>
                                                    </tr>
                                                    <tr>
                                                        <td>5. Flexibility/Adaptability</td>
                                                        <td>6. Self Confidence</td>
                                                    </tr>
                                                    <tr>
                                                        <td>7. Self Motivated</td>
                                                        <td>8. Honesty</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-12">
                                            <h3 class="pt-3">Interests</h3>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="intrest">
                                                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                                                        <span>Memento Technologies</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="appointment" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h4 class="card-title">Please enter date and time for appointment</h4>
                                                    <div class="form-group row">
                                                        <label for="example-datetime-local-input" class="col-md-2 col-form-label">Date and time</label>
                                                        <div class="col-md-10">
                                                            <input class="form-control" type="datetime-local" value="2019-08-19T13:45:00" id="example-datetime-local-input">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> <!-- end col -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>