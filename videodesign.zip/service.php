<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="cover-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/group/group-cover.jpg" alt="">
                    </div>
                    <div class="profile-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                    </div>
                    <i class="fa fa-camera upload-image" aria-hidden="true"></i>
                    <h1 class="about-username">John Smith</h1>
                    <p><b>Assitant Manager</b> @ deolite, Toranto,British Colombia,Canada.</p>
                </div>
                <!-- end page title -->
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#all" role="tab" aria-selected="true">
                                        <span class="d-block d-sm-none"><i class="fas fa-users-cog"></i></span>
                                        <span class="d-none d-sm-block">About</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#unread" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-clock"></i></span>
                                        <span class="d-none d-sm-block">Activity</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#archieve" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-users"></i></span>
                                        <span class="d-none d-sm-block">Associations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                        <span class="d-none d-sm-block">Recommendations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#appointment" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="far fa-calendar-alt"></i></span>
                                        <span class="d-none d-sm-block">Appointment</span>
                                    </a>
                                </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content text-muted">
                                <div class="tab-pane active" id="all" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-8">
                                            <h3 class="pt-3">Talk To An HR Proffesionals</h3>
                                            <h5>Service Description</h5>
                                            <p class="text-justify font-size-15">Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae suscipit cum ipsam, corrupti nisi beatae fugit impedit assumenda quidem incidunt, doloremque non quibusdam ea, id aspernatur. Autem voluptates dolore non? Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae suscipit cum ipsam, corrupti nisi beatae fugit impedit assumenda quidem incidunt, doloremque non quibusdam ea, id aspernatur. Autem voluptates dolore non?</p>
                                            <h3 class="pt-3">Achievement</h3>
                                            <ol class="achivement">
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                                <li>Add this class to emphasize text.</li>
                                            </ol>
                                        </div>
                                        <div class="col-lg-4">
                                            <div>
                                                <img src="assets/images/girls.jpg" alt="" class="img-fluid" style="border-radius: 15px;">
                                            </div>
                                            <p class="prices pt-2 mb-0">Price : $2200</p>
                                            <p class="prices mb-0">Length : 5.2 Feet</p>
                                            <p class="prices mb-0">Subject : English</p>
                                            <p class="prices">Language : English</p>
                                            <button class="btn btn-primary btn-block">Add To Cart</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>