<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="cover-image">
                        <img src="assets/images/cover/group-cover.jpg" alt="">
                    </div>
                    <div class="profile-image">
                        <img src="assets/images/avatar/profile.jpg" alt="">
                    </div>
                    <i class="fa fa-camera upload-image" aria-hidden="true"></i>
                    <h1 class="about-username">John Smith</h1>
                    <p><b>Assitant Manager</b> @ deolite, Toranto,British Colombia,Canada.</p>
                </div>
                <!-- end page title -->
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#all" role="tab" aria-selected="true">
                                        <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                        <span class="d-none d-sm-block">About</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#unread" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                        <span class="d-none d-sm-block">Content</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#followers" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="far fa-envelope"></i></span>
                                        <span class="d-none d-sm-block">Followers</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#following" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                        <span class="d-none d-sm-block">Following</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#spam-1" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                        <span class="d-none d-sm-block">Recommendations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#spam-1" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                        <span class="d-none d-sm-block">Schedule an Appointment</span>
                                    </a>
                                </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content text-muted">
                                <div class="tab-pane active" id="followers" role="tabpanel">
                                    <div class="row">
                                        <div class="col-12">
                                            <h3 class="pt-3">Followers</h3>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Following</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Following</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Following</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Following</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Following</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Following</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="following" role="tabpanel">
                                    <div class="row">
                                        <div class="col-12">
                                            <h3 class="pt-3">Following</h3>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Unfollow</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Unfollow</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Unfollow</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Unfollow</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Unfollow</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 pb-3">
                                            <div class="row">
                                                <div class="col-lg-2">
                                                    <div class="follow-profile">
                                                        <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                                    </div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="follow-text">
                                                        <h4>Stella Johnson</h4>
                                                        <p>Assitant Manager @ deolite, Toranto,British Colombia,Canada</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-5 text-right pt-3 follow-btn">
                                                    <button class="btn btn-primary btn-lg">Unfollow</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>