<?php include 'header2.html' ?>
<div class="main-content">
    <div class="page-content" style="padding-bottom:200px!important">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-4">
                    <ul class="nav nav-pills nav-justified" role="tablist">
                        <li class="nav-item waves-effect waves-light">
                            <a class="nav-link" data-toggle="tab" href="#job" role="tab" aria-selected="true">
                                <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                <span class="d-none d-sm-block">All</span>
                            </a>
                        </li>
                        <li class="nav-item waves-effect waves-light">
                            <a class="nav-link" data-toggle="tab" href="#about" role="tab" aria-selected="false">
                                <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                <span class="d-none d-sm-block">Open</span>
                            </a>
                        </li>
                        <li class="nav-item waves-effect waves-light">
                            <a class="nav-link" data-toggle="tab" href="#job" role="tab" aria-selected="true">
                                <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                <span class="d-none d-sm-block">Closed</span>
                            </a>
                        </li>
                        <li class="nav-item waves-effect waves-light">
                            <a class="nav-link active" data-toggle="tab" href="#about" role="tab" aria-selected="false">
                                <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                <span class="d-none d-sm-block">Drafts</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-lg-12 d-flex justify-content-end">
                            <div class="row">
                                <div class="col-lg-8 mb-3">
                                    <form>
                                        <div class="position-relative">
                                            <input type="text" class="custom-input form-control"
                                                placeholder="Search...">
                                            <span class="bx bx-search-alt custom-search"></span>
                                            <span class="bx bxs-microphone custom-voice"></span>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-4 mb-3 d-flex align-items-center">
                                    <div class="filter">
                                        <a href="#" type="button" id="filter">
                                            <i class="fas fa-bars"></i>
                                            <span class="text-dark">Filters</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12" id="filter-items">
                            <div class="row">
                                <div class="col-lg-3">
                                    <select class="form-control">
                                        <option>Sort</option>
                                        <option>Large select</option>
                                        <option>Small select</option>
                                    </select>
                                </div>
                                <div class="col-lg-3">
                                    <select class="form-control">
                                        <option>Title</option>
                                        <option>Large select</option>
                                        <option>Small select</option>
                                    </select>
                                </div>
                                <div class="col-lg-3">
                                    <select class="form-control">
                                        <option>Location</option>
                                        <option>Large select</option>
                                        <option>Small select</option>
                                    </select>
                                </div>
                                <div class="col-lg-3">
                                    <select class="form-control">
                                        <option>Employment Type</option>
                                        <option>Large select</option>
                                        <option>Small select</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-lg-12 hr">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="w-25">
                                <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="name-info">
                                <span class="username">Small Business Advisor</span>
                                <p>Full Time - Permanent</p>
                                <p>ICBC (Insurance Corporation of British Columbia) <br> Surry, BC, Canada</p>
                                <small class="pt-2 pb-2">Started 2W Ago</small>
                            </div>
                        </div>
                        <div class="col-lg-6 text-center">
                            <p class="mt-4">Job Id. SEF230987</p>


                            <ul class="list-inline user-chat-nav mb-0">
                                <li class="list-inline-item d-none d-sm-inline-block">
                                    <div class="dropdown">
                                    <button type="button"
                                    class="btn btn-primary waves-effect btn-sm waves-light">Unsaved</button>
                                        </button>
                                    </div>
                                </li>
                                <li class="list-inline-item  d-none d-sm-inline-block">
                                    <div class="dropdown">
                                        <button class="btn dropdown-toggle" type="button" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            <i class="bx bx-dots-horizontal-rounded" style="font-size: 25px;"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="#"><i class="far fa-eye"></i> View Profile</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-user-check"></i> Request Association</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-envelope"></i> Message</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-plus"></i> Follow (See content of sameer without associating)</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-share"></i> Share Profile</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-minus-circle"></i> Dismiss</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-ban"></i> Report/Block</a> 
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 hr">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="w-25">
                                <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="name-info">
                                <span class="username">Small Business Advisor</span>
                                <p>Full Time - Permanent</p>
                                <p>ICBC (Insurance Corporation of British Columbia) <br> Surry, BC, Canada</p>
                                <small class="pt-2 pb-2">Started 2W Ago</small>
                            </div>
                        </div>
                        <div class="col-lg-6 text-center">
                            <p class="mt-4">Job Id. SEF230987</p>


                            <ul class="list-inline user-chat-nav mb-0">
                                <li class="list-inline-item d-none d-sm-inline-block">
                                    <div class="dropdown">
                                    <button type="button"
                                    class="btn btn-primary waves-effect btn-sm waves-light">Unsaved</button>
                                        </button>
                                    </div>
                                </li>
                                <li class="list-inline-item  d-none d-sm-inline-block">
                                    <div class="dropdown">
                                        <button class="btn dropdown-toggle" type="button" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            <i class="bx bx-dots-horizontal-rounded" style="font-size: 25px;"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="#"><i class="far fa-eye"></i> View Profile</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-user-check"></i> Request Association</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-envelope"></i> Message</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-plus"></i> Follow (See content of sameer without associating)</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-share"></i> Share Profile</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-minus-circle"></i> Dismiss</a>
                                            <a class="dropdown-item" href="#"><i class="fas fa-ban"></i> Report/Block</a> 
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

</div>

</div>
</div>
<!-- /Right-bar -->




<!-- <div class="tab-content p-3 text-muted">
                        <div class="tab-pane active" id="job" role="tabpanel">
                            <p class="mb-0">
                                Raw denim you probably haven't heard of them jean shorts Austin.
                                Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache
                                cliche tempor, williamsburg carles vegan helvetica. Reprehenderit
                                butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi,
                                qui irure terry richardson ex squid. Aliquip placeat salvia cillum
                                iphone. Seitan aliquip quis cardigan american apparel, butcher
                                voluptate nisi qui.
                            </p>
                        </div>
                        <div class="tab-pane" id="about" role="tabpanel">
                            <p class="mb-0">
                                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quae voluptas dicta sapiente
                                vitae deleniti. Similique alias eos exercitationem nulla rem corrupti dolorum quam porro
                                laudantium nisi. At, cupiditate repellat. Nulla?
                            </p>
                        </div>
                    </div> -->