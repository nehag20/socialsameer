<?php include 'header4.html' ?>


<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <h3 class="font-size-16">Manage your Service</h3>

         <div class="row">


            <div class="col-lg-12">
               <div class="card">
                  <div class="card-body">
                     <h4 class="card-title mb-4">Plese Select the Service To see upcoming opponments,update the calendear and request change</h4>

                     <div class="row my-2">
                        <div class="col-lg-8 bg-primary h-80 text-light">Talk to HR professional</div>
                        <div class="d-flex col-lg-4">
                          <button class="btn btn-primary m-auto">0 <br> Appoitment</button>
                           <button class="btn btn-primary m-auto">update <br> calendar</button>
                        </div>
                     </div>
                     <div class="row my-2">
                        <div class="col-lg-8 bg-primary h-80 text-light">Talk to HR professional</div>
                        <div class="d-flex col-lg-4">
                          <button class="btn btn-primary m-auto">0 <br> Appoitment</button>
                           <button class="btn btn-primary m-auto">update <br> calendar</button>
                        </div>
                     </div>
                     <div class="row my-2">
                        <div class="col-lg-8 bg-primary h-80 text-light">Talk to HR professional</div>
                        <div class="d-flex col-lg-4">
                          <button class="btn btn-primary m-auto">0 <br> Appoitment</button>
                           <button class="btn btn-primary m-auto">update <br> calendar</button>
                        </div>
                     </div>
                     <div class="row my-2 ">
                        <a href="javascript:void(0)">
                           Click more service? click here
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>