<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Select Box</h4>
                                </div>
                            </div>
                        </div>
            <!-- end page title -->
        
                        <div class="row justify-content-center text-right">
                            <div class="col-8">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <select class="form-control">
                                                    <option>ICBC</option>
                                                    <option>Large select</option>
                                                    <option>Small select</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <select class="form-control">
                                                    <option>Business Insights Analytics</option>
                                                    <option>Large select</option>
                                                    <option>Small select</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <select class="form-control">
                                                    <option>Temporay</option>
                                                    <option>Large select</option>
                                                    <option>Small select</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <select class="form-control">
                                                    <option>Surrey, BC</option>
                                                    <option>Large select</option>
                                                    <option>Small select</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group mb-0">
                                                <div>
                                                    
                                                    <button type="reset" class="btn btn-secondary waves-effect">
                                                        Cancel
                                                    </button>
                                                    <button type="submit" class="btn btn-primary waves-effect waves-light mr-1">
                                                        Next
                                                    </button>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->                      
        </div>
    </div>
</div>
