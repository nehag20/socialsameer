<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="cover-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/group/group-cover.jpg" alt="">
                    </div>
                    <div class="profile-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                    </div>
                    <i class="fa fa-camera upload-image" aria-hidden="true"></i>
                    <h1 class="about-username">John Smith</h1>
                    <p><b>Assitant Manager</b> @ deolite, Toranto,British Colombia,Canada.</p>
                </div>
                <!-- end page title -->
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#all" role="tab" aria-selected="true">
                                        <span class="d-block d-sm-none"><i class="fas fa-users-cog"></i></span>
                                        <span class="d-none d-sm-block">About</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#unread" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-clock"></i></span>
                                        <span class="d-none d-sm-block">Activity</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#archieve" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-users"></i></span>
                                        <span class="d-none d-sm-block">Associations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#messages" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                        <span class="d-none d-sm-block">Recommendations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#appointment" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="far fa-calendar-alt"></i></span>
                                        <span class="d-none d-sm-block">Appointment</span>
                                    </a>
                                </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content text-muted">
                                <div class="tab-pane active" id="all" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-9">
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                        <div class="embed-responsive embed-responsive-21by9 mb-4">
                                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Jv8KRwF1zQs" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center m-0"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <h5 class="font-size-15 mb-3 mt-3">Invites</h5>
                                            <div class="text-center">
                                                <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                            </div>
                                            <div class="text-center pt-3 pb-3">
                                                <button class="btn btn-primary" style="background-color: #532574;border: none;outline: none;">Sent Friend Request</button>
                                            </div>
                                            <div class="d-lg-flex">
                                                <div class="profile-chat-leftsidebar chat-leftsidebar mr-lg-4">
                                                    <h5 class="font-size-15 mb-3 mt-3">Contacts</h5>
                                                    <div class="chat-leftsidebar-nav">
                                                        <ul class="nav nav-pills nav-justified">
                                                            <li class="nav-item">
                                                                <a href="#chat" data-toggle="tab" aria-expanded="true" class="nav-link active">
                                                                    <i class="bx bx-chat font-size-20 d-sm-none"></i>
                                                                    <span class="d-none d-sm-block">Friends</span>
                                                                </a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a href="#group" data-toggle="tab" aria-expanded="false" class="nav-link">
                                                                    <i class="bx bx-group font-size-20 d-sm-none"></i>
                                                                    <span class="d-none d-sm-block">Group</span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                        <div class="tab-content py-4">
                                                            <div class="tab-pane show active" id="chat">
                                                                <div>
                                                                    <ul class="list-unstyled chat-list" data-simplebar="init" style="max-height: 410px;">
                                                                        <div class="simplebar-wrapper" style="margin: 0px;">
                                                                            <div class="simplebar-height-auto-observer-wrapper">
                                                                                <div class="simplebar-height-auto-observer"></div>
                                                                            </div>
                                                                            <div class="simplebar-mask">
                                                                                <div class="simplebar-offset" style="right: -17px; bottom: 0px;">
                                                                                    <div class="simplebar-content-wrapper" style="height: auto; overflow: hidden scroll;">
                                                                                        <div class="simplebar-content" style="padding: 0px;">
                                                                                            <li class="active">
                                                                                                <a href="#">
                                                                                                    <div class="media">
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <i class="mdi mdi-circle font-size-10"></i>
                                                                                                        </div>
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <img src="assets/images/users/avatar-2.jpg" class="rounded-circle avatar-xs" alt="">
                                                                                                        </div>

                                                                                                        <div class="media-body overflow-hidden">
                                                                                                            <h5 class="text-truncate font-size-14 mb-1">Steven Franklin</h5>
                                                                                                            <p class="text-truncate mb-0">Hey! there I'm available</p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </a>
                                                                                            </li>

                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <div class="media">
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <i class="mdi mdi-circle text-success font-size-10"></i>
                                                                                                        </div>
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <img src="assets/images/users/avatar-3.jpg" class="rounded-circle avatar-xs" alt="">
                                                                                                        </div>
                                                                                                        <div class="media-body overflow-hidden">
                                                                                                            <h5 class="text-truncate font-size-14 mb-1">Adam Miller</h5>
                                                                                                            <p class="text-truncate mb-0">I've finished it! See you so</p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </a>
                                                                                            </li>

                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <div class="media">
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <i class="mdi mdi-circle text-success font-size-10"></i>
                                                                                                        </div>
                                                                                                        <div class="avatar-xs align-self-center mr-3">
                                                                                                            <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                                K
                                                                                                            </span>
                                                                                                        </div>
                                                                                                        <div class="media-body overflow-hidden">
                                                                                                            <h5 class="text-truncate font-size-14 mb-1">Keith Gonzales</h5>
                                                                                                            <p class="text-truncate mb-0">This theme is awesome!</p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </a>
                                                                                            </li>

                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <div class="media">
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <i class="mdi mdi-circle text-warning font-size-10"></i>
                                                                                                        </div>
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <img src="assets/images/users/avatar-4.jpg" class="rounded-circle avatar-xs" alt="">
                                                                                                        </div>
                                                                                                        <div class="media-body overflow-hidden">
                                                                                                            <h5 class="text-truncate font-size-14 mb-1">Jose Vickery</h5>
                                                                                                            <p class="text-truncate mb-0">Nice to meet you</p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </a>
                                                                                            </li>
                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <div class="media">
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <i class="mdi mdi-circle font-size-10"></i>
                                                                                                        </div>

                                                                                                        <div class="avatar-xs align-self-center mr-3">
                                                                                                            <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                                M
                                                                                                            </span>
                                                                                                        </div>
                                                                                                        <div class="media-body overflow-hidden">
                                                                                                            <h5 class="text-truncate font-size-14 mb-1">Mitchel Givens</h5>
                                                                                                            <p class="text-truncate mb-0">Hey! there I'm available</p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </a>
                                                                                            </li>

                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <div class="media">
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <i class="mdi mdi-circle text-success font-size-10"></i>
                                                                                                        </div>
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <img src="assets/images/users/avatar-6.jpg" class="rounded-circle avatar-xs" alt="">
                                                                                                        </div>
                                                                                                        <div class="media-body overflow-hidden">
                                                                                                            <h5 class="text-truncate font-size-14 mb-1">Stephen Hadley</h5>
                                                                                                            <p class="text-truncate mb-0">I've finished it! See you so</p>
                                                                                                        </div></div>
                                                                                                </a>
                                                                                            </li>
                                                                                            <li>
                                                                                                <a href="#">
                                                                                                    <div class="media">
                                                                                                        <div class="align-self-center mr-3">
                                                                                                            <i class="mdi mdi-circle text-success font-size-10"></i>
                                                                                                        </div>
                                                                                                        <div class="avatar-xs align-self-center mr-3">
                                                                                                            <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                                K
                                                                                                            </span>
                                                                                                        </div>
                                                                                                        <div class="media-body overflow-hidden">
                                                                                                            <h5 class="text-truncate font-size-14 mb-1">Keith Gonzales</h5>
                                                                                                            <p class="text-truncate mb-0">This theme is awesome!</p>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </a>
                                                                                            </li>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="simplebar-placeholder" style="width: auto; height: 476px;"></div>
                                                                        </div>
                                                                        <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                                                            <div class="simplebar-scrollbar" style="transform: translate3d(0px, 0px, 0px); display: none;"></div>
                                                                        </div>
                                                                        <div class="simplebar-track simplebar-vertical" style="visibility: visible;">
                                                                            <div class="simplebar-scrollbar" style="height: 353px; transform: translate3d(0px, 0px, 0px); display: block;"></div>
                                                                        </div>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane" id="group">
                                                                <h5 class="font-size-14 mb-3">Group</h5>
                                                                <ul class="list-unstyled chat-list" data-simplebar="init" style="max-height: 410px;">
                                                                    <div class="simplebar-wrapper" style="margin: 0px;">
                                                                        <div class="simplebar-height-auto-observer-wrapper">
                                                                            <div class="simplebar-height-auto-observer"></div>
                                                                        </div>
                                                                        <div class="simplebar-mask">
                                                                            <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                                                                <div class="simplebar-content-wrapper" style="height: auto; overflow: hidden;">
                                                                                    <div class="simplebar-content" style="padding: 0px;">
                                                                                        <li>
                                                                                            <a href="#">
                                                                                                <div class="media align-items-center">
                                                                                                    <div class="avatar-xs mr-3">
                                                                                                        <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                            G
                                                                                                        </span>
                                                                                                    </div>

                                                                                                    <div class="media-body">
                                                                                                        <h5 class="font-size-14 mb-0">General</h5>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </li>

                                                                                        <li>
                                                                                            <a href="#">
                                                                                                <div class="media align-items-center">
                                                                                                    <div class="avatar-xs mr-3">
                                                                                                        <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                            R
                                                                                                        </span>
                                                                                                    </div>

                                                                                                    <div class="media-body">
                                                                                                        <h5 class="font-size-14 mb-0">Reporting</h5>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </li>

                                                                                        <li>
                                                                                            <a href="#">
                                                                                                <div class="media align-items-center">
                                                                                                    <div class="avatar-xs mr-3">
                                                                                                        <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                            M
                                                                                                        </span>
                                                                                                    </div>

                                                                                                    <div class="media-body">
                                                                                                        <h5 class="font-size-14 mb-0">Meeting</h5>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </li>

                                                                                        <li>
                                                                                            <a href="#">
                                                                                                <div class="media align-items-center">
                                                                                                    <div class="avatar-xs mr-3">
                                                                                                        <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                            A
                                                                                                        </span>
                                                                                                    </div>

                                                                                                    <div class="media-body">
                                                                                                        <h5 class="font-size-14 mb-0">Project A</h5>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </li>

                                                                                        <li>
                                                                                            <a href="#">
                                                                                                <div class="media align-items-center">
                                                                                                    <div class="avatar-xs mr-3">
                                                                                                        <span class="avatar-title rounded-circle bg-soft-primary text-primary">
                                                                                                            B
                                                                                                        </span>
                                                                                                    </div>

                                                                                                    <div class="media-body">
                                                                                                        <h5 class="font-size-14 mb-0">Project B</h5>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </a>
                                                                                        </li>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                                                                    </div>
                                                                    <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                                                        <div class="simplebar-scrollbar" style="transform: translate3d(0px, 0px, 0px); display: none;"></div>
                                                                    </div>
                                                                    <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                                                        <div class="simplebar-scrollbar" style="transform: translate3d(0px, 0px, 0px); display: none;"></div>
                                                                    </div>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>