<?php include 'header4.html' ?>
<link href="assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">

<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">

         <!-- start page title -->
         <div class="row profile-text">
            <div class="col-12">
               <div class="page-title-box d-flex align-items-center justify-content-between">
                  <div class="col-lg-12 d-flex align-items-center justify-content-center">
                     <div class="dropdown d-lg-inline-block ml-1">
                        <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           <img class="rounded-circle header-profile-user" src="assets/images/users/avatar-1.jpg" alt="Header Avatar">
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           About
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           Activity
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           Association
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           Recomandetion
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           Appoinments
                        </button>
                        <button type="button" class="btn header-item noti-icon waves-effect text-dark" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           Show more
                        </button>


                     </div>
                  </div>


               </div>
            </div>
         </div>
         <!-- end page title -->

         <div class="row">


            <div class="col-lg-12">
               <div class="card">
                  <div class="card-body">
                     <h4 class="card-title mb-4 text-center">Talk to HR Professional</h4>
                     <div id="progrss-wizard" class="twitter-bs-wizard">
                        <ul class="twitter-bs-wizard-nav nav-justified nav nav-pills">
                           <li class="nav-item">
                              <a href="#progress-seller-details" class="nav-link active" data-toggle="tab">
                                 <span class="step-number mr-2">01</span>
                                <span class="profile-text"> Select Date & time </span>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="#progress-company-document" class="nav-link" data-toggle="tab">
                                 <span class="step-number mr-2">02</span>
                                 <span class="profile-text"> Select Date & time</span>
                              </a>
                           </li>

                           <li class="nav-item">
                              <a href="#progress-bank-detail" class="nav-link" data-toggle="tab">
                                 <span class="step-number mr-2">03</span>
                                 <span class="profile-text"> Upload Resume</span>
                              </a>
                           </li>
                           <li class="nav-item">
                              <a href="#progress-confirm-detail" class="nav-link" data-toggle="tab">
                                 <span class="step-number mr-2">04</span>
                                 <span class="profile-text"> Confirm Payment</span>
                              </a>
                           </li>
                        </ul>
                        <div id="bar" class="progress mt-4">
                           <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" style="width: 25%;"></div>
                        </div>
                        <div class="tab-content twitter-bs-wizard-tab-content">
                           <div class="tab-pane active" id="progress-seller-details">
                              <div class="row">
                                 <div class="form-group mb-3 col-lg-4">
                                    <select class="form-control select2-search-disable select2-hidden-accessible" data-select2-id="6" tabindex="-1" aria-hidden="true">
                                       <option data-select2-id="8">Select</option>
                                       <optgroup label="Alaskan/Hawaiian Time Zone">
                                          <option value="AK">Alaska</option>
                                          <option value="HI">Hawaii</option>
                                       </optgroup>
                                       <optgroup label="Pacific Time Zone">
                                          <option value="CA">California</option>
                                          <option value="NV">Nevada</option>
                                          <option value="OR">Oregon</option>
                                          <option value="WA">Washington</option>
                                       </optgroup>
                                    </select>

                                 </div>
                                 <div class="form-group mb-3 col-lg-4">
                                    <select class="form-control select2-search-disable select2-hidden-accessible" data-select2-id="6" tabindex="-1" aria-hidden="true">
                                       <option data-select2-id="8">Select</option>
                                       <optgroup label="Alaskan/Hawaiian Time Zone">
                                          <option value="AK">Alaska</option>
                                          <option value="HI">Hawaii</option>
                                       </optgroup>
                                       <optgroup label="Pacific Time Zone">
                                          <option value="CA">California</option>
                                          <option value="NV">Nevada</option>
                                          <option value="OR">Oregon</option>
                                          <option value="WA">Washington</option>
                                       </optgroup>
                                    </select>

                                 </div>
                              </div>
                              <div class="form-group mb-0">
                              <p class="font-size-16 text-center">Please Select 3 Dates For Total 3 Hours</p>
                                 <div data-provide="datepicker-inline" class="bootstrap-datepicker-inline">
                                    <div class="datepicker datepicker-inline">
                                       <div class="datepicker-days" style="display:none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">March 2023</th>
                                                   <th class="next">»</th>
                                                </tr>
                                                <tr>
                                                   <th class="dow">Su</th>
                                                   <th class="dow">Mo</th>
                                                   <th class="dow">Tu</th>
                                                   <th class="dow">We</th>
                                                   <th class="dow">Th</th>
                                                   <th class="dow">Fr</th>
                                                   <th class="dow">Sa</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td class="old day" data-date="1677369600000">26</td>
                                                   <td class="old day" data-date="1677456000000">27</td>
                                                   <td class="old day" data-date="1677542400000">28</td>
                                                   <td class="day" data-date="1677628800000">1</td>
                                                   <td class="day" data-date="1677715200000">2</td>
                                                   <td class="day" data-date="1677801600000">3</td>
                                                   <td class="day" data-date="1677888000000">4</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1677974400000">5</td>
                                                   <td class="day" data-date="1678060800000">6</td>
                                                   <td class="day" data-date="1678147200000">7</td>
                                                   <td class="day" data-date="1678233600000">8</td>
                                                   <td class="day" data-date="1678320000000">9</td>
                                                   <td class="day" data-date="1678406400000">10</td>
                                                   <td class="day" data-date="1678492800000">11</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1678579200000">12</td>
                                                   <td class="day" data-date="1678665600000">13</td>
                                                   <td class="day" data-date="1678752000000">14</td>
                                                   <td class="day" data-date="1678838400000">15</td>
                                                   <td class="day" data-date="1678924800000">16</td>
                                                   <td class="day" data-date="1679011200000">17</td>
                                                   <td class="day" data-date="1679097600000">18</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1679184000000">19</td>
                                                   <td class="day" data-date="1679270400000">20</td>
                                                   <td class="day" data-date="1679356800000">21</td>
                                                   <td class="day" data-date="1679443200000">22</td>
                                                   <td class="day" data-date="1679529600000">23</td>
                                                   <td class="day" data-date="1679616000000">24</td>
                                                   <td class="day" data-date="1679702400000">25</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1679788800000">26</td>
                                                   <td class="day" data-date="1679875200000">27</td>
                                                   <td class="day" data-date="1679961600000">28</td>
                                                   <td class="day" data-date="1680048000000">29</td>
                                                   <td class="day" data-date="1680134400000">30</td>
                                                   <td class="day" data-date="1680220800000">31</td>
                                                   <td class="new day" data-date="1680307200000">1</td>
                                                </tr>
                                                <tr>
                                                   <td class="new day" data-date="1680393600000">2</td>
                                                   <td class="new day" data-date="1680480000000">3</td>
                                                   <td class="new day" data-date="1680566400000">4</td>
                                                   <td class="new day" data-date="1680652800000">5</td>
                                                   <td class="new day" data-date="1680739200000">6</td>
                                                   <td class="new day" data-date="1680825600000">7</td>
                                                   <td class="new day" data-date="1680912000000">8</td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-months" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2023</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month focused">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-years" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2020-2029</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="year old">2019</span><span class="year">2020</span><span class="year">2021</span><span class="year">2022</span><span class="year focused">2023</span><span class="year">2024</span><span class="year">2025</span><span class="year">2026</span><span class="year">2027</span><span class="year">2028</span><span class="year">2029</span><span class="year new">2030</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-decades" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2000-2090</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="decade old">1990</span><span class="decade">2000</span><span class="decade">2010</span><span class="decade focused">2020</span><span class="decade">2030</span><span class="decade">2040</span><span class="decade">2050</span><span class="decade">2060</span><span class="decade">2070</span><span class="decade">2080</span><span class="decade">2090</span><span class="decade new">2100</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-centuries" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2000-2900</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="century old">1900</span><span class="century focused">2000</span><span class="century">2100</span><span class="century">2200</span><span class="century">2300</span><span class="century">2400</span><span class="century">2500</span><span class="century">2600</span><span class="century">2700</span><span class="century">2800</span><span class="century">2900</span><span class="century new">3000</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-lg-6 mt-5">
                                    <h5 class="font-size-16">Avalibele time for Nomeber 14</h5>
                                    <h5 class="font-size-14">Session length 62 minutes</h5>
                                    <ul class="ks-cboxtags">
                                       <li><input type="checkbox" id="checkboxOne" value="Rainbow Dash" checked><label for="checkboxOne">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxTwo" value="Cotton Candy"><label for="checkboxTwo">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxThree" value="Rarity"><label for="checkboxThree">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFour" value="Moondancer"><label for="checkboxFour">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFive" value="Surprise"><label for="checkboxFive">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxSix" value="Twilight Sparkle"><label for="checkboxSix">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxSeven" value="Fluttershy"><label for="checkboxSeven">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxEight" value="Derpy Hooves"><label for="checkboxEight">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxNine" value="Princess Celestia"><label for="checkboxNine">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxTen" value="Gusty"><label for="checkboxTen">9:00 am</label></li>
                                       <li class="ks-selected"><input type="checkbox" id="checkboxEleven" value="Discord"><label for="checkboxEleven">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxTwelve" value="Clover"><label for="checkboxTwelve">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxThirteen" value="Baby Moondancer"><label for="checkboxThirteen">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxFourteen" value="Medley"><label for="checkboxFourteen">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFifteen" value="Firefly"><label for="checkboxFifteen">9:00 am</label></li>
                                    </ul>
                                    <div class="row ml-4">
                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor1">
                                          <label class="custom-control-label" for="customCheckcolor1">call</label>
                                       </div>

                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor2">
                                          <label class="custom-control-label" for="customCheckcolor2">video</label>
                                       </div>

                                    </div>
                                    <h5 class="font-size-16 mt-5">Avalibele time for Nomeber 14</h5>
                                    <h5 class="font-size-14">Session length 62 minutes</h5>


                                 </div>
                                 <div class="col-lg-6 mt-5">
                                    <h5 class="font-size-16">Avalibele time for Nomeber 14</h5>
                                    <h5 class="font-size-14">Session length 62 minutes</h5>

                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane" id="progress-company-document">
                              <div class="form-group mb-3 col-lg-4">
                                 <select class="form-control select2-search-disable select2-hidden-accessible" data-select2-id="6" tabindex="-1" aria-hidden="true">
                                    <option data-select2-id="8">Select</option>
                                    <optgroup label="Alaskan/Hawaiian Time Zone">
                                       <option value="AK">Alaska</option>
                                       <option value="HI">Hawaii</option>
                                    </optgroup>
                                    <optgroup label="Pacific Time Zone">
                                       <option value="CA">California</option>
                                       <option value="NV">Nevada</option>
                                       <option value="OR">Oregon</option>
                                       <option value="WA">Washington</option>
                                    </optgroup>
                                 </select>

                              </div>
                              <div class="form-group mb-0">
                              <p class="font-size-16 text-center">Please Select 3 Dates For Total 3 Hours</p>
                                 <div data-provide="datepicker-inline" class="bootstrap-datepicker-inline">
                                    <div class="datepicker datepicker-inline">
                                       <div class="datepicker-days" style="display:none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">March 2023</th>
                                                   <th class="next">»</th>
                                                </tr>
                                                <tr>
                                                   <th class="dow">Su</th>
                                                   <th class="dow">Mo</th>
                                                   <th class="dow">Tu</th>
                                                   <th class="dow">We</th>
                                                   <th class="dow">Th</th>
                                                   <th class="dow">Fr</th>
                                                   <th class="dow">Sa</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td class="old day" data-date="1677369600000">26</td>
                                                   <td class="old day" data-date="1677456000000">27</td>
                                                   <td class="old day" data-date="1677542400000">28</td>
                                                   <td class="day" data-date="1677628800000">1</td>
                                                   <td class="day" data-date="1677715200000">2</td>
                                                   <td class="day" data-date="1677801600000">3</td>
                                                   <td class="day" data-date="1677888000000">4</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1677974400000">5</td>
                                                   <td class="day" data-date="1678060800000">6</td>
                                                   <td class="day" data-date="1678147200000">7</td>
                                                   <td class="day" data-date="1678233600000">8</td>
                                                   <td class="day" data-date="1678320000000">9</td>
                                                   <td class="day" data-date="1678406400000">10</td>
                                                   <td class="day" data-date="1678492800000">11</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1678579200000">12</td>
                                                   <td class="day" data-date="1678665600000">13</td>
                                                   <td class="day" data-date="1678752000000">14</td>
                                                   <td class="day" data-date="1678838400000">15</td>
                                                   <td class="day" data-date="1678924800000">16</td>
                                                   <td class="day" data-date="1679011200000">17</td>
                                                   <td class="day" data-date="1679097600000">18</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1679184000000">19</td>
                                                   <td class="day" data-date="1679270400000">20</td>
                                                   <td class="day" data-date="1679356800000">21</td>
                                                   <td class="day" data-date="1679443200000">22</td>
                                                   <td class="day" data-date="1679529600000">23</td>
                                                   <td class="day" data-date="1679616000000">24</td>
                                                   <td class="day" data-date="1679702400000">25</td>
                                                </tr>
                                                <tr>
                                                   <td class="day" data-date="1679788800000">26</td>
                                                   <td class="day" data-date="1679875200000">27</td>
                                                   <td class="day" data-date="1679961600000">28</td>
                                                   <td class="day" data-date="1680048000000">29</td>
                                                   <td class="day" data-date="1680134400000">30</td>
                                                   <td class="day" data-date="1680220800000">31</td>
                                                   <td class="new day" data-date="1680307200000">1</td>
                                                </tr>
                                                <tr>
                                                   <td class="new day" data-date="1680393600000">2</td>
                                                   <td class="new day" data-date="1680480000000">3</td>
                                                   <td class="new day" data-date="1680566400000">4</td>
                                                   <td class="new day" data-date="1680652800000">5</td>
                                                   <td class="new day" data-date="1680739200000">6</td>
                                                   <td class="new day" data-date="1680825600000">7</td>
                                                   <td class="new day" data-date="1680912000000">8</td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-months" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2023</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month focused">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-years" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2020-2029</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="year old">2019</span><span class="year">2020</span><span class="year">2021</span><span class="year">2022</span><span class="year focused">2023</span><span class="year">2024</span><span class="year">2025</span><span class="year">2026</span><span class="year">2027</span><span class="year">2028</span><span class="year">2029</span><span class="year new">2030</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-decades" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2000-2090</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="decade old">1990</span><span class="decade">2000</span><span class="decade">2010</span><span class="decade focused">2020</span><span class="decade">2030</span><span class="decade">2040</span><span class="decade">2050</span><span class="decade">2060</span><span class="decade">2070</span><span class="decade">2080</span><span class="decade">2090</span><span class="decade new">2100</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                       <div class="datepicker-centuries" style="display: none;">
                                          <table class="table-condensed">
                                             <thead>
                                                <tr>
                                                   <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                </tr>
                                                <tr>
                                                   <th class="prev">«</th>
                                                   <th colspan="5" class="datepicker-switch">2000-2900</th>
                                                   <th class="next">»</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="7"><span class="century old">1900</span><span class="century focused">2000</span><span class="century">2100</span><span class="century">2200</span><span class="century">2300</span><span class="century">2400</span><span class="century">2500</span><span class="century">2600</span><span class="century">2700</span><span class="century">2800</span><span class="century">2900</span><span class="century new">3000</span></td>
                                                </tr>
                                             </tbody>
                                             <tfoot>
                                                <tr>
                                                   <th colspan="7" class="today" style="display: none;">Today</th>
                                                </tr>
                                                <tr>
                                                   <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                </tr>
                                             </tfoot>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-lg-6 mt-5">
                                    <h5 class="font-size-16">Avalibele time for Nomeber 14</h5>
                                    <h5 class="font-size-14">Session length 62 minutes</h5>
                                    <ul class="ks-cboxtags">
                                       <li><input type="checkbox" id="checkbox16" value="Rainbow Dash" checked><label for="checkbox16">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkbox17" value="Cotton Candy"><label for="checkbox17">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkbox18" value="Rarity"><label for="checkbox18">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkbox19" value="Moondancer"><label for="checkbox19">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkbox20" value="Surprise"><label for="checkbox20">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkbox21" value="Twilight Sparkle"><label for="checkbox21">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkbox22" value="Fluttershy"><label for="checkbox22">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkbo23" value="Derpy Hooves"><label for="checkboxEight">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkbox24" value="Princess Celestia"><label for="checkboxNine">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkbox" value="Gusty"><label for="checkboxTen">9:00 am</label></li>
                                       <li class="ks-selected"><input type="checkbox" id="checkboxEleven" value="Discord"><label for="checkboxEleven">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxTwelve" value="Clover"><label for="checkboxTwelve">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxThirteen" value="Baby Moondancer"><label for="checkboxThirteen">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxFourteen" value="Medley"><label for="checkboxFourteen">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFifteen" value="Firefly"><label for="checkboxFifteen">9:00 am</label></li>
                                    </ul>
                                    <div class="row ml-4">
                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor3">
                                          <label class="custom-control-label" for="customCheckcolor3">call</label>
                                       </div>

                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor4">
                                          <label class="custom-control-label" for="customCheckcolor4">video</label>
                                       </div>

                                    </div>
                                    <h5 class="font-size-16 mt-5">Avalibele time for Nomeber 14</h5>
                                    <h5 class="font-size-14">Session length 62 minutes</h5>
                                    <ul class="ks-cboxtags">
                                       <li><input type="checkbox" id="checkboxOne" value="Rainbow Dash" checked><label for="checkboxOne">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxTwo" value="Cotton Candy"><label for="checkboxTwo">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxThree" value="Rarity"><label for="checkboxThree">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFour" value="Moondancer"><label for="checkboxFour">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFive" value="Surprise"><label for="checkboxFive">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxSix" value="Twilight Sparkle"><label for="checkboxSix">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxSeven" value="Fluttershy"><label for="checkboxSeven">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxEight" value="Derpy Hooves"><label for="checkboxEight">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxNine" value="Princess Celestia"><label for="checkboxNine">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxTen" value="Gusty"><label for="checkboxTen">9:00 am</label></li>
                                       <li class="ks-selected"><input type="checkbox" id="checkboxEleven" value="Discord"><label for="checkboxEleven">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxTwelve" value="Clover"><label for="checkboxTwelve">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxThirteen" value="Baby Moondancer"><label for="checkboxThirteen">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxFourteen" value="Medley"><label for="checkboxFourteen">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFifteen" value="Firefly"><label for="checkboxFifteen">9:00 am</label></li>
                                    </ul>
                                    <div class="row ml-4">
                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor5">
                                          <label class="custom-control-label" for="customCheckcolor5">call</label>
                                       </div>

                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor6">
                                          <label class="custom-control-label" for="customCheckcolor6">video</label>
                                       </div>

                                    </div>
                                 </div>
                                 <div class="col-lg-6 mt-5">
                                    <h5 class="font-size-16">Avalibele time for Nomeber 14</h5>
                                    <h5 class="font-size-14">Session length 62 minutes</h5>
                                    <ul class="ks-cboxtags">
                                       <li><input type="checkbox" id="checkboxOne" value="Rainbow Dash" checked><label for="checkboxOne">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxTwo" value="Cotton Candy"><label for="checkboxTwo">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxThree" value="Rarity"><label for="checkboxThree">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFour" value="Moondancer"><label for="checkboxFour">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFive" value="Surprise"><label for="checkboxFive">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxSix" value="Twilight Sparkle"><label for="checkboxSix">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxSeven" value="Fluttershy"><label for="checkboxSeven">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxEight" value="Derpy Hooves"><label for="checkboxEight">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxNine" value="Princess Celestia"><label for="checkboxNine">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxTen" value="Gusty"><label for="checkboxTen">9:00 am</label></li>
                                       <li class="ks-selected"><input type="checkbox" id="checkboxEleven" value="Discord"><label for="checkboxEleven">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxTwelve" value="Clover"><label for="checkboxTwelve">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxThirteen" value="Baby Moondancer"><label for="checkboxThirteen">9:00 am
                                          </label></li>
                                       <li><input type="checkbox" id="checkboxFourteen" value="Medley"><label for="checkboxFourteen">9:00 am</label></li>
                                       <li><input type="checkbox" id="checkboxFifteen" value="Firefly"><label for="checkboxFifteen">9:00 am</label></li>
                                    </ul>
                                    <div class="row ml-4">
                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor7">
                                          <label class="custom-control-label" for="customCheckcolor7">call</label>
                                       </div>

                                       <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                          <input type="checkbox" class="custom-control-input" id="customCheckcolor8">
                                          <label class="custom-control-label" for="customCheckcolor8">video</label>
                                       </div>

                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane" id="progress-bank-detail">
                              <div>
                              <p class="font-size-16 text-center ">Write For Brief Message</p>
                                 <form action="#" class="dropzone dz-clickable text-center upload-image p-5">

                                    <div class="dz-message needsclick">
                                       <div class="mb-3">
                                          <i class="display-4 text-muted bx bxs-cloud-upload"></i>
                                       </div>

                                       <h4>Drop files here or click to upload.</h4>
                                    </div>
                                 </form>
                              </div>

                           </div>
                           <div class="tab-pane" id="progress-confirm-detail">
                              <div class="row">
                                 <div class="col-lg-6 p-3">
                                    <div class="mb-5">
                                       <h5 class="font-size-12"><a href="javascript: void(0);" class="text-dark">1st Session Time Out Of November 14</a></h5>
                                       <p class="text-muted">Session Length 60 minutes</p>



                                       <div class="team row float-left">
                                          <div class="col-lg-7">
                                             <button type="button" class="btn btn-primary waves-effect waves-light">9:00 am</button>
                                          </div>
                                          <div class="col-lg-5">
                                             <div class="custom-control custom-checkbox custom-checkbox-primary mt-2">
                                                <input type="checkbox" class="custom-control-input" id="customCheckcolor9" checked="">
                                                <label class="custom-control-label" for="customCheckcolor9">Video</label>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="text-right">
                                          <p class="mt-4 text-muted">Modify</p>
                                       </div>
                                    </div>
                                    <div class="mb-5">
                                       <h5 class="font-size-12"><a href="javascript: void(0);" class="text-dark">1st Session Time Out Of November 14</a></h5>
                                       <p class="text-muted">Session Length 60 minutes</p>



                                       <div class="team row float-left">
                                          <div class="col-lg-7">
                                             <button type="button" class="btn btn-primary waves-effect waves-light">9:00 am</button>
                                          </div>
                                          <div class="col-lg-5">
                                             <div class="custom-control custom-checkbox custom-checkbox-primary mt-2">
                                                <input type="checkbox" class="custom-control-input" id="customCheckcolor10" checked="">
                                                <label class="custom-control-label" for="customCheckcolor10">Video</label>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="text-right">
                                          <p class="mt-4 text-muted">Modify</p>
                                       </div>
                                    </div>
                                    <div class="mb-5">
                                       <h5 class="font-size-12"><a href="javascript: void(0);" class="text-dark">1st Session Time Out Of November 14</a></h5>
                                       <p class="text-muted">Session Length 60 minutes</p>



                                       <div class="team row float-left">
                                          <div class="col-lg-7">
                                             <button type="button" class="btn btn-primary waves-effect waves-light">9:00 am</button>
                                          </div>
                                          <div class="col-lg-5">
                                             <div class="custom-control custom-checkbox custom-checkbox-primary mt-2">
                                                <input type="checkbox" class="custom-control-input" id="customCheckcolor11" checked="">
                                                <label class="custom-control-label" for="customCheckcolor11">Video</label>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="text-right">
                                          <p class="mt-4 text-muted">Modify</p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-lg-6 p-3">
                                    <b>
                                       <p class="font-size-16"><a href="javascript: void(0);" class="text-dark">Receipet Summary</a></p>
                                    </b>
                                    <div class="team float-left">
                                       <p class="text-dark">3 Hours seesion <br>
                                          Discount <br>
                                          SubTotal</p>
                                    </div>

                                    <div class="text-right">
                                       <p class="text-dark"> 150 USD <br>
                                          0 USD <br>
                                          150 USD</p>
                                       <div class="team float-left text-left">
                                          <p class="text-dark"> <span class="font-size-14"> Total <br> Converstion</span></p>
                                       </div>

                                       <div class="text-right">
                                          <p class="text-dark"> <span class="font-size-14">150 USD <br> 1500 INR</span> <br>
                                          </p>
                                       </div>
                                    </div>
                                    <b>
                                       <p class="font-size-16 mt-5"><a href="javascript: void(0);" class="text-dark">Receipet Summary</a></p>
                                    </b>

                                    <div class="row">
                                       <div class="col-lg-2">
                                          <label class="card-radio-label mb-3">
                                             <input type="radio" name="pay-method" id="pay-methodoption1" class="card-radio-input">

                                             <div class="card-radio">
                                                <i class="fab fa-cc-visa font-size-24 text-primary align-middle mr-2"></i>
                                             </div>
                                          </label>
                                       </div>

                                       <div class="col-lg-2">
                                          <label class="card-radio-label mb-3">
                                             <input type="radio" name="pay-method" id="pay-methodoption1" class="card-radio-input">

                                             <div class="card-radio">
                                                <i class="fab fa-cc-mastercard font-size-24 text-primary align-middle mr-2"></i>
                                             </div>
                                          </label>
                                       </div>

                                       <div class="col-lg-2">
                                          <label class="card-radio-label mb-3">
                                             <input type="radio" name="pay-method" id="pay-methodoption1" class="card-radio-input">

                                             <div class="card-radio">
                                                <i class="fab fa-cc-amex font-size-24 text-primary align-middle mr-2"></i>
                                             </div>
                                          </label>
                                       </div>

                                       <div class="col-lg-2">
                                          <label class="card-radio-label mb-3">
                                             <input type="radio" name="pay-method" id="pay-methodoption1" class="card-radio-input">

                                             <div class="card-radio">
                                                <i class="fab fa-cc-discover font-size-24 text-primary align-middle mr-2"></i>
                                             </div>
                                          </label>
                                       </div>

                                       <div class="col-lg-2">
                                          <label class="card-radio-label mb-3">
                                             <input type="radio" name="pay-method" id="pay-methodoption3" class="card-radio-input" checked="">

                                             <div class="card-radio">
                                                <i class="fab fa-cc-paypal font-size-24 text-primary align-middle mr-2"></i>
                                             </div>
                                          </label>
                                       </div>
                                       <div class="col-lg-2">
                                          <label class="card-radio-label mb-3">
                                             <input type="radio" name="pay-method" id="pay-methodoption3" class="card-radio-input" checked="">

                                             <div class="card-radio">
                                                <i class="fas fa-university font-size-24 text-primary align-middle mr-2"></i>
                                             </div>
                                          </label>
                                       </div>
                                       <div class="form-group col-lg-12">
                                          <label>Name On Crediet card </label>
                                          <input type="text" class="form-control">
                                       </div>
                                       <div class="form-group col-lg-12">
                                          <label>Crediet card Number</label>
                                          <input type="text" class="form-control">
                                       </div>
                                       <div class="row col-lg-12">
                                          <div class="form-group col-lg-6">
                                             <label>Expires on</label>
                                             <input type="text" class="form-control" placeholder="Month">
                                          </div>
                                          <div class="form-group col-lg-6">
                                             <label>Expires on</label>
                                             <input type="text" class="form-control" placeholder="Year">
                                          </div>
                                       </div>
                                       <div class="row col-lg-12">
                                          <div class="form-group col-lg-6">
                                             <label>CVC</label>
                                             <input type="text" class="form-control" placeholder="CVC">
                                          </div>
                                          <div class="-lg-6">
                                             <p class="mt-4 text-aling-center"><a href="javascript:void(0)">What ic cvv ??</a></p>
                                          </div>

                                       </div>
                                       <div class="col-lg-12">
                                          <button type="button" class="btn btn-primary waves-effect waves-light w-100">BOOK SECURELY</button> </div>
                                       <p class="text-muted m-auto"><i class="bx bx-lock"></i>Your Credit card Information is encrypted</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <ul class="pager wizard twitter-bs-wizard-pager-link">
                           <li class="previous "><a href="javascript: void(0);">Previous</a></li>
                           <li class="next"><a href="javascript: void(0);">Next</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- end row -->

      </div>
   </div>
</div>

<script src="assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="assets/libs/dropzone/min/dropzone.min.js"></script>
<script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
<script src="assets/libs/twitter-bootstrap-wizard/prettify.js"></script>
<script src="assets/js/pages/form-wizard.init.js"></script>