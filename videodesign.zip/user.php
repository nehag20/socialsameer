<?php include 'header.html' ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="cover-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/group/group-cover.jpg" alt="">
                    </div>
                    <div class="profile-image">
                        <img src="http://mahorgwarevaish.in/social/assets/images/avatars/avatar-1.jpg" alt="">
                    </div>
                    <i class="fa fa-camera upload-image" aria-hidden="true"></i>
                    <h1 class="about-username">John Smith</h1>
                    <p><b>Assitant Manager</b> @ deolite, Toranto,British Colombia,Canada.</p>
                </div>
                <!-- end page title -->
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <!-- Nav tabs -->
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#all" role="tab" aria-selected="true">
                                        <span class="d-block d-sm-none"><i class="fas fa-users-cog"></i></span>
                                        <span class="d-none d-sm-block">About</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#unread" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-clock"></i></span>
                                        <span class="d-none d-sm-block">Activity</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#archieve" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-users"></i></span>
                                        <span class="d-none d-sm-block">Associations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#recommendations" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                        <span class="d-none d-sm-block">Recommendations</span>
                                    </a>
                                </li>
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-toggle="tab" href="#appointment" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="far fa-calendar-alt"></i></span>
                                        <span class="d-none d-sm-block">Appointment</span>
                                    </a>
                                </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content text-muted">
                                <div class="tab-pane active" id="all" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-9">
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                        <div class="embed-responsive embed-responsive-21by9 mb-4">
                                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Jv8KRwF1zQs" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center m-0"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="post-wrapper mt-3 mb-3">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="w-20">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                        </div>
                                                        <div class="w-25" style="float: left;">
                                                            <span class="username">John Smith</span>
                                                            <p>5 Hrs Ago <i class="fas fa-user-friends"></i></p>
                                                        </div>
                                                        <div class="w-10">
                                                            <div class="dropdown">
                                                                <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                                                                </a>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="#">Share</a>
                                                                    <a class="dropdown-item" href="#">Edit Post</a>
                                                                    <a class="dropdown-item" href="#">Disable Comments</a>
                                                                    <a class="dropdown-item" href="#">Add Favourite</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <!-- Enter Post Content Here -->
                                                        <p class="post-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio, natus architecto repudiandae repellat quod est harum deleniti et quisquam temporibus! Expedita ipsum illo earum molestias rerum provident quod ullam officiis!Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="like-image">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <img src="assets/images/avatar/45x45.jpg" alt="" class="rounded-circle img-group">
                                                            <span><b>Richard</b> and 2 friends are liked</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-center"><i class="fas fa-comments"></i> 24</p>
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <p class="text-right"><i class="fas fa-share-alt"></i> 215</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <h5 class="font-size-15 mb-3 mt-3">Invites</h5>
                                            <div class="text-center">
                                                <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                            </div>
                                            <div class="text-center pt-3 pb-3">
                                                <button class="btn btn-primary" style="background-color: #532574;border: none;outline: none;">Sent Friend Request</button>
                                            </div>
                                            <h5 class="font-size-15 mb-3 mt-3">Ads Area</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane active" id="recommendations" role="tabpanel">
                                    <div class="row justify-content-center align-items-center">
                                        <div class="col-lg-3 col-sm-12 mt-3 mb-3">
                                            <div class="text-center">
                                                <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-sm-12">
                                            <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas cupiditate earum id maxime, labore quasi autem. Beatae aut nemo totam excepturi id veritatis, laudantium minima sequi labore, officia quis rerum?</p>
                                        </div>
                                        <div class="col-lg-3 col-sm-12 mt-3 mb-3">
                                            <div class="text-center">
                                                <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-sm-12">
                                            <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas cupiditate earum id maxime, labore quasi autem. Beatae aut nemo totam excepturi id veritatis, laudantium minima sequi labore, officia quis rerum?</p>
                                        </div>
                                        <div class="col-lg-3 col-sm-12 mt-3 mb-3">
                                            <div class="text-center">
                                                <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-sm-12">
                                            <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas cupiditate earum id maxime, labore quasi autem. Beatae aut nemo totam excepturi id veritatis, laudantium minima sequi labore, officia quis rerum?</p>
                                        </div>
                                        <div class="col-lg-3 col-sm-12 mt-3 mb-3">
                                            <div class="text-center">
                                                <img src="assets/images/avatar/profile-sm.jpg" alt="" class="rounded-circle">
                                            </div>
                                        </div>
                                        <div class="col-lg-9 col-sm-12">
                                            <p class="text-justify">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas cupiditate earum id maxime, labore quasi autem. Beatae aut nemo totam excepturi id veritatis, laudantium minima sequi labore, officia quis rerum?</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>