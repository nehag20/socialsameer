<?php include 'header3.html' ?>
<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <div class="row">
         <div class="col-lg-12">
         <div class="card">
         <div class="card-body">
         <div class="row">
               <div class="col-lg-9">
                  <div class="card-title-desc">
                     Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum fuga consequuntur quasi laborum dolor porro et optio doloribus nobis, quos iusto consequatur ratione ducimus nihil dolorem sit earum, rem aliquam!
                  </div>
                  </div>
                  <div class="col-lg-3">
                     <p class="chatid">Subject:Job Id -SEF20205456 </p>
                  </div>
                  </div>
        </div>
         <div class="col-lg-12">
         <div class="row">
               
               
                <div class="col-lg-7">
                  <ul class="nav nav-pills nav-justified" role="tablist">
                     <li class="nav-item waves-effect waves-light">
                        <a class="nav-link active" data-toggle="tab" href="#all" role="tab" aria-selected="true">
                        <span class="d-block d-sm-none"><i class="fas fa-sort"></i></span>
                        <span class="d-none d-sm-block">Sort</span>
                        </a>
                     </li>
                     <li class="nav-item waves-effect waves-light">
                        <a class="nav-link" data-toggle="tab" href="#about" role="tab" aria-selected="false">
                        <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                        <span class="d-none d-sm-block">Application</span>
                        </a>
                     </li>
                     <li class="nav-item waves-effect waves-light">
                        <select class="form-control">
                           <option>Status</option>
                           <option>Under Review</option>
                           <option>Complated</option>
                           <option>Pending</option>
                           <option>Unschopde</option>
                        </select>
                     </li>
                     <li class="nav-item waves-effect waves-light">
                        <a class="nav-link" data-toggle="tab" href="#job" role="tab" aria-selected="true">
                        <span class="d-block d-sm-none"><i class="fas fa-calendar"></i></span>
                        <span class="d-none d-sm-block">Date</span>
                        </a>
                     </li>
                     <li class="nav-item waves-effect waves-light">
                        <a class="nav-link " data-toggle="tab" href="#drafts" role="tab" aria-selected="false">
                        <span class="d-block d-sm-none"><i class="far fa-compass"></i></span>
                        <span class="d-none d-sm-block">Location</span>
                        </a>
                     </li>
                  </ul>
               </div>
               <div class="col-lg-5">
                  <div class="row">
                     <div class="col-lg-12 d-flex justify-content-end">
                        <div class="row">
                           <div class="col-lg-8 mb-3">
                              <form>
                                 <div class="position-relative">
                                    <input type="text" class="custom-input form-control"
                                       placeholder="Search...">
                                    <span class="bx bx-search-alt custom-search"></span>
                                    <span class="bx bxs-microphone custom-voice"></span>
                                 </div>
                              </form>
                           </div>
                           <div class="col-lg-4 mb-3 d-flex align-items-center">
                              <div class="filter">
                                 <a href="#" type="button" id="filter">
                                 <i class="fas fa-bars"></i>
                                 <span class="text-dark">Filters</span>
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-12" id="filter-items">
                        <div class="row">
                           <div class="col-lg-3">
                              <select class="form-control">
                                 <option>Sort</option>
                                 <option>Large select</option>
                                 <option>Small select</option>
                              </select>
                           </div>
                           <div class="col-lg-3">
                              <select class="form-control">
                                 <option>Title</option>
                                 <option>Large select</option>
                                 <option>Small select</option>
                              </select>
                           </div>
                           <div class="col-lg-3">
                              <select class="form-control">
                                 <option>Location</option>
                                 <option>Large select</option>
                                 <option>Small select</option>
                              </select>
                           </div>
                           <div class="col-lg-3">
                              <select class="form-control">
                                 <option>Employment Type</option>
                                 <option>Large select</option>
                                 <option>Small select</option>
                              </select>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               </div>
         </div>
         </div>
            </div>
            <div class="col-lg-9">
            <div class="card">
            <div class="card-body">
            <div class="tab-content p-3 text-muted">
               <div class="tab-pane active" id="all" role="tabpanel">
                  <div class="row mt-3">
                     <div class="col-lg-12 hr">
                        <div class="row">
                           <div class="col-lg-8">
                              <div class="w-25">
                                 <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid p-2">
                              </div>
                              <div>
                                 <span class="username"><a href="#"> Small Business Advisor</a></span>
                                 <p>Full Time - Permanent <br>
                                 ICBC  <br> Surry, BC, Canada</p>
                                 
                                 <small>Application ID : 03022020 | <a href="javascript:void(0)">Status - Unopene</a> </small>
                              </div>
                           </div>
                           <div class="col-lg-4 text-center">
                              <p class="mt-4">Application on 12/01/2020</p>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-12 hr">
                        <div class="row">
                           <div class="col-lg-8">
                              <div class="w-25">
                                 <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid p-2">
                              </div>
                              <div>
                                 <span class="username"><a href="#">Small Business Advisor</a></span>
                                 <p>Full Time - Permanent <br>
                                 ICBC  <br> Surry, BC, Canada</p>
                                 <small>Application ID : 03022020 </small>
                              </div>
                           </div>
                           <div class="col-lg-4 text-center">
                              <p class="mt-4">Application on 12/01/2020</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            </div>
            </div>
            </div>
         <div class="col-md-3 text-center">
            <button type="button" class="btn btn-outline-secondary waves-effect mb-3">View all jobs</button>
            <div class="row">
               <div class="col-md-12">
                  <p class="chatid">Statistics</p>
               </div>
               <div class="col-6">
                  <p class="chatid">Reached to <br> 100</p>
               </div>
               <div class="col-6">
                  <p class="chatid">Views <br> 50</p>
               </div>
               <div class="col-6">
                  <p class="chatid">Application 20</p>
               </div>
               
               
               <div class="col-6">
                  <p class="chatid">Indox <br> 20</p>
               </div>
               <div class="col-6">
                  <p class="chatid">Note Met Screning Question 3</p>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <p class="chatid">Remark</p>
               </div>
               <div class="col-6">
                  <p class="chatid">Fit <br> <span class="font-size-10">You have short listed anyone yet</span></p>
               </div>
               <div class="col-6">
                  <p class="chatid">Not a fit <br> 20</p>
               </div>
               <div class="col-6">
                  <p class="chatid">Schedule  <br><span class="font-size-10"> you hovent Schedule any  yet</span></p>
               </div> 
               <div class="col-md-12">
                  <p class="chatid">Dwonload Resume</p>
               </div>  
            </div>
         </div>
         </div>
      </div>
   </div>
</div>