<?php include 'header3.html' ?>
<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-9">
               <div class="card">
                  <div class="card-body">
                     <div class="col-lg-12">
                        <div class="w-25" style="padding:10px;">
                           <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                        </div>
                        <div class="w-10" style="text-align: right;">
                           <div class="dropdown">
                              <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <i class="bx bx-dots-vertical-rounded" style="padding-top: 10px;font-size: 25px;color:#74788d;"></i>
                              </a>
                              <div class="dropdown-menu">
                                 <a class="dropdown-item" href="#">Share</a>
                                 <a class="dropdown-item" href="#">Edit Post</a>
                                 <a class="dropdown-item" href="#">Disable Comments</a>
                                 <a class="dropdown-item" href="#">Add Favourite</a>
                              </div>
                           </div>
                        </div>
                        <div class="w-80" style="float: none; text-align: left;  padding-top:10px;">
                           <span class="username">Small Business Advisor</span>
                           <p>Full Time - Permanent <br> social Bank</p>
                           <ul class="jobs">
                              <li><button type="button" class="btn btn-primary waves-effect">Apply</button>
                                 <button type="button" class="btn btn-primary waves-effect">Save</button>
                              </li>
                              <li class="my-1">Posted 2 days ago
                              <li class="my-1">125 Views</li>
                              <li class="my-1">80 Applicants</li>
                           </ul>
                        </div>
                        
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-12">
                     <div class="row">
                        <div class="col-lg-12">
                           <div class="card">
                              <div class="card-body">
                                 <!-- Nav tabs -->
                                 <ul class="nav nav-pills nav-justified" role="tablist">
                                    <li class="nav-item waves-effect waves-light">
                                       <a class="nav-link active" data-toggle="tab" href="#home-1" role="tab">
                                       <span class="d-block d-sm-none"><i class="fas fa-atlas"></i></span>
                                       <span class="d-none d-sm-block">Job Description</span> 
                                       </a>
                                    </li>
                                    <li class="nav-item waves-effect waves-light">
                                       <a class="nav-link" data-toggle="tab" href="#profile-1" role="tab">
                                       <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                                       <span class="d-none d-sm-block">Setting</span> 
                                       </a>
                                    </li>
                                 </ul>
                                 <!-- Tab panes -->
                                 <div class="tab-content p-3 text-muted">
                                    <div class="tab-pane active" id="home-1" role="tabpanel">
                                       <p>
                                          Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditate iste incidunt repellendus architecto quisquam, nulla temporibus doloremque laudantium nihil recusandae id maiores commodi.                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditate iste incidunt repellendus architecto quisquam, nulla temporibus doloremque laudantium nihil recusandae id maiores commodi.
                                       </p>
                                       <p>
                                          Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditate iste incidunt repellendus architecto quisquam, nulla temporibus doloremque laudantium nihil recusandae id maiores commodi.
                                       </p>
                                       <p>
                                          Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos facilis tempora reprehenderit beatae, odit accusantium cupiditat.
                                       </p>
                                       <p>
                                          Raw denim you
                                       </p>
                                       <p>
                                          Raw denim you probably haven't heard of them jean shorts Austin.
                                          Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache. Aliquip placeat salvia cillum
                                          iphone. Seitan aliquip quis cardigan american apparel, butcher
                                          voluptate nisi qui.
                                       </p>
                                       <p>
                                          Raw denim you probably haven't heard of them jean shorts Austin.
                                          Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache
                                       </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-lg-3">
                    <div class="user-chat">
                        <div class="card">
                            <div class="p-4 border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="profile-card text-center">
                                            <img src="assets/images/users/avatar-2.jpg" alt="" class="img-fluid rounded-circle">
                                        </div>
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">Steven Franklin</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Full Stack Developer at Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="p-4 border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">250</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Associates</p>
                                    </div>
                                    <div class="col-md-12">
                                        <h5 class="font-size-24 mb-1 mt-3 text-center">50</h5>
                                        <p class="text-muted mb-0 font-size-18 text-center">Mutual Associates</p>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom">
                                <div class="row">
                                    <div class="col-md-12">
                                        <p class="text-dark pb-1 pt-3 text-center font-size-18">Association since Oct 31st 2019</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
         </div>
      </div>
   </div>
</div>