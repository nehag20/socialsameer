<?php include 'header.html' ?>
<div class="main-content">
<div class="page-content">
<div class="container-fluid">
<link href="assets/libs/summernote/summernote-bs4.min.css" rel="stylesheet" type="text/css" />
<!-- Bootstrap Css -->
<link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
<!-- start page title -->
<div class="container-fluid">
   <!-- start page title -->
   <div class="row">
      <div class="col-12">
         <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0 font-size-18">The Ecsisent Way To Get Your New Hire</h4>
         </div>
         <div class="row pb-4">
            <div class="col-md-2">
               <input class="form-control" type="text" placeholder="Frist name">
            </div>
            <div class="col-md-2">
               <input class="form-control" type="text" placeholder="Last name">
            </div>
            <div class="col-md-2">
               <input class="form-control" type="text" placeholder="E-Mail">
            </div>
            <div class="col-md-2">
               <input class="form-control" type="text" placeholder="Phone No">
            </div>
            <div class="cpl-md-2">
               <button type="button" class="btn btn-primary waves-effect waves-light">Next</button>
            </div>
         </div>
      </div>
   </div>
   <!-- end page title -->
   <div class="row">
      <div class="col-lg-12">
         <div class="card">
            <div class="card-body">
               <h4 class="card-title">How Does it Works</h4>
               <p class="card-title-desc">Images in Bootstrap are made responsive
                  the image so that it scales with the parent elementImages in Bootstrap are made responsive
                  the image so that it scales with the parent element.
               </p>
               <div class="">
                  <img src="assets/images/small/img-2.jpg" class="img-fluid" alt="Responsive image">
               </div>
            </div>
         </div>
      </div>
      <div class="col-lg-12">
         <div class="card">
            <div class="card-body">
               <h4 class="card-title">Step 1</h4>
               <p class="card-title-desc">Use classes
                  and 
               </p>
               <div class="row">
                  <div class="col-md-8">
                     <div class="mt-4 mt-md-0">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate voluptates animi aspernatur ex natus reiciendis possimus aliquam dolor, nesciunt doloremque ullam temporibus quibusdam atque pariatur cum beatae culpa commodi rerum.
                     </div>
                  </div>
                  <div class="col-md-4">
                     <img class="rounded mr-2" alt="200x200" width="200" src="assets/images/small/img-4.jpg" data-holder-rendered="true">
                  </div>
               </div>
            </div>
         </div>
         <div class="card">
            <div class="card-body">
               <h4 class="card-title">Step 2</h4>
               <p class="card-title-desc">Use classes
                  and 
               </p>
               <div class="row">
                  <div class="col-md-4">
                     <img class="rounded mr-2" alt="200x200" width="200" src="assets/images/small/img-4.jpg" data-holder-rendered="true">
                  </div>
                  <div class="col-md-8">
                     <div class="mt-4 mt-md-0">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate voluptates animi aspernatur ex natus reiciendis possimus aliquam dolor, nesciunt doloremque ullam temporibus quibusdam atque pariatur cum beatae culpa commodi rerum.
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="card">
            <div class="card-body">
               <h4 class="card-title">Step 3</h4>
               <p class="card-title-desc">Use classes
                  and 
               </p>
               <div class="row">
                  <div class="col-md-8">
                     <div class="mt-4 mt-md-0">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate voluptates animi aspernatur ex natus reiciendis possimus aliquam dolor, nesciunt doloremque ullam temporibus quibusdam atque pariatur cum beatae culpa commodi rerum.
                     </div>
                  </div>
                  <div class="col-md-4">
                     <img class="rounded mr-2" alt="200x200" width="200" src="assets/images/small/img-4.jpg" data-holder-rendered="true">
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="media">
                                        

                                            <div class="media-body overflow-hidden">
                                                <h5 class="text-truncate font-size-15">Got a questions</h5>
                                                <p class="text-muted">Separate existence is a myth. For science, music, sport, etc.Separate existence is a myth. For science, music, sport, etc.Separate existence is a myth. For science, music, sport, etc.</p>
                                            </div>
                                        </div>
                                      
                                            <img src="assets/images/logo.png" alt="" class="avatar mr-4">
                                            
                                            <div class="text-muted mt-4">
                                            <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> To achieve this, it would be necessary</p>
                                            <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> Separate existence is a myth.</p>
                                            <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> If several languages coalesce</p>
                                            <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> To achieve this, it would be necessary</p>
                                            <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> Separate existence is a myth.</p>
                                            <p><i class="mdi mdi-chevron-right text-primary mr-1"></i> If several languages coalesce</p>
                                   
                                        </div>
                                        <h5 class="font-size-15 mt-4">Project Details :</h5>
<div class="row">
                                        <div class="col-md-11">
                                        <p class="text-muted">To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc,</p>
                                    </div>
                                      
    
                                            <div class="col-md-1 text-center">
                                                <div class="mt-2">
                                                    <h1><i class="bx bx-chat mr-1 text-primary"></i> </h1>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
   </div>
   <!-- end row -->
</div>
<!-- container-fluid -->