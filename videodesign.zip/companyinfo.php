<?php include 'header3.html' ?>
<div class="main-content">
<div class="page-content">
<div class="container-fluid">
   <link href="assets/libs/summernote/summernote-bs4.min.css" rel="stylesheet" type="text/css" />
   <!-- Bootstrap Css -->
   <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
   <!-- Icons Css -->
   <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
   <!-- App Css-->
   <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
   <!-- start page title -->
   <div class="row">
      <div class="col-12">
         <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0 font-size-18">Select Box</h4>
         </div>
      </div>
   </div>
   <!-- end page title -->
   <div class="row">
      <div class="col-lg-12">
         <div class="card">
            <div class="card-body">
               <h4 class="card-title">Justify Tabs</h4>
               <div class="col-md-12">
                  <p class="card-title-desc">Use the tab JavaScript plugin—include
                     it individually or through the compiled <code class="highlighter-rouge">bootstrap.js</code>
                     file—to extend our navigational tabs and pills to create tabbable panes
                     of local content, even via dropdown menus.
                  </p>
               </div>
               <div class="col-md-3">
                  <p class="chatid">Subject:Job Id -SEF20205456 </p>
               </div>
               <!-- Nav tabs -->
               <ul class="nav nav-pills nav-justified" role="tablist">
                  <li class="nav-item waves-effect waves-light">
                     <a class="nav-link active" data-toggle="tab" href="#home-1" role="tab">
                     <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                     <span class="d-none d-sm-block">Company Info</span> 
                     </a>
                  </li>
                  <li class="nav-item waves-effect waves-light">
                     <a class="nav-link" data-toggle="tab" href="#profile-1" role="tab">
                     <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                     <span class="d-none d-sm-block">Jobs Details</span> 
                     </a>
                  </li>
                  <li class="nav-item waves-effect waves-light">
                     <a class="nav-link" data-toggle="tab" href="#messages-1" role="tab">
                     <span class="d-block d-sm-none"><i class="far fa-envelope"></i></span>
                     <span class="d-none d-sm-block">Screening Questions</span>   
                     </a>
                  </li>
                  <li class="nav-item waves-effect waves-light">
                     <a class="nav-link" data-toggle="tab" href="#settings-1" role="tab">
                     <span class="d-block d-sm-none"><i class="fas fa-cog"></i></span>
                     <span class="d-none d-sm-block">Settings</span>    
                     </a>
                  </li>
               </ul>
               <!-- Tab panes -->
               <div class="tab-content p-3 text-muted">
                  <div class="tab-pane active" id="home-1" role="tabpanel">
                     <p class="mb-0">
                        Raw denim you probably haven't heard of them jean shorts Austin.
                        Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache
                        cliche tempor, williamsburg carles vegan helvetica. Reprehenderit
                        butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi,
                        qui irure terry richardson ex squid. Aliquip placeat salvia cillum
                        iphone. Seitan aliquip quis cardigan american apparel, butcher
                        voluptate nisi qui.
                     </p>
                  </div>
                  <div class="tab-pane" id="profile-1" role="tabpanel">
                     <div class="row">
                        <div class="col-9">
                           <h4 class="card-title">Add Description</h4>
                           <form method="post">
                              <textarea id="summernote" name="editordata"></textarea>
                           </form>
                           <h4 class="mt-3 card-title">Add Skills</h4>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <button class="btn btn-primary waves-effect waves-light px-5 m-2">+</button>
                           <div class="d-flex justify-content-end">
   <button type="button" class="btn btn-primary waves-effect waves-light m-2">Cancel</button>
   <button type="button" class="btn btn-primary waves-effect waves-light m-2">Save</button>
</div>
                        </div>
                        <!-- end col -->
                        <div class="col-md-3">
                           <button type="button" class="btn btn-outline-secondary waves-effect mt-4">View all jobs</button>
                           <p class="my-5">Use the tab JavaScript plugin—include it individually or through the compiled bootstrap.js file—to extend our navigational tabs and pills to create tabbable panes of local content, even via dropdown menus.</p>
                           <h5 class="my-2">Got a Question?</h5>
                           <p>Use the tab JavaScript plugin—include it individually or through the compiled bootstrap.js file—to extend our navigational tabs and pills to create tabbable panes of local content, even via dropdown menus.</p>
                        </div>
                     </div>
                  </div>
                  <div class="tab-pane" id="messages-1" role="tabpanel">
                     <div class="row">
                        <div class="col-9">
                           <h4 class="card-title">Add Description</h4>
                           <form method="post">
                              <textarea id="summernote1" name="editordata"></textarea>
                           </form>
                           <div class="d-flex justify-content-end">
   <button type="button" class="btn btn-primary waves-effect waves-light m-2">Cancel</button>
   <button type="button" class="btn btn-primary waves-effect waves-light m-2">Save</button>
</div>
                        </div>
                        <!-- end col -->
                        <div class="col-md-3">
                           <button type="button" class="btn btn-outline-secondary waves-effect mt-4">View all jobs</button>
                           <p class="my-5">Use the tab JavaScript plugin—include it individually or through the compiled bootstrap.js file—to extend our navigational tabs and pills to create tabbable panes of local content, even via dropdown menus.</p>
                        </div>
                     </div>
                  </div>
                  <div class="tab-pane" id="settings-1" role="tabpanel">
                    <div class="row">
                     <div class="col-md-9">
                        <table class="table table-editable dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="position: relative;">
                          <tbody>
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>1.You can chose to schdule a date & time to auto Post this job</h4>
                                 <p>Plese Select date</p><div class="col-md-12">
                                                <input class="form-control" type="date" value="2019-08-19" id="example-date-input">
                                            </div>
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                                 <input type="checkbox" class="custom-control-input" id="customSwitch1" checked="">
                                 <label class="custom-control-label" for="customSwitch1"></label>
                              </div>
                            </td>
                           </tr>
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>2.You can chose to auto Close this job Post</h4>
                                 <p>Plese Select date</p><div class="col-md-12">
                                                <input class="form-control" type="date" value="2019-08-19" id="example-date-input">
                                            </div>
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                              <input type="checkbox" class="custom-control-input" id="customSwitchsizemd2">
                                                        <label class="custom-control-label" for="customSwitchsizemd2"></label>
                              </div>
                            </td>
                           </tr>
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>3.Accept Direct Messages Form Condidate for this job</h4>
                                 
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                              <input type="checkbox" class="custom-control-input" id="customSwitchsizemd3">
                                                        <label class="custom-control-label" for="customSwitchsizemd3"></label>
                              </div>
                            </td>
                           </tr>
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>4.Set the limit of applications You Would Like to received 200</h4>
                                 <p>Once set limit of application are received this job post will br auto-closed irreepective of auto closed job post setting</p>
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                              <input type="checkbox" class="custom-control-input" id="customSwitchsizemd4">
                                                        <label class="custom-control-label" for="customSwitchsizemd4"></label>
                              </div>
                            </td>
                           </tr>
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>5.Send applications acknowledgment emaill to the applications.</h4>
                                 <form method="post">
                              <textarea id="summernote2" name="editordata"></textarea>
                           </form>
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                              <input type="checkbox" class="custom-control-input" id="customSwitchsizemd5">
                                                        <label class="custom-control-label" for="customSwitchsizemd5"></label>
                              </div>
                            </td>
                           </tr>
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>6.Recevie applications on externall website</h4>
                                 <p>we cant to gother screeing Questions if applications apply on external website</p>
                                 <div class="col-md-12">
                                                <input class="form-control" type="url" id="example-url-input" placeholder="https://www.videodesign.com/">
                                </div>
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                              <input type="checkbox" class="custom-control-input" id="customSwitchsizemd6">
                                                        <label class="custom-control-label" for="customSwitchsizemd6"></label>
                              </div>
                            </td>
                           </tr>
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>7.Send auto rejection emaills to the application who does meet the screening requirments</h4>
                                 <form method="post">
                              <textarea id="summernote3" name="editordata"></textarea>
                           </form>
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                              <input type="checkbox" class="custom-control-input" id="customSwitchsizemd7">
                                                        <label class="custom-control-label" for="customSwitchsizemd7"></label>
                              </div>
                            </td>
                           </tr> 
                           <tr role="row" class="odd">
                              <td class="sorting_1">
                                 <h4>8.Loaction</h4>
 
                              </td>
                              <td data-original-value="11"><div class="custom-control custom-switch custom-switch-md mb-3 text-right" dir="ltr">
                              <input type="checkbox" class="custom-control-input" id="customSwitchsizemd8">
                                                        <label class="custom-control-label" for="customSwitchsizemd8"></label>
                              </div>
                            </td>
                           </tr>                           
                          </tbody>
                        </table>
                        <div class="d-flex justify-content-end">
   <button type="button" class="btn btn-primary waves-effect waves-light m-2">Cancel</button>
   <button type="button" class="btn btn-primary waves-effect waves-light m-2">Save</button>
</div>
                     </div>
                     <div class="col-md-3">
                           <button type="button" class="btn btn-outline-secondary waves-effect mt-4">View all jobs</button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="d-flex justify-content-between">
   <button type="button" class="btn btn-primary waves-effect waves-light">View as Candidate</button>
   <button type="button" class="btn btn-primary waves-effect waves-light">Save as a draft</button>
</div>
<!-- JAVASCRIPT -->
<script src="assets/libs/tinymce/tinymce.min.js"></script>
<script src="assets/libs/summernote/summernote-bs4.min.js"></script>
<script src="assets/js/pages/form-editor.init.js"></script>
<script>
   $('#summernote').summernote({
     placeholder: 'Hello Bootstrap 4',
     tabsize: 2,
     height: 200
   });
   $('#summernote1').summernote({
     placeholder: 'Hello Bootstrap 4',
     tabsize: 2,
     height: 200
   });
   $('#summernote2').summernote({
     placeholder: 'Hello Bootstrap 4',
     tabsize: 2,
     height: 100
   });
   $('#summernote3').summernote({
     placeholder: 'Hello Bootstrap 4',
     tabsize: 2,
     height: 100
   });
</script>