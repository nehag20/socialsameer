<?php include 'header4.html' ?>
<link href="assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">


<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <h3 class="font-size-16 col-lg-10">Manage your Service</h3> <button class="col-lg-2 btn btn-dark">Edit Service</button>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link active" data-toggle="tab" href="#all" role="tab" aria-selected="true">
                                        <span class="d-block d-sm-none"><i class="fas fa-thumbtack"></i></span>
                                        <span class="d-none d-sm-block">My Appointements</span>
                                    </a>
                                </li>

                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link " data-toggle="tab" href="#drafts" role="tab" aria-selected="false">
                                        <span class="d-block d-sm-none"><i class="far fa-calendar-alt"></i></span>
                                        <span class="d-none d-sm-block">Calender</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-8">
                            <div class="row">
                                <div class="col-lg-12 d-flex justify-content-end">
                                    <div class="row">
                                        <div class="col-lg-8 mb-3">
                                            <form>
                                                <div class="position-relative">
                                                    <input type="text" class="custom-input form-control" placeholder="Search...">
                                                    <span class="bx bx-search-alt custom-search"></span>
                                                    <span class="bx bxs-microphone custom-voice"></span>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="col-lg-4 mb-3 d-flex align-items-center">
                                            <div class="filter">
                                                <a href="#" type="button" id="filter">
                                                    <i class="fas fa-bars"></i>
                                                    <span class="text-dark">Filters</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12" id="filter-items" style="display: none;">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <select class="form-control">
                                                <option>Sort</option>
                                                <option>Large select</option>
                                                <option>Small select</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-4">
                                            <select class="form-control">
                                                <option> Appointements Dates</option>
                                                <option>Large select</option>
                                                <option>Small select</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-4">
                                            <select class="form-control">
                                                <option>Status</option>
                                                <option>Large select</option>
                                                <option>Small select</option>
                                            </select>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-content p-3 text-muted">
                        <div class="tab-pane active" id="all" role="tabpanel">
                            <div class="row mt-3">

                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-borderless mb-0">

                                                <thead>
                                                    <tr>

                                                        <th>Name</th>
                                                        <th>Appointements</th>
                                                        <th>Time</th>
                                                        <th>Mode</th>
                                                        <th class="text-center">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>

                                                        <td>
                                                            <div class="w-25">
                                                                <img src="assets/images/avatar/profile.jpg" alt="" class="img-fluid">
                                                            </div>
                                                            <div class="name-info">
                                                                <span class="username"><a href="#"> Small Business Advisor</a></span>
                                                                <p>Full Time - Permanent <br>
                                                                    Voncouver,CA
                                                                </p>

                                                            </div>
                                                        </td>
                                                        <td>12/10/2020</td>
                                                        <td>9am-10am</td>
                                                        <td>Video</td>

                                                        <td> <select class="form-control">
                                                                    <option> Appointements Dates</option>
                                                                    <option>Large select</option>
                                                                    <option>Small select</option>
                                                                </select></td>
                                                    </tr>



                                                </tbody>


                                            </table>
                                            <div class="form-group">
                                                <textarea id="formmessage" class="form-control" rows="7" spellcheck="false" placeholder="Write some message"></textarea>
                                            </div>
                                        </div>
                                        <button class="btn btn-primary">View Resume</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane" id="drafts" role="tabpanel">

                            <div class="form-group mb-0">
                                <p class="font-size-16">Please Select 3 Dates For Total 3 Hours</p>
                                <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                    <input type="checkbox" class="custom-control-input" id="customCheckcolor2">
                                    <label class="custom-control-label" for="customCheckcolor2">Select Multiple Dates</label>
                                </div>
                                <div data-provide="datepicker-inline" class="bootstrap-datepicker-inline">
                                    <div class="datepicker datepicker-inline">
                                        <div class="datepicker-days" style="display:none;">
                                            <table class="table-condensed">
                                                <thead>
                                                    <tr>
                                                        <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                    </tr>
                                                    <tr>
                                                        <th class="prev">«</th>
                                                        <th colspan="5" class="datepicker-switch">March 2023</th>
                                                        <th class="next">»</th>
                                                    </tr>
                                                    <tr>
                                                        <th class="dow">Su</th>
                                                        <th class="dow">Mo</th>
                                                        <th class="dow">Tu</th>
                                                        <th class="dow">We</th>
                                                        <th class="dow">Th</th>
                                                        <th class="dow">Fr</th>
                                                        <th class="dow">Sa</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="old day" data-date="1677369600000">26</td>
                                                        <td class="old day" data-date="1677456000000">27</td>
                                                        <td class="old day" data-date="1677542400000">28</td>
                                                        <td class="day" data-date="1677628800000">1</td>
                                                        <td class="day" data-date="1677715200000">2</td>
                                                        <td class="day" data-date="1677801600000">3</td>
                                                        <td class="day" data-date="1677888000000">4</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="day" data-date="1677974400000">5</td>
                                                        <td class="day" data-date="1678060800000">6</td>
                                                        <td class="day" data-date="1678147200000">7</td>
                                                        <td class="day" data-date="1678233600000">8</td>
                                                        <td class="day" data-date="1678320000000">9</td>
                                                        <td class="day" data-date="1678406400000">10</td>
                                                        <td class="day" data-date="1678492800000">11</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="day" data-date="1678579200000">12</td>
                                                        <td class="day" data-date="1678665600000">13</td>
                                                        <td class="day" data-date="1678752000000">14</td>
                                                        <td class="day" data-date="1678838400000">15</td>
                                                        <td class="day" data-date="1678924800000">16</td>
                                                        <td class="day" data-date="1679011200000">17</td>
                                                        <td class="day" data-date="1679097600000">18</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="day" data-date="1679184000000">19</td>
                                                        <td class="day" data-date="1679270400000">20</td>
                                                        <td class="day" data-date="1679356800000">21</td>
                                                        <td class="day" data-date="1679443200000">22</td>
                                                        <td class="day" data-date="1679529600000">23</td>
                                                        <td class="day" data-date="1679616000000">24</td>
                                                        <td class="day" data-date="1679702400000">25</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="day" data-date="1679788800000">26</td>
                                                        <td class="day" data-date="1679875200000">27</td>
                                                        <td class="day" data-date="1679961600000">28</td>
                                                        <td class="day" data-date="1680048000000">29</td>
                                                        <td class="day" data-date="1680134400000">30</td>
                                                        <td class="day" data-date="1680220800000">31</td>
                                                        <td class="new day" data-date="1680307200000">1</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="new day" data-date="1680393600000">2</td>
                                                        <td class="new day" data-date="1680480000000">3</td>
                                                        <td class="new day" data-date="1680566400000">4</td>
                                                        <td class="new day" data-date="1680652800000">5</td>
                                                        <td class="new day" data-date="1680739200000">6</td>
                                                        <td class="new day" data-date="1680825600000">7</td>
                                                        <td class="new day" data-date="1680912000000">8</td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th colspan="7" class="today" style="display: none;">Today</th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                        <div class="datepicker-months" style="display: none;">
                                            <table class="table-condensed">
                                                <thead>
                                                    <tr>
                                                        <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                    </tr>
                                                    <tr>
                                                        <th class="prev">«</th>
                                                        <th colspan="5" class="datepicker-switch">2023</th>
                                                        <th class="next">»</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month focused">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th colspan="7" class="today" style="display: none;">Today</th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                        <div class="datepicker-years" style="display: none;">
                                            <table class="table-condensed">
                                                <thead>
                                                    <tr>
                                                        <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                    </tr>
                                                    <tr>
                                                        <th class="prev">«</th>
                                                        <th colspan="5" class="datepicker-switch">2020-2029</th>
                                                        <th class="next">»</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td colspan="7"><span class="year old">2019</span><span class="year">2020</span><span class="year">2021</span><span class="year">2022</span><span class="year focused">2023</span><span class="year">2024</span><span class="year">2025</span><span class="year">2026</span><span class="year">2027</span><span class="year">2028</span><span class="year">2029</span><span class="year new">2030</span></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th colspan="7" class="today" style="display: none;">Today</th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                        <div class="datepicker-decades" style="display: none;">
                                            <table class="table-condensed">
                                                <thead>
                                                    <tr>
                                                        <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                    </tr>
                                                    <tr>
                                                        <th class="prev">«</th>
                                                        <th colspan="5" class="datepicker-switch">2000-2090</th>
                                                        <th class="next">»</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td colspan="7"><span class="decade old">1990</span><span class="decade">2000</span><span class="decade">2010</span><span class="decade focused">2020</span><span class="decade">2030</span><span class="decade">2040</span><span class="decade">2050</span><span class="decade">2060</span><span class="decade">2070</span><span class="decade">2080</span><span class="decade">2090</span><span class="decade new">2100</span></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th colspan="7" class="today" style="display: none;">Today</th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                        <div class="datepicker-centuries" style="display: none;">
                                            <table class="table-condensed">
                                                <thead>
                                                    <tr>
                                                        <th colspan="7" class="datepicker-title" style="display: none;"></th>
                                                    </tr>
                                                    <tr>
                                                        <th class="prev">«</th>
                                                        <th colspan="5" class="datepicker-switch">2000-2900</th>
                                                        <th class="next">»</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td colspan="7"><span class="century old">1900</span><span class="century focused">2000</span><span class="century">2100</span><span class="century">2200</span><span class="century">2300</span><span class="century">2400</span><span class="century">2500</span><span class="century">2600</span><span class="century">2700</span><span class="century">2800</span><span class="century">2900</span><span class="century new">3000</span></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th colspan="7" class="today" style="display: none;">Today</th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7" class="clear" style="display: none;">Clear</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 mt-5">
                                    <h5 class="font-size-16">Avalibele time for Nomeber 14</h5>
                                    <h5 class="font-size-14">Session length 62 minutes</h5>
                                    <ul class="ks-cboxtags">
                                        <li><input type="checkbox" id="checkboxOne" value="Rainbow Dash" checked><label for="checkboxOne">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxTwo" value="Cotton Candy"><label for="checkboxTwo">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxThree" value="Rarity"><label for="checkboxThree">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxFour" value="Moondancer"><label for="checkboxFour">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxFive" value="Surprise"><label for="checkboxFive">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxSix" value="Twilight Sparkle"><label for="checkboxSix">9:00 am
                                            </label></li>
                                        <li><input type="checkbox" id="checkboxSeven" value="Fluttershy"><label for="checkboxSeven">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxEight" value="Derpy Hooves"><label for="checkboxEight">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxNine" value="Princess Celestia"><label for="checkboxNine">9:00 am
                                            </label></li>
                                        <li><input type="checkbox" id="checkboxTen" value="Gusty"><label for="checkboxTen">9:00 am</label></li>
                                        <li class="ks-selected"><input type="checkbox" id="checkboxEleven" value="Discord"><label for="checkboxEleven">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxTwelve" value="Clover"><label for="checkboxTwelve">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxThirteen" value="Baby Moondancer"><label for="checkboxThirteen">9:00 am
                                            </label></li>
                                        <li><input type="checkbox" id="checkboxFourteen" value="Medley"><label for="checkboxFourteen">9:00 am</label></li>
                                        <li><input type="checkbox" id="checkboxFifteen" value="Firefly"><label for="checkboxFifteen">9:00 am</label></li>
                                    </ul>
                                    <div class="row ml-4">
                                        <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                            <input type="checkbox" class="custom-control-input" id="customCheckcolor1">
                                            <label class="custom-control-label" for="customCheckcolor1">call</label>
                                        </div>

                                        <div class="custom-control custom-checkbox custom-checkbox-primary mb-3 mr-3">
                                            <input type="checkbox" class="custom-control-input" id="customCheckcolor2">
                                            <label class="custom-control-label" for="customCheckcolor2">video</label>
                                        </div>

                                    </div>

                                </div>
                            </div>
                            <div class="row float-right">
                                <button class="btn btn-primary ">save</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="assets/libs/dropzone/min/dropzone.min.js"></script>
    <script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
    <script src="assets/libs/twitter-bootstrap-wizard/prettify.js"></script>
    <script src="assets/js/pages/form-wizard.init.js"></script>